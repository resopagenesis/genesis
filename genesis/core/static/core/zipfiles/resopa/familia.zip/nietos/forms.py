from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from nietos.models import nieto


#@[p_importmodelos_01]



#@[p_listachoices_01]

#@[p_forms_01]

class nietoForm(forms.ModelForm):
#@[p_Meta_nieto_01]
	class Meta:
#@[p_Meta_nieto_02]
		model = nieto
#@[p_Meta_nieto_03]
#@[p_fields_nieto_01]
		fields = ('nombre',)
#@[p_fields_nieto_02]
#@[p_widgets_nieto_01]
		widgets = {
#@[p_listawidgets_nieto_01]
			'nombre': forms.TextInput(attrs={'class':'form-control font_control_nieto mt-1', 'placeholder': ''}),

#@[p_listawidgets_nieto_02]
		}
#@[p_widgets_nieto_02]
#@[p_labels_nieto_01]
		labels = {
#@[p_listalabels_nieto_01]
		'nombre':'',
#@[p_listalabels_nieto_02]
		}
#@[p_labels_nieto_02]
#@[p_reglas_nieto_01]

#@[p_reglas_nieto_02]





































































