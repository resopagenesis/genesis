from django.shortcuts import render
from django.views.generic.list import ListView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.views.generic.base import TemplateView
from django.urls import reverse, reverse_lazy
from django.http import HttpResponseRedirect

from nietos.models import nieto
from padres.models import padre
from hijos.models import hijo
from hijos.models import hijo
from padres.models import padre

#@[p_importmodelos_02]


from .forms import nietoForm

#@[p_importforms_02]



# Create your views here.
class HomeView(TemplateView):
	template_name = 'nietos/home.html'


#@[p_modelospadre_02]



class EditarnietoView(UpdateView):
#@[p_editar_nieto_01]
	model = nieto
	form_class = nietoForm
	template_name_suffix = '_update_form'

#@[p_editar_nieto_02]
	def get_success_url(self):
#@[p_editar_success_nieto_03]
		return reverse_lazy('hijos:editar_hijo', args=[self.request.GET['hijo_id']]) + '?correcto' + '&padre_id=' + str(self.request.GET['padre_id'])
#@[p_editar_success_nieto_04]

	def get_context_data(self,**kwargs):
		context = super(EditarnietoView, self).get_context_data(**kwargs)
#@[p_editar_context_nieto_01]
		nieto = (self.object)
		context['nieto_id'] = self.object.id
		context['nombre'] = nieto.nombre

		context['hijo_id'] = self.object.hijo.id
		hijo_hijo = hijo.objects.get(id=self.object.hijo.id)
		context['padre_id'] = hijo_hijo.padre.id
#@[p_borrar_context_nieto_04]


#@[p_editar_context_nieto_02]
		return context

class CrearnietoView(CreateView):
#@[p_crear_nieto_01]
	model = nieto
	form_class = nietoForm
#@[p_crear_nieto_02]

	def get_success_url(self):
#@[p_crear_success_nieto_01]
		return reverse_lazy('hijos:editar_hijo', args=[self.request.GET['hijo_id']]) + '?correcto'

	def post(self,request,*args,**kwargs):
#@[p_crear_post_nieto_01]
		form = self.form_class(request.POST)
		hijo_post = hijo.objects.get(id = request.GET['hijo_id'])
#@[p_crear_post_nieto_02]
		if form.is_valid():
#@[p_crear_post_nieto_03]
			nieto= form.save(commit=False)
			nieto.hijo = hijo_post
			nieto.save()
#@[p_crear_post_nieto_04]
			return HttpResponseRedirect(self.get_success_url())
#@[p_crear_post_nieto_05]
		else:
#@[p_crear_post_nieto_06]
			return self.render_to_response(self.get_context_data(form=form))

	def get_context_data(self,**kwargs):
#@[p_crear_context_nieto_01]
		context = super(CrearnietoView, self).get_context_data(**kwargs)
		obj = hijo.objects.get(id=self.request.GET['hijo_id'])
		context['hijo_id'] = obj.id
		padre_padre = padre.objects.get(id=obj.padre.id)
		context['padre_id'] = padre_padre.id
#@[p_crear_context_nieto_02]
		return context

class BorrarnietoView(DeleteView):
#@[p_borrar_nieto_01]
	model = nieto
#@[p_borrar_nieto_02]

	def get_success_url(self):
#@[p_borrar_success_nieto_01]
		return reverse_lazy('hijos:editar_hijo', args=[self.request.GET['hijo_id']]) + '?correcto'
#@[p_borrar_success_nieto_02]

	def get_context_data(self,**kwargs):
		context = super(BorrarnietoView, self).get_context_data(**kwargs)
#@[p_borrar_context_nieto_01]
		nieto_borra_nieto_borra = nieto.objects.get(id=self.object.id)
		context['nombreborrar'] = nieto_borra_nieto_borra.nombre
		context['hijo_id'] = self.object.hijo.id
		hijo_hijo = hijo.objects.get(id=self.object.hijo.id)
		context['padre_id'] = hijo_hijo.padre.id
#@[p_borrar_context_nieto_04]

#@[p_borrar_context_nieto_02]
		return context


#@[p_modeloshijo_02]





































































