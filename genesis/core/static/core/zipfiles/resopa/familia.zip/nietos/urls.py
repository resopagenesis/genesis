from django.urls import path
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required

from .views import HomeView
from .views import CrearnietoView, EditarnietoView, BorrarnietoView


#@[p_listaviews_01]

nietos_patterns = ([
	path('',(HomeView.as_view()), name='home'),
	path('editar_nieto/<int:pk>/',(EditarnietoView.as_view()), name='editar_nieto'),
	path('crear_nieto/',(CrearnietoView.as_view()), name='crear_nieto'),
	path('borrar_nieto/<int:pk>/',(BorrarnietoView.as_view()), name='borrar_nieto'),


#@[p_listaurls_01]
], 'nietos')

#@[p_views_01]


































































