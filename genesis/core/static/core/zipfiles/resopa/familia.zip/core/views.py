from django.shortcuts import render
from django.views.generic.base import TemplateView

#@[p_core_view_01]

class CorePageView(TemplateView):
    template_name = "core/home.html"
#@[p_core_view_02]

    def get_context_data(self, **kwargs):
        context = super(CorePageView, self).get_context_data(**kwargs)
#@[p_core_view_03]
        # # Verificar si la url lleva informacion de aplicaciones o modelos
        # try:
        #     context['opcion_menu'] = self.request.GET['opcion_menu']
        # except:
        #     context['opcion_menu'] = 'aplicaciones'

        # context['portada'] = True
        return context       

#@[p_core_view_04]



































































