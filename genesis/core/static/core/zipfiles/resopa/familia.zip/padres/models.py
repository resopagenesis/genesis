from django.db import models
from ckeditor.fields import RichTextField
from django.core.exceptions import ValidationError
from django.utils.translation import ugettext_lazy as _
from django.urls import reverse, reverse_lazy
from django.utils import timezone


# Modelos Foreign



#@[p_foraneos_01]	

# Create your models here.

#@[p_modelos_01]

class padre(models.Model):

#@[p_propiedades_padre_01]

	nombre = models.CharField(max_length=30,default='')

#@[p_propiedades_padre_02]

	def __str__(self):
#@[p_self_padre_01]
		return self.nombre
#@[p_self_padre_02]

class madre(models.Model):

#@[p_propiedades_madre_01]

	nombre = models.CharField(max_length=30,default='')

#@[p_propiedades_madre_02]

	def __str__(self):
#@[p_self_madre_01]
		return self.nombre
#@[p_self_madre_02]



#@[p_modelos_02]	


































































