from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from padres.models import padre
from padres.models import madre


#@[p_importmodelos_01]



#@[p_listachoices_01]

#@[p_forms_01]

class padreForm(forms.ModelForm):
#@[p_Meta_padre_01]
	class Meta:
#@[p_Meta_padre_02]
		model = padre
#@[p_Meta_padre_03]
#@[p_fields_padre_01]
		fields = ('nombre',)
#@[p_fields_padre_02]
#@[p_widgets_padre_01]
		widgets = {
#@[p_listawidgets_padre_01]
			'nombre': forms.TextInput(attrs={'class':'form-control font_control_padre mt-1', 'placeholder': ''}),

#@[p_listawidgets_padre_02]
		}
#@[p_widgets_padre_02]
#@[p_labels_padre_01]
		labels = {
#@[p_listalabels_padre_01]
		'nombre':'',
#@[p_listalabels_padre_02]
		}
#@[p_labels_padre_02]
#@[p_reglas_padre_01]

#@[p_reglas_padre_02]

class madreForm(forms.ModelForm):
#@[p_Meta_madre_01]
	class Meta:
#@[p_Meta_madre_02]
		model = madre
#@[p_Meta_madre_03]
#@[p_fields_madre_01]
		fields = ('nombre',)
#@[p_fields_madre_02]
#@[p_widgets_madre_01]
		widgets = {
#@[p_listawidgets_madre_01]
			'nombre': forms.TextInput(attrs={'class':'form-control font_control_madre mt-1', 'placeholder': ''}),

#@[p_listawidgets_madre_02]
		}
#@[p_widgets_madre_02]
#@[p_labels_madre_01]
		labels = {
#@[p_listalabels_madre_01]
		'nombre':'',
#@[p_listalabels_madre_02]
		}
#@[p_labels_madre_02]
#@[p_reglas_madre_01]

#@[p_reglas_madre_02]





































































