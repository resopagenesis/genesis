from django.urls import path
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required

from .views import HomeView
from .views import ListarpadreView, CrearpadreView, EditarpadreView, BorrarpadreView
from .views import ListarmadreView, CrearmadreView, EditarmadreView, BorrarmadreView


#@[p_listaviews_01]

padres_patterns = ([
	path('',(HomeView.as_view()), name='home'),
	path('listar_padre/',staff_member_required(ListarpadreView.as_view()), name='listar_padre'),
	path('editar_padre/<int:pk>/',(EditarpadreView.as_view()), name='editar_padre'),
	path('crear_padre/',(CrearpadreView.as_view()), name='crear_padre'),
	path('borrar_padre/<int:pk>/',(BorrarpadreView.as_view()), name='borrar_padre'),

	path('listar_madre/',(ListarmadreView.as_view()), name='listar_madre'),
	path('editar_madre/<int:pk>/',(EditarmadreView.as_view()), name='editar_madre'),
	path('crear_madre/',(CrearmadreView.as_view()), name='crear_madre'),
	path('borrar_madre/<int:pk>/',(BorrarmadreView.as_view()), name='borrar_madre'),


#@[p_listaurls_01]
], 'padres')

#@[p_views_01]


































































