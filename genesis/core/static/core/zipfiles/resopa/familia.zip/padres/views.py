from django.shortcuts import render
from django.views.generic.list import ListView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.views.generic.base import TemplateView
from django.urls import reverse, reverse_lazy
from django.http import HttpResponseRedirect

from padres.models import padre
from hijos.models import hijo
from hijos.models import hija
from padres.models import madre

#@[p_importmodelos_02]


from .forms import padreForm
from .forms import madreForm

#@[p_importforms_02]



# Create your views here.
class HomeView(TemplateView):
	template_name = 'padres/home.html'

class ListarpadreView(ListView):
#@[p_listar_padre_01]
	model = padre
#@[p_listar_padre_02]

	def get_context_data(self,**kwargs):
#@[p_listar_context_padre_01]
		context = super(ListarpadreView, self).get_context_data(**kwargs)
#@[p_listar_context_padre_02]
		return context

class EditarpadreView(UpdateView):
#@[p_editar_padre_01]
	model = padre
	form_class = padreForm
	template_name_suffix = '_update_form'
#@[p_editar_padre_02]

	def get_success_url(self):
#@[p_editar_success_padre_01]
		return reverse_lazy('padres:editar_padre', args=[self.object.id]) + '?correcto'

	def get_context_data(self,**kwargs):
#@[p_editar_context_padre_01]
		context = super(EditarpadreView, self).get_context_data(**kwargs)
		padre = (self.object)
		context['padre_id'] = self.object.id
#@[p_editar_context_padre_02]
		hijo_lista = hijo.objects.filter(padre = padre)
		context['listahijo'] =  hijo_lista
		hija_lista = hija.objects.filter(padre = padre)
		context['listahija'] =  hija_lista

#@[p_editar_context_padre_03]
		context['nombre'] = padre.nombre
		context['numerohijo'] = hijo.objects.filter(padre=padre).count()
		context['numerohija'] = hija.objects.filter(padre=padre).count()
		return context

class CrearpadreView(CreateView):
#@[p_crear_padre_01]
	model = padre
	form_class = padreForm
#@[p_crear_padre_02]

	def get_success_url(self):
#@[p_crear_success_padre_01]
		return reverse_lazy('padres:listar_padre') + '?correcto'
	def get_context_data(self,**kwargs):
#@[p_crear_padre_01]
		context = super(CrearpadreView, self).get_context_data(**kwargs)
#@[p_crear_padre_02]
		return context

class BorrarpadreView(DeleteView):
#@[p_borrar_padre_01]
	model = padre
#@[p_borrar_padre_02]

	def get_success_url(self):
#@[p_borrar_success_padre_01]
		return reverse_lazy('padres:listar_padre') + '?correcto'
	def get_context_data(self,**kwargs):
#@[p_borrar_context_padre_01]
		context = super(BorrarpadreView, self).get_context_data(**kwargs)
		padre_borra_padre_borra = padre.objects.get(id=self.object.id)
		context['nombreborrar'] = padre_borra_padre_borra.nombre
#@[p_borrar_context_padre_02]
		return context

class ListarmadreView(ListView):
#@[p_listar_madre_01]
	model = madre
#@[p_listar_madre_02]

	def get_context_data(self,**kwargs):
#@[p_listar_context_madre_01]
		context = super(ListarmadreView, self).get_context_data(**kwargs)
#@[p_listar_context_madre_02]
		return context

class EditarmadreView(UpdateView):
#@[p_editar_madre_01]
	model = madre
	form_class = madreForm
	template_name_suffix = '_update_form'
#@[p_editar_madre_02]

	def get_success_url(self):
#@[p_editar_success_madre_01]
		return reverse_lazy('padres:editar_madre', args=[self.object.id]) + '?correcto'

	def get_context_data(self,**kwargs):
#@[p_editar_context_madre_01]
		context = super(EditarmadreView, self).get_context_data(**kwargs)
		madre = (self.object)
		context['madre_id'] = self.object.id
#@[p_editar_context_madre_02]

#@[p_editar_context_madre_03]
		context['nombre'] = madre.nombre
		return context

class CrearmadreView(CreateView):
#@[p_crear_madre_01]
	model = madre
	form_class = madreForm
#@[p_crear_madre_02]

	def get_success_url(self):
#@[p_crear_success_madre_01]
		return reverse_lazy('padres:listar_madre') + '?correcto'
	def get_context_data(self,**kwargs):
#@[p_crear_madre_01]
		context = super(CrearmadreView, self).get_context_data(**kwargs)
#@[p_crear_madre_02]
		return context

class BorrarmadreView(DeleteView):
#@[p_borrar_madre_01]
	model = madre
#@[p_borrar_madre_02]

	def get_success_url(self):
#@[p_borrar_success_madre_01]
		return reverse_lazy('padres:listar_madre') + '?correcto'
	def get_context_data(self,**kwargs):
#@[p_borrar_context_madre_01]
		context = super(BorrarmadreView, self).get_context_data(**kwargs)
		madre_borra_madre_borra = madre.objects.get(id=self.object.id)
		context['nombreborrar'] = madre_borra_madre_borra.nombre
#@[p_borrar_context_madre_02]
		return context


#@[p_modelospadre_02]




#@[p_modeloshijo_02]





































































