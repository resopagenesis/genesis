from django.db import models
from ckeditor.fields import RichTextField
from django.core.exceptions import ValidationError
from django.utils.translation import ugettext_lazy as _
from django.urls import reverse, reverse_lazy
from django.utils import timezone


# Modelos Foreign

from padres.models import padre


#@[p_foraneos_01]	

# Create your models here.

#@[p_modelos_01]

class hijo(models.Model):

#@[p_propiedades_hijo_01]

	nombre = models.CharField(max_length=30,default='')
	padre =  models.ForeignKey(padre, on_delete=models.CASCADE)

#@[p_propiedades_hijo_02]

	def __str__(self):
#@[p_self_hijo_01]
		return self.nombre
#@[p_self_hijo_02]

class hija(models.Model):

#@[p_propiedades_hija_01]

	nombre = models.CharField(max_length=30,default='')
	padre =  models.ForeignKey(padre, on_delete=models.CASCADE)

#@[p_propiedades_hija_02]

	def __str__(self):
#@[p_self_hija_01]
		return self.nombre
#@[p_self_hija_02]



#@[p_modelos_02]	


































































