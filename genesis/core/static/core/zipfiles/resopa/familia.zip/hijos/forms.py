from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from hijos.models import hijo
from hijos.models import hija


#@[p_importmodelos_01]



#@[p_listachoices_01]

#@[p_forms_01]

class hijoForm(forms.ModelForm):
#@[p_Meta_hijo_01]
	class Meta:
#@[p_Meta_hijo_02]
		model = hijo
#@[p_Meta_hijo_03]
#@[p_fields_hijo_01]
		fields = ('nombre',)
#@[p_fields_hijo_02]
#@[p_widgets_hijo_01]
		widgets = {
#@[p_listawidgets_hijo_01]
			'nombre': forms.TextInput(attrs={'class':'form-control font_control_hijo mt-1', 'placeholder': ''}),

#@[p_listawidgets_hijo_02]
		}
#@[p_widgets_hijo_02]
#@[p_labels_hijo_01]
		labels = {
#@[p_listalabels_hijo_01]
		'nombre':'',
#@[p_listalabels_hijo_02]
		}
#@[p_labels_hijo_02]
#@[p_reglas_hijo_01]

#@[p_reglas_hijo_02]

class hijaForm(forms.ModelForm):
#@[p_Meta_hija_01]
	class Meta:
#@[p_Meta_hija_02]
		model = hija
#@[p_Meta_hija_03]
#@[p_fields_hija_01]
		fields = ('nombre',)
#@[p_fields_hija_02]
#@[p_widgets_hija_01]
		widgets = {
#@[p_listawidgets_hija_01]
			'nombre': forms.TextInput(attrs={'class':'form-control font_control_hija mt-1', 'placeholder': ''}),

#@[p_listawidgets_hija_02]
		}
#@[p_widgets_hija_02]
#@[p_labels_hija_01]
		labels = {
#@[p_listalabels_hija_01]
		'nombre':'',
#@[p_listalabels_hija_02]
		}
#@[p_labels_hija_02]
#@[p_reglas_hija_01]

#@[p_reglas_hija_02]





































































