from django.urls import path
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required

from .views import HomeView
from .views import CrearhijoView, EditarhijoView, BorrarhijoView
from .views import CrearhijaView, EditarhijaView, BorrarhijaView


#@[p_listaviews_01]

hijos_patterns = ([
	path('',(HomeView.as_view()), name='home'),
	path('editar_hijo/<int:pk>/',(EditarhijoView.as_view()), name='editar_hijo'),
	path('crear_hijo/',(CrearhijoView.as_view()), name='crear_hijo'),
	path('borrar_hijo/<int:pk>/',(BorrarhijoView.as_view()), name='borrar_hijo'),

	path('editar_hija/<int:pk>/',(EditarhijaView.as_view()), name='editar_hija'),
	path('crear_hija/',(CrearhijaView.as_view()), name='crear_hija'),
	path('borrar_hija/<int:pk>/',(BorrarhijaView.as_view()), name='borrar_hija'),


#@[p_listaurls_01]
], 'hijos')

#@[p_views_01]


































































