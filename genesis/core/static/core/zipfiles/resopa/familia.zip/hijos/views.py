from django.shortcuts import render
from django.views.generic.list import ListView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.views.generic.base import TemplateView
from django.urls import reverse, reverse_lazy
from django.http import HttpResponseRedirect

from hijos.models import hijo
from padres.models import padre
from padres.models import padre
from nietos.models import nieto
from hijos.models import hija
from padres.models import padre
from padres.models import padre

#@[p_importmodelos_02]


from .forms import hijoForm
from .forms import hijaForm

#@[p_importforms_02]



# Create your views here.
class HomeView(TemplateView):
	template_name = 'hijos/home.html'


#@[p_modelospadre_02]



class EditarhijoView(UpdateView):
#@[p_editar_hijo_01]
	model = hijo
	form_class = hijoForm
	template_name_suffix = '_update_form'

#@[p_editar_hijo_02]
	def get_success_url(self):
#@[p_editar_success_hijo_03]
		return reverse_lazy('padres:editar_padre', args=[self.request.GET['padre_id']]) + '?correcto'

	def get_context_data(self,**kwargs):
		context = super(EditarhijoView, self).get_context_data(**kwargs)
#@[p_editar_context_hijo_01]
		hijo = (self.object)
		context['hijo_id'] = self.object.id
		context['nombre'] = hijo.nombre
		nieto_nieto = nieto.objects.filter(hijo = hijo)
		context['listanieto'] =  nieto_nieto

		context['padre_id'] = self.object.padre.id
#@[p_borrar_context_hijo_04]

		context['numeronieto'] = nieto.objects.filter(hijo=hijo).count()

#@[p_editar_context_hijo_02]
		return context

class CrearhijoView(CreateView):
#@[p_crear_hijo_01]
	model = hijo
	form_class = hijoForm
#@[p_crear_hijo_02]

	def get_success_url(self):
#@[p_crear_success_hijo_01]
		return reverse_lazy('padres:editar_padre', args=[self.request.GET['padre_id']]) + '?correcto'

	def post(self,request,*args,**kwargs):
#@[p_crear_post_hijo_01]
		form = self.form_class(request.POST)
		padre_post = padre.objects.get(id = request.GET['padre_id'])
#@[p_crear_post_hijo_02]
		if form.is_valid():
#@[p_crear_post_hijo_03]
			hijo= form.save(commit=False)
			hijo.padre = padre_post
			hijo.save()
#@[p_crear_post_hijo_04]
			return HttpResponseRedirect(self.get_success_url())
#@[p_crear_post_hijo_05]
		else:
#@[p_crear_post_hijo_06]
			return self.render_to_response(self.get_context_data(form=form))

	def get_context_data(self,**kwargs):
		context = super(CrearhijoView, self).get_context_data(**kwargs)
#@[p_crear_context_hijo_01]
		context['padre_id'] = self.request.GET['padre_id']
#@[p_crear_context_hijo_02]
		return context

class BorrarhijoView(DeleteView):
#@[p_borrar_hijo_01]
	model = hijo
#@[p_borrar_hijo_02]

	def get_success_url(self):
#@[p_borrar_success_hijo_01]
		return reverse_lazy('padres:editar_padre', args=[self.request.GET['padre_id']]) + '?correcto'
#@[p_borrar_success_hijo_02]

	def get_context_data(self,**kwargs):
		context = super(BorrarhijoView, self).get_context_data(**kwargs)
#@[p_borrar_context_hijo_01]
		hijo_borra_hijo_borra = hijo.objects.get(id=self.object.id)
		context['nombreborrar'] = hijo_borra_hijo_borra.nombre
		context['padre_id'] = self.object.padre.id
#@[p_borrar_context_hijo_04]

#@[p_borrar_context_hijo_02]
		return context

class EditarhijaView(UpdateView):
#@[p_editar_hija_01]
	model = hija
	form_class = hijaForm
	template_name_suffix = '_update_form'

#@[p_editar_hija_02]
	def get_success_url(self):
#@[p_editar_success_hija_03]
		return reverse_lazy('padres:editar_padre', args=[self.request.GET['padre_id']]) + '?correcto'

	def get_context_data(self,**kwargs):
		context = super(EditarhijaView, self).get_context_data(**kwargs)
#@[p_editar_context_hija_01]
		hija = (self.object)
		context['hija_id'] = self.object.id
		context['nombre'] = hija.nombre

		context['padre_id'] = self.object.padre.id
#@[p_borrar_context_hija_04]


#@[p_editar_context_hija_02]
		return context

class CrearhijaView(CreateView):
#@[p_crear_hija_01]
	model = hija
	form_class = hijaForm
#@[p_crear_hija_02]

	def get_success_url(self):
#@[p_crear_success_hija_01]
		return reverse_lazy('padres:editar_padre', args=[self.request.GET['padre_id']]) + '?correcto'

	def post(self,request,*args,**kwargs):
#@[p_crear_post_hija_01]
		form = self.form_class(request.POST)
		padre_post = padre.objects.get(id = request.GET['padre_id'])
#@[p_crear_post_hija_02]
		if form.is_valid():
#@[p_crear_post_hija_03]
			hija= form.save(commit=False)
			hija.padre = padre_post
			hija.save()
#@[p_crear_post_hija_04]
			return HttpResponseRedirect(self.get_success_url())
#@[p_crear_post_hija_05]
		else:
#@[p_crear_post_hija_06]
			return self.render_to_response(self.get_context_data(form=form))

	def get_context_data(self,**kwargs):
		context = super(CrearhijaView, self).get_context_data(**kwargs)
#@[p_crear_context_hija_01]
		context['padre_id'] = self.request.GET['padre_id']
#@[p_crear_context_hija_02]
		return context

class BorrarhijaView(DeleteView):
#@[p_borrar_hija_01]
	model = hija
#@[p_borrar_hija_02]

	def get_success_url(self):
#@[p_borrar_success_hija_01]
		return reverse_lazy('padres:editar_padre', args=[self.request.GET['padre_id']]) + '?correcto'
#@[p_borrar_success_hija_02]

	def get_context_data(self,**kwargs):
		context = super(BorrarhijaView, self).get_context_data(**kwargs)
#@[p_borrar_context_hija_01]
		hija_borra_hija_borra = hija.objects.get(id=self.object.id)
		context['nombreborrar'] = hija_borra_hija_borra.nombre
		context['padre_id'] = self.object.padre.id
#@[p_borrar_context_hija_04]

#@[p_borrar_context_hija_02]
		return context


#@[p_modeloshijo_02]





































































