from django.urls import path
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required

from .views import HomeView
from .views import ListarregistroView, CrearregistroView, EditarregistroView, BorrarregistroView


#@[p_listaviews_01]

actividad_patterns = ([
	path('',(HomeView.as_view()), name='home'),
	path('listar_registro/',(ListarregistroView.as_view()), name='listar_registro'),
	path('editar_registro/<int:pk>/',(EditarregistroView.as_view()), name='editar_registro'),
	path('crear_registro/',(CrearregistroView.as_view()), name='crear_registro'),
	path('borrar_registro/<int:pk>/',(BorrarregistroView.as_view()), name='borrar_registro'),


#@[p_listaurls_01]
], 'actividad')

#@[p_views_01]
