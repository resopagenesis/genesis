from django.db import models
from ckeditor.fields import RichTextField
from django.core.exceptions import ValidationError
from django.utils.translation import ugettext_lazy as _
from django.urls import reverse, reverse_lazy
from django.utils import timezone
from django.contrib.auth.models import User

# Modelos Foreign

from pacientes.models import paciente
from parametros.models import consultorio
from parametros.models import estudio
from parametros.models import seguro


#@[p_foraneos_01]	

# Create your models here.

#@[p_modelos_01]

class registro(models.Model):

#@[p_propiedades_registro_01]

	paciente =  models.ForeignKey(paciente, on_delete=models.CASCADE, related_name='%(class)s_paciente')
	consultorio =  models.ForeignKey(consultorio, on_delete=models.CASCADE, related_name='%(class)s_consultorio')
	fecha = models.DateField(default=timezone.now)
	estudio =  models.ForeignKey(estudio, on_delete=models.CASCADE, related_name='%(class)s_estudio')
	horaTurno = models.TimeField(default='00:00')
	horaArribo = models.TimeField(default='00:00')
	horaAtencion = models.TimeField(default='00:00')
	horaFin = models.TimeField(default='00:00')
	turno =  models.SmallIntegerField(default=0)
	seguro =  models.ForeignKey(seguro, on_delete=models.CASCADE, related_name='%(class)s_seguro')

#@[p_propiedades_registro_02]

	def __str__(self):
#@[p_self_registro_01]
		return str(self.fecha)
#@[p_self_registro_02]



#@[p_modelos_02]	
