from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from actividad.models import registro
from pacientes.models import paciente
from parametros.models import consultorio
from parametros.models import estudio
from parametros.models import seguro


#@[p_importmodelos_01]



#@[p_listachoices_01]

#@[p_forms_01]

class registroForm(forms.ModelForm):
#@[p_Meta_registro_01]
	class Meta:
#@[p_Meta_registro_02]
		model = registro
#@[p_Meta_registro_03]
#@[p_fields_registro_01]
		fields = ('paciente','consultorio','estudio','horaTurno','horaArribo','horaAtencion','horaFin','seguro',)
#@[p_fields_registro_02]
#@[p_widgets_registro_01]
		widgets = {
#@[p_listawidgets_registro_01]
			'paciente': forms.Select(attrs={'class':'form-control  font_control_registro mt-1'},choices=paciente.objects.all()),
			'consultorio': forms.Select(attrs={'class':'form-control  font_control_registro mt-1'},choices=consultorio.objects.all()),
			'estudio': forms.Select(attrs={'class':'form-control  font_control_registro mt-1'},choices=estudio.objects.all()),
			'horaTurno': forms.TimeInput(attrs={'class':'form-control  font_control_registro mt-1'}),
			'horaArribo': forms.TimeInput(attrs={'class':'form-control  font_control_registro mt-1'}),
			'horaAtencion': forms.TimeInput(attrs={'class':'form-control  font_control_registro mt-1'}),
			'horaFin': forms.TimeInput(attrs={'class':'form-control  font_control_registro mt-1'}),
			'seguro': forms.Select(attrs={'class':'form-control  font_control_registro mt-1'},choices=seguro.objects.all()),

#@[p_listawidgets_registro_02]
		}
#@[p_widgets_registro_02]
#@[p_labels_registro_01]
		labels = {
#@[p_listalabels_registro_01]
		'paciente':'paciente','consultorio':'consultorio','estudio':'estudio','horaTurno':'Turno','horaArribo':'Arribo','horaAtencion':'Atencion','horaFin':'Fin','seguro':'seguro',
#@[p_listalabels_registro_02]
		}
#@[p_labels_registro_02]
#@[p_reglas_registro_01]

#@(p_reglas_registro_02)
class graficoForm(forms.Form):
    fecha = forms.DateField()
    def clean(self):
        cleaned_data = super(graficoForm, self).clean()
        fecha = cleaned_data.get('fecha')
        if not fecha :
            raise forms.ValidationError('Ingrese una fecha!')

#@()




