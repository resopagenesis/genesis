from django.shortcuts import render
from django.views.generic.list import ListView
from django.views.generic.edit import CreateView, UpdateView, DeleteView, FormView
from django.views.generic.base import TemplateView
from django.urls import reverse, reverse_lazy
from django.http import HttpResponseRedirect
from django.db.models import Sum, Count, Avg, Q
import random
import datetime

from actividad.models import registro

#@(p_importmodelos_02)
from django.utils import timezone
from .forms import graficoForm

#@()


from .forms import registroForm

#@(p_importforms_02)
from parametros.models import turno, imagenes
from django.db.models import Sum, Count, Avg, Q
import random
import datetime

#@()



# Create your views here.
class HomeView(TemplateView):
    template_name = 'actividad/home.html'

class ListarregistroView(ListView):
#@[p_listar_registro_01]
    model = registro
#@[p_listar_registro_02]

    def get_context_data(self,**kwargs):
#@[p_listar_context_registro_01]
        context = super(ListarregistroView, self).get_context_data(**kwargs)
#@(p_listar_context_registro_02)
        context['object_list']  = registro.objects.filter(fecha=timezone.now())
        context['object_list']  = registro.objects.all()
        labels = []
        colors = []
        data = []
        labels.append('F')
        labels.append('M')
        data.append(52)
        data.append(82)
        colors.append("#FF4136")
        colors.append("#0074D9")
        context['labels'] = labels
        context['data'] = data
        context['colors'] = colors
        context['imagenes'] = imagenes.objects.get(lista='lista')
        return context
def formaLabels(lista,dsld,hora,ejex):
    flgEsta = False
    for reg in lista:
        if reg['hora'] == hora and reg['ejex'] == ejex:
            if ejex == 'NA':
                print(reg['ejex__count'])
            dsld.append(reg['ejex__count'])
            flgEsta = True
            break
    if flgEsta == False:
        dsld.append(0)
    return dsld
def vecesHora(dsld, lista, veces, lh):
    for h in lh:
        dsld = formaLabels(lista,dsld,h,veces)
    return dsld
def sumarMinutos(hora,minutos):
    h = int(str(hora)[:2])
    m = int(str(hora)[3:5])
    s = int(str(hora)[6:9])
    m = m + minutos
    if m < 0:
        h = h -1
        m = m * -1
    elif m > 59:
        h = h + 1
        m = m - 59

#@()
        return context

class EditarregistroView(UpdateView):
#@[p_editar_registro_01]
    model = registro
    form_class = registroForm
    template_name_suffix = '_update_form'
#@[p_editar_registro_02]

    def get_success_url(self):
#@[p_editar_success_registro_01]
        return reverse_lazy('actividad:editar_registro', args=[self.object.id]) + '?correcto'

    def get_context_data(self,**kwargs):
#@[p_editar_context_registro_01]
        context = super(EditarregistroView, self).get_context_data(**kwargs)
        registro = (self.object)
        context['registro_id'] = self.object.id
#@[p_editar_context_registro_02]

#@[p_editar_context_registro_03]
        context['nombre'] = registro.fecha
        return context

class CrearregistroView(CreateView):
#@[p_crear_registro_01]
    model = registro
    form_class = registroForm
#@(p_crear_registro_02)
    def post(self,request,*args,**kwargs):
        form = self.form_class(request.POST)
        if form.is_valid():
            regis = form.save(commit=False)
            try:
                turnov = turno.objects.get(consultorio = regis.consultorio,fecha=timezone.now())
                turnov.numero = turnov.numero + 1
                regis.turno = turnov.numero
                turnov.save()
            except:
                turnov = turno()
                turnov.fecha = timezone.now()
                turnov.consultorio = regis.consultorio
                turnov.numero = 1
                regis.turno = turnov.numero
                turnov.save()
            regis.save()
            return HttpResponseRedirect(self.get_success_url())
        return render(request, 'actividad/registro_list.html', {'form': form})

#@()

    def get_success_url(self):
#@[p_crear_success_registro_01]
        return reverse_lazy('actividad:listar_registro') + '?correcto'
    def get_context_data(self,**kwargs):
#@[p_crear_successregistro_02]
        context = super(CrearregistroView, self).get_context_data(**kwargs)
#@[p_crear_successregistro_03]
        return context

class BorrarregistroView(DeleteView):
#@[p_borrar_registro_01]
    model = registro
#@[p_borrar_registro_02]

    def get_success_url(self):
#@[p_borrar_success_registro_01]
        return reverse_lazy('actividad:listar_registro') + '?correcto'
    def get_context_data(self,**kwargs):
#@[p_borrar_context_registro_01]
        context = super(BorrarregistroView, self).get_context_data(**kwargs)
        registro_borra_registro_borra = registro.objects.get(id=self.object.id)
        context['nombreborrar'] = registro_borra_registro_borra.fecha
#@[p_borrar_context_registro_02]
        return context


#@(p_modelospadre_02)
# class graficoView(TemplateView):
#     template_name = 'actividad/grafico.html'
def graficoView(request):
    if request.method == 'POST':
        form = graficoForm(request.POST)
        if form.is_valid():
            cleaned_data = form.cleaned_data
            fecha = cleaned_data.get('fecha')
            
            # for reg in registro.objects.all():
            #     # fecha.hour = str(reg.horaTurno)[:2]
            #     # print('fecha ',fecha)
            #     crit = random.randrange(1, 3, 1)
            #     if crit == 1:
            #         reg.fecha = reg.fecha + datetime.timedelta(minutes=3)
            #         # reg.horaArribo = reg.horaTurno + timedelta(seconds=10)
            #         print (reg.horaTurno,reg.fecha)
            #     # reg.save()
            #     break;
            # Para charts
            # Registros para saber el tiempo entre el turno y el arribo
            chart.objects.all().delete()
            for reg in registro.objects.all():
                graph = chart()
                graph.hora = str(reg.horaTurno)[:2]
                graph.ejex = '100'
                if str(reg.horaArribo) != '00:00:00':
                    rango = restaMinutos(reg.horaArribo,reg.horaTurno)
                    if rango >0 and rango<=10:
                        graph.ejex = '10'
                    elif rango >10 and rango<=15:
                        graph.ejex = '15'
                    elif rango >15 and rango<=25:
                        graph.ejex = '20'
                    elif rango >25 and rango<=30:
                        graph.ejex = '30'
                    elif rango >30 and rango<=35:
                        graph.ejex = '35'
                    elif rango >35 and rango<=40:
                        graph.ejex = '40'
                    elif rango >40 and rango<=60:
                        graph.ejex = '60'
                    elif rango > 60:
                        graph.ejex = '70'
                    elif rango<0:
                        graph.ejex = '0'
                graph.fecha = reg.fecha
                graph.save()
            # lista = registro.objects.values().annotate(Count('horaTurno'))
            lista = chart.objects.values('hora','ejex').annotate(Count('ejex'))
            # lista = registro.objects.filter(horaTurno='12:00:00').aggregate(Count('horaTurno'))
            # lista = registro.objects.filter(dept_name='Sales').values('dept_name').annotate(Count('employee'))
            
            labels = []
            labels.append('08')
            labels.append('09')
            labels.append('10')
            labels.append('11')
            labels.append('12')
            labels.append('13')
            labels.append('14')
            lph = []
            lm = ['0','10','20','30','40','50','60','70','100']
            lc = ['yellow','red','blue','magenta','green','darkblue','coral','gold','gray']
            texto = "Tiempo de espera entre arribo y consulta"
            i = 0
            for it in lm:
                dsld = []
                dsld = vecesHora(dsld,lista,it,labels)
                color = "%06x" % random.randint(0, 0xFFFFFF)
                lph.append([it,dsld,lc[i]])
                i+=1
            # context['labels'] = labels
            # for reg in lista:
            #     labels.append(reg['ejex'])
            #     print(reg['hora'],reg['ejex'],reg['ejex__count'])
            
            # lista = registro.objects.values('horaTurno').annotate(Count('id'))
            # lista = registro.objects.all().aggregate(total=count('id'))
            # context['lph'] = lph
            # context['texto'] = texto
            return render(request, 'actividad/turnoarribo.html', {'labels':labels,'lph':lph,'texto':texto})                    
    else:
        form = graficoForm()
    return render(request, 'actividad/grafico.html', {'form': form})

#@()




#@(p_modeloshijo_02)
def restaMinutos(horaFinal,horaInicial):
    mf = str(horaFinal)[3:5]
    mi = str(horaInicial)[3:5]
    hf = str(horaFinal)[:2]
    hi = str(horaInicial)[:2]
    minutos = (int(hf) - int(hi)) * 60
    minutos += int(mf) - int(mi)
    return minutos

#@()



