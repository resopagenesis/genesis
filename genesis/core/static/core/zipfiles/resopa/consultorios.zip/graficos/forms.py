from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User



#@[p_importmodelos_01]



#@[p_listachoices_01]

#@[p_forms_01]

#@[p__turnoarribaForm_01]
class turnoarribaForm(forms.Form):
#@[p__turnoarribaForm_02]
	fecha = forms.DateField()

#@[p__turnoarribaForm_03]
	fecha.widget.attrs.update({'class': 'datepicker form-control'})

#@[p__turnoarribaForm_04]
	def clean(self):
#@[p__turnoarribaForm_05]
		cleaned_data = super(turnoarribaForm, self).clean()
#@[p__turnoarribaForm_06]




