from django.shortcuts import render
from django.views.generic.list import ListView
from django.views.generic.edit import CreateView, UpdateView, DeleteView, FormView
from django.views.generic.base import TemplateView
from django.urls import reverse, reverse_lazy
from django.http import HttpResponseRedirect
from django.db.models import Sum, Count, Avg, Q
import random
import datetime


#@[p_importmodelos_02]


from .forms import turnoarribaForm

#@(p_importforms_02)
from actividad.models import registro

#@()



# Create your views here.
class HomeView(TemplateView):
    template_name = 'graficos/home.html'

#@[p_turnoarriba_sinbase_01]
class turnoarribaView(FormView):
#@[p_turnoarriba_view_01]
    template_name = 'graficos/turnoarriba_sinbase.html'
    form_class = turnoarribaForm
#@[p_turnoarriba_view_02]
    def get_success_url(self):
#@[p_turnoarriba_success_01]
        return reverse_lazy('core:home')
#@[p_turnoarriba_success_02]


#@(p_modelospadre_02)
    def post(self,request,*args,**kwargs):
        form = self.form_class(request.POST,request.FILES)
        if form.is_valid():
            cleaned_data = form.cleaned_data
            fecha = cleaned_data.get('fecha')
            print (fecha)
            # Los labels exteriores seran
            labels = []
            labels.append('08:00 - 08:30')
            labels.append('08:30 - 09:00')
            labels.append('09:00 - 09:30')
            labels.append('09:30 - 10:00')
            labels.append('10:00 - 10:30')
            labels.append('10:30 - 11:00')
            labels.append('11:00 - 11:30')
            labels.append('11:30 - 12:00')
            labels.append('12:00 - 12:30')
            labels.append('12:30 - 13:00')
            labels.append('13:00 - 13:30')
            labels.append('13:30 - 14:00')
            labels.append('14:00 - 14:30')
            labels.append('14:30 - 15:00')
            # Se debe encontrar para cada uno de los labels exteriores
            # el numero de minutos entre el turno y el arribo
            # Cada label exterior tendra la siguiente clasificacion de tiempos
            # entre turno y arribo
            # 0-10 si se llega antes del turno o 10 minutos entre arribo y turno
            # 10-20 si se llega entre 10 y 20 minutos despues del turno
            # 20-30 si se llega entre 20 y 30 minutos despues del turno
            # 30-40 si se llega entre 30 y 40 minutos despues del turno
            # 40-50 si se llega entre 40 y 50 minutos despues del turno
            # 50-60 si se llega entre 50 y 60 minutos despues del turno
            # 60 si se llega mas de 60 minutos despues del turno
            # data_general es la lista de data para cada intervalo de horas
            # 0 - 8 8:30
            # 1 - 8:30 9
            # 2 - 9 9:30
            # 3 - 9:30 10
            # 4 - 10 10:30
            # 5 - 10:30 11
            # 6 - 11 11:30
            # 7 - 11:30 12
            # 8 - 12 12:30
            # 9 - 12:30 13
            # 10 - 13 8:130
            # 11 - 13:30 14
            # 12 - 14 14:30
            # 13 - 14:30 15
            # data es el rango de diferencia turno y arribo
            # 0 - <0
            # 1 - 0 -10
            # 2 - 10 -20
            # 3 - 20 -30
            # 4 - 30 -40
            # 5 - 40 -50
            # 6 - 50 -60
            # 7 - >60
            data_general = []
            data0 = [0,0,0,0,0,0,0,0,0,0,0,0,0,0]
            data1 = [0,0,0,0,0,0,0,0,0,0,0,0,0,0]
            data2 = [0,0,0,0,0,0,0,0,0,0,0,0,0,0]
            data3 = [0,0,0,0,0,0,0,0,0,0,0,0,0,0]
            data4 = [0,0,0,0,0,0,0,0,0,0,0,0,0,0]
            data5 = [0,0,0,0,0,0,0,0,0,0,0,0,0,0]
            data6 = [0,0,0,0,0,0,0,0,0,0,0,0,0,0]
            data7 = [0,0,0,0,0,0,0,0,0,0,0,0,0,0]
            for reg in registro.objects.filter(fecha=fecha):
                if str(reg.horaArribo) != '00:00:00':
                    rango = restaMinutos(reg.horaArribo,reg.horaTurno)
                    hora = int(str(reg.horaTurno)[:2])
                    minuto = int(str(reg.horaTurno)[3:5])
                    if rango <= 0:
                        data0 = formaData(hora,minuto,data0)
                    if rango > 0 and rango < 10:
                        data1 = formaData(hora,minuto,data1)
                    if rango >= 10 and rango < 20:
                        data2 = formaData(hora,minuto,data2)
                    if rango >= 20 and rango < 30:
                        data3 = formaData(hora,minuto,data3)
                    if rango >= 30 and rango < 40:
                        data4 = formaData(hora,minuto,data4)
                    if rango >= 40 and rango < 50:
                        data5 = formaData(hora,minuto,data5)
                    if rango >= 50 and rango < 60:
                        data6 = formaData(hora,minuto,data6)
                    if rango >= 60:
                        data7 = formaData(hora,minuto,data7)
            data_general.append(data0)
            data_general.append(data1)
            data_general.append(data2)
            data_general.append(data3)
            data_general.append(data4)
            data_general.append(data5)
            data_general.append(data6)
            data_general.append(data7)
            # lista = registro.objects.values().annotate(Count('horaTurno'))
            # lista = chart.objects.values('hora','ejex').annotate(Count('ejex'))
            #     lista1.append([reg['hora'],reg['ejex'],reg['ejex__count']])  
            # lista = registro.objects.filter(horaTurno='12:00:00').aggregate(Count('horaTurno'))
            # lista = registro.objects.filter(dept_name='Sales').values('dept_name').annotate(Count('employee'))
            lph = []
            lm = ['<0','0-10','10-20','20-30','30-40','40-50','50-60','>60']
            lc = ['yellow','red','blue','magenta','green','darkblue','coral','gold']
            texto = "Tiempo de espera entre arribo y consulta"
            i = 0
            for it in lm:
                # color = "%06x" % random.randint(0, 0xFFFFFF)
                lph.append([it,data_general[i],lc[i]])
                i+=1
            # return HttpResponseRedirect(self.get_success_url())
        return render(request, 'graficos/turnoarriba_sinbase.html', {'form': form,'labels':labels,'texto':texto,'lph':lph})
    # def form_valid(self, form):
    #     # This method is called when valid form data has been POSTed.
    #     # It should return an HttpResponse.
    #     form.send_email()
    #     return super().form_valid(form)
def formaData(hora,minuto,data):
    if hora == 8:
        if minuto >= 0 and minuto < 30:
            data[0] += 1
        if minuto >= 30:
            data[1] += 1
    if hora == 9:
        if minuto >= 0 and minuto < 30:
            data[2] += 1
        if minuto >= 30:
            data[3] += 1
    if hora == 10:
        if minuto >= 0 and minuto < 30:
            data[4] += 1
        if minuto >= 30:
            data[5] += 1
    if hora == 11:
        if minuto >= 0 and minuto < 30:
            data[6] += 1
        if minuto >= 30:
            data[7] += 1
    if hora == 12:
        if minuto >= 0 and minuto < 30:
            data[8] += 1
        if minuto >= 30:
            data[9] += 1
    if hora == 13:
        if minuto >= 0 and minuto < 30:
            data[10] += 1
        if minuto >= 30:
            data[11] += 1
    if hora == 14:
        if minuto >= 0 and minuto < 30:
            data[12] += 1
        if minuto >= 30:
            data[13] += 1
    return data
def restaMinutos(horaFinal,horaInicial):
    mf = str(horaFinal)[3:5]
    mi = str(horaInicial)[3:5]
    hf = str(horaFinal)[:2]
    hi = str(horaInicial)[:2]
    minutos = (int(hf) - int(hi)) * 60
    minutos += int(mf) - int(mi)
    return minutos    

#@()




#@[p_modeloshijo_02]



