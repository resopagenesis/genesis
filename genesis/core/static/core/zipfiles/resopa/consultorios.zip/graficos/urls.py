from django.urls import path
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required

from .views import HomeView
from .views import turnoarribaView


#@[p_listaviews_01]

graficos_patterns = ([
	path('',(HomeView.as_view()), name='home'),
	path('turnoarriba/',(turnoarribaView.as_view()), name='turnoarriba'),


#@[p_listaurls_01]
], 'graficos')

#@[p_views_01]
