from django.db import models
from ckeditor.fields import RichTextField
from django.core.exceptions import ValidationError
from django.utils.translation import ugettext_lazy as _
from django.urls import reverse, reverse_lazy
from django.utils import timezone
from django.contrib.auth.models import User

# Modelos Foreign



#@[p_foraneos_01]	

# Create your models here.

#@[p_modelos_01]

class estudio(models.Model):

#@[p_propiedades_estudio_01]

	descripcion = models.CharField(max_length=40,default='')

#@[p_propiedades_estudio_02]

	def __str__(self):
#@[p_self_estudio_01]
		return self.descripcion
#@[p_self_estudio_02]

class seguro(models.Model):

#@[p_propiedades_seguro_01]

	nombre = models.CharField(max_length=30,default='')
	codigo = models.CharField(max_length=4,default='')

#@[p_propiedades_seguro_02]

	def __str__(self):
#@[p_self_seguro_01]
		return self.codigo
#@[p_self_seguro_02]

class consultorio(models.Model):

#@[p_propiedades_consultorio_01]

	nombre = models.CharField(max_length=30,default='')

#@[p_propiedades_consultorio_02]

	def __str__(self):
#@[p_self_consultorio_01]
		return self.nombre
#@[p_self_consultorio_02]

class turno(models.Model):

#@[p_propiedades_turno_01]

	consultorio =  models.ForeignKey(consultorio, on_delete=models.CASCADE, related_name='%(class)s_consultorio')
	numero =  models.BigIntegerField(default=1)
	fecha = models.DateField(default=timezone.now)

#@[p_propiedades_turno_02]

	def __str__(self):
#@[p_self_turno_01]
		return self.numero
#@[p_self_turno_02]

class imagenes(models.Model):

#@[p_propiedades_imagenes_01]

	lista = models.CharField(max_length=5,default='')
	turnoSinArribo = models.ImageField(upload_to='imagenes',blank=True,null=True)
	arriboSinAtencion = models.ImageField(upload_to='imagenes',blank=True,null=True)
	atencion = models.ImageField(upload_to='imagenes',blank=True,null=True)
	finAtencion = models.ImageField(upload_to='imagenes',blank=True,null=True)

#@[p_propiedades_imagenes_02]

	def __str__(self):
#@[p_self_imagenes_01]
		return self.lista
#@[p_self_imagenes_02]



#@[p_modelos_02]	
