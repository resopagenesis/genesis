from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from parametros.models import estudio
from parametros.models import seguro
from parametros.models import consultorio
from parametros.models import turno
from parametros.models import consultorio
from parametros.models import imagenes


#@[p_importmodelos_01]



#@[p_listachoices_01]

#@[p_forms_01]

class estudioForm(forms.ModelForm):
#@[p_Meta_estudio_01]
	class Meta:
#@[p_Meta_estudio_02]
		model = estudio
#@[p_Meta_estudio_03]
#@[p_fields_estudio_01]
		fields = ('descripcion',)
#@[p_fields_estudio_02]
#@[p_widgets_estudio_01]
		widgets = {
#@[p_listawidgets_estudio_01]
			'descripcion': forms.TextInput(attrs={'class':'form-control font_control_estudio mt-1', 'placeholder': ''}),

#@[p_listawidgets_estudio_02]
		}
#@[p_widgets_estudio_02]
#@[p_labels_estudio_01]
		labels = {
#@[p_listalabels_estudio_01]
		'descripcion':'descripcion',
#@[p_listalabels_estudio_02]
		}
#@[p_labels_estudio_02]
#@[p_reglas_estudio_01]

#@[p_reglas_estudio_02]

class seguroForm(forms.ModelForm):
#@[p_Meta_seguro_01]
	class Meta:
#@[p_Meta_seguro_02]
		model = seguro
#@[p_Meta_seguro_03]
#@[p_fields_seguro_01]
		fields = ('nombre','codigo',)
#@[p_fields_seguro_02]
#@[p_widgets_seguro_01]
		widgets = {
#@[p_listawidgets_seguro_01]
			'nombre': forms.TextInput(attrs={'class':'form-control font_control_seguro mt-1', 'placeholder': ''}),
			'codigo': forms.TextInput(attrs={'class':'form-control font_control_seguro mt-1', 'placeholder': ''}),

#@[p_listawidgets_seguro_02]
		}
#@[p_widgets_seguro_02]
#@[p_labels_seguro_01]
		labels = {
#@[p_listalabels_seguro_01]
		'nombre':'nombre','codigo':'codigo',
#@[p_listalabels_seguro_02]
		}
#@[p_labels_seguro_02]
#@[p_reglas_seguro_01]

#@[p_reglas_seguro_02]

class consultorioForm(forms.ModelForm):
#@[p_Meta_consultorio_01]
	class Meta:
#@[p_Meta_consultorio_02]
		model = consultorio
#@[p_Meta_consultorio_03]
#@[p_fields_consultorio_01]
		fields = ('nombre',)
#@[p_fields_consultorio_02]
#@[p_widgets_consultorio_01]
		widgets = {
#@[p_listawidgets_consultorio_01]
			'nombre': forms.TextInput(attrs={'class':'form-control font_control_consultorio mt-1', 'placeholder': ''}),

#@[p_listawidgets_consultorio_02]
		}
#@[p_widgets_consultorio_02]
#@[p_labels_consultorio_01]
		labels = {
#@[p_listalabels_consultorio_01]
		'nombre':'nombre',
#@[p_listalabels_consultorio_02]
		}
#@[p_labels_consultorio_02]
#@[p_reglas_consultorio_01]

#@[p_reglas_consultorio_02]

class turnoForm(forms.ModelForm):
#@[p_Meta_turno_01]
	class Meta:
#@[p_Meta_turno_02]
		model = turno
#@[p_Meta_turno_03]
#@[p_fields_turno_01]
		fields = ('consultorio','numero','fecha',)
#@[p_fields_turno_02]
#@[p_widgets_turno_01]
		widgets = {
#@[p_listawidgets_turno_01]
			'consultorio': forms.Select(attrs={'class':'form-control  font_control_turno mt-1'},choices=consultorio.objects.all()),
			'numero': forms.TextInput(attrs={'class':'form-control  font_control_turno mt-1', 'placeholder': ''}),
			'fecha': forms.DateInput(attrs={'class':'datepicker form-control  font_control_turno mt-1'},format="%m/%d/%Y"),

#@[p_listawidgets_turno_02]
		}
#@[p_widgets_turno_02]
#@[p_labels_turno_01]
		labels = {
#@[p_listalabels_turno_01]
		'consultorio':'consultorio','numero':'numero','fecha':'fecha',
#@[p_listalabels_turno_02]
		}
#@[p_labels_turno_02]
#@[p_reglas_turno_01]

#@[p_reglas_turno_02]

class imagenesForm(forms.ModelForm):
#@[p_Meta_imagenes_01]
	class Meta:
#@[p_Meta_imagenes_02]
		model = imagenes
#@[p_Meta_imagenes_03]
#@[p_fields_imagenes_01]
		fields = ('lista','turnoSinArribo','arriboSinAtencion','atencion','finAtencion',)
#@[p_fields_imagenes_02]
#@[p_widgets_imagenes_01]
		widgets = {
#@[p_listawidgets_imagenes_01]
			'lista': forms.TextInput(attrs={'class':'form-control font_control_imagenes mt-1', 'placeholder': ''}),
			'turnoSinArribo': forms.ClearableFileInput(attrs={'class':'form-control-file  font_control_imagenes mt-1'}),
			'arriboSinAtencion': forms.ClearableFileInput(attrs={'class':'form-control-file  font_control_imagenes mt-1'}),
			'atencion': forms.ClearableFileInput(attrs={'class':'form-control-file  font_control_imagenes mt-1'}),
			'finAtencion': forms.ClearableFileInput(attrs={'class':'form-control-file  font_control_imagenes mt-1'}),

#@[p_listawidgets_imagenes_02]
		}
#@[p_widgets_imagenes_02]
#@[p_labels_imagenes_01]
		labels = {
#@[p_listalabels_imagenes_01]
		'lista':'lista','turnoSinArribo':'imagenIngreso','arriboSinAtencion':'arriboSinAtencion','atencion':'atencion','finAtencion':'finAtencion',
#@[p_listalabels_imagenes_02]
		}
#@[p_labels_imagenes_02]
#@[p_reglas_imagenes_01]

#@[p_reglas_imagenes_02]




