from django.urls import path
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required

from .views import HomeView
from .views import ListarestudioView, CrearestudioView, EditarestudioView, BorrarestudioView
from .views import ListarseguroView, CrearseguroView, EditarseguroView, BorrarseguroView
from .views import ListarconsultorioView, CrearconsultorioView, EditarconsultorioView, BorrarconsultorioView
from .views import ListarturnoView, CrearturnoView, EditarturnoView, BorrarturnoView
from .views import ListarimagenesView, CrearimagenesView, EditarimagenesView, BorrarimagenesView


#@[p_listaviews_01]

parametros_patterns = ([
	path('',(HomeView.as_view()), name='home'),
	path('listar_estudio/',(ListarestudioView.as_view()), name='listar_estudio'),
	path('editar_estudio/<int:pk>/',(EditarestudioView.as_view()), name='editar_estudio'),
	path('crear_estudio/',(CrearestudioView.as_view()), name='crear_estudio'),
	path('borrar_estudio/<int:pk>/',(BorrarestudioView.as_view()), name='borrar_estudio'),

	path('listar_seguro/',(ListarseguroView.as_view()), name='listar_seguro'),
	path('editar_seguro/<int:pk>/',(EditarseguroView.as_view()), name='editar_seguro'),
	path('crear_seguro/',(CrearseguroView.as_view()), name='crear_seguro'),
	path('borrar_seguro/<int:pk>/',(BorrarseguroView.as_view()), name='borrar_seguro'),

	path('listar_consultorio/',(ListarconsultorioView.as_view()), name='listar_consultorio'),
	path('editar_consultorio/<int:pk>/',(EditarconsultorioView.as_view()), name='editar_consultorio'),
	path('crear_consultorio/',(CrearconsultorioView.as_view()), name='crear_consultorio'),
	path('borrar_consultorio/<int:pk>/',(BorrarconsultorioView.as_view()), name='borrar_consultorio'),

	path('listar_turno/',(ListarturnoView.as_view()), name='listar_turno'),
	path('editar_turno/<int:pk>/',(EditarturnoView.as_view()), name='editar_turno'),
	path('crear_turno/',(CrearturnoView.as_view()), name='crear_turno'),
	path('borrar_turno/<int:pk>/',(BorrarturnoView.as_view()), name='borrar_turno'),

	path('listar_imagenes/',(ListarimagenesView.as_view()), name='listar_imagenes'),
	path('editar_imagenes/<int:pk>/',(EditarimagenesView.as_view()), name='editar_imagenes'),
	path('crear_imagenes/',(CrearimagenesView.as_view()), name='crear_imagenes'),
	path('borrar_imagenes/<int:pk>/',(BorrarimagenesView.as_view()), name='borrar_imagenes'),


#@[p_listaurls_01]
], 'parametros')

#@[p_views_01]
