from django.shortcuts import render
from django.views.generic.list import ListView
from django.views.generic.edit import CreateView, UpdateView, DeleteView, FormView
from django.views.generic.base import TemplateView
from django.urls import reverse, reverse_lazy
from django.http import HttpResponseRedirect
from django.db.models import Sum, Count, Avg, Q
import random
import datetime

from parametros.models import estudio
from parametros.models import seguro
from parametros.models import consultorio
from parametros.models import turno
from parametros.models import imagenes

#@[p_importmodelos_02]


from .forms import estudioForm
from .forms import seguroForm
from .forms import consultorioForm
from .forms import turnoForm
from .forms import imagenesForm

#@[p_importforms_02]



# Create your views here.
class HomeView(TemplateView):
	template_name = 'parametros/home.html'

class ListarestudioView(ListView):
#@[p_listar_estudio_01]
	model = estudio
#@[p_listar_estudio_02]

	def get_context_data(self,**kwargs):
#@[p_listar_context_estudio_01]
		context = super(ListarestudioView, self).get_context_data(**kwargs)
#@[p_listar_context_estudio_02]
		return context

class EditarestudioView(UpdateView):
#@[p_editar_estudio_01]
	model = estudio
	form_class = estudioForm
	template_name_suffix = '_update_form'
#@[p_editar_estudio_02]

	def get_success_url(self):
#@[p_editar_success_estudio_01]
		return reverse_lazy('parametros:editar_estudio', args=[self.object.id]) + '?correcto'

	def get_context_data(self,**kwargs):
#@[p_editar_context_estudio_01]
		context = super(EditarestudioView, self).get_context_data(**kwargs)
		estudio = (self.object)
		context['estudio_id'] = self.object.id
#@[p_editar_context_estudio_02]

#@[p_editar_context_estudio_03]
		context['nombre'] = estudio.descripcion
		return context

class CrearestudioView(CreateView):
#@[p_crear_estudio_01]
	model = estudio
	form_class = estudioForm
#@[p_crear_estudio_02]

	def get_success_url(self):
#@[p_crear_success_estudio_01]
		return reverse_lazy('parametros:listar_estudio') + '?correcto'
	def get_context_data(self,**kwargs):
#@[p_crear_successestudio_02]
		context = super(CrearestudioView, self).get_context_data(**kwargs)
#@[p_crear_successestudio_03]
		return context

class BorrarestudioView(DeleteView):
#@[p_borrar_estudio_01]
	model = estudio
#@[p_borrar_estudio_02]

	def get_success_url(self):
#@[p_borrar_success_estudio_01]
		return reverse_lazy('parametros:listar_estudio') + '?correcto'
	def get_context_data(self,**kwargs):
#@[p_borrar_context_estudio_01]
		context = super(BorrarestudioView, self).get_context_data(**kwargs)
		estudio_borra_estudio_borra = estudio.objects.get(id=self.object.id)
		context['nombreborrar'] = estudio_borra_estudio_borra.descripcion
#@[p_borrar_context_estudio_02]
		return context

class ListarseguroView(ListView):
#@[p_listar_seguro_01]
	model = seguro
#@[p_listar_seguro_02]

	def get_context_data(self,**kwargs):
#@[p_listar_context_seguro_01]
		context = super(ListarseguroView, self).get_context_data(**kwargs)
#@[p_listar_context_seguro_02]
		return context

class EditarseguroView(UpdateView):
#@[p_editar_seguro_01]
	model = seguro
	form_class = seguroForm
	template_name_suffix = '_update_form'
#@[p_editar_seguro_02]

	def get_success_url(self):
#@[p_editar_success_seguro_01]
		return reverse_lazy('parametros:editar_seguro', args=[self.object.id]) + '?correcto'

	def get_context_data(self,**kwargs):
#@[p_editar_context_seguro_01]
		context = super(EditarseguroView, self).get_context_data(**kwargs)
		seguro = (self.object)
		context['seguro_id'] = self.object.id
#@[p_editar_context_seguro_02]

#@[p_editar_context_seguro_03]
		context['nombre'] = seguro.codigo
		return context

class CrearseguroView(CreateView):
#@[p_crear_seguro_01]
	model = seguro
	form_class = seguroForm
#@[p_crear_seguro_02]

	def get_success_url(self):
#@[p_crear_success_seguro_01]
		return reverse_lazy('parametros:listar_seguro') + '?correcto'
	def get_context_data(self,**kwargs):
#@[p_crear_successseguro_02]
		context = super(CrearseguroView, self).get_context_data(**kwargs)
#@[p_crear_successseguro_03]
		return context

class BorrarseguroView(DeleteView):
#@[p_borrar_seguro_01]
	model = seguro
#@[p_borrar_seguro_02]

	def get_success_url(self):
#@[p_borrar_success_seguro_01]
		return reverse_lazy('parametros:listar_seguro') + '?correcto'
	def get_context_data(self,**kwargs):
#@[p_borrar_context_seguro_01]
		context = super(BorrarseguroView, self).get_context_data(**kwargs)
		seguro_borra_seguro_borra = seguro.objects.get(id=self.object.id)
		context['nombreborrar'] = seguro_borra_seguro_borra.codigo
#@[p_borrar_context_seguro_02]
		return context

class ListarconsultorioView(ListView):
#@[p_listar_consultorio_01]
	model = consultorio
#@[p_listar_consultorio_02]

	def get_context_data(self,**kwargs):
#@[p_listar_context_consultorio_01]
		context = super(ListarconsultorioView, self).get_context_data(**kwargs)
#@[p_listar_context_consultorio_02]
		return context

class EditarconsultorioView(UpdateView):
#@[p_editar_consultorio_01]
	model = consultorio
	form_class = consultorioForm
	template_name_suffix = '_update_form'
#@[p_editar_consultorio_02]

	def get_success_url(self):
#@[p_editar_success_consultorio_01]
		return reverse_lazy('parametros:editar_consultorio', args=[self.object.id]) + '?correcto'

	def get_context_data(self,**kwargs):
#@[p_editar_context_consultorio_01]
		context = super(EditarconsultorioView, self).get_context_data(**kwargs)
		consultorio = (self.object)
		context['consultorio_id'] = self.object.id
#@[p_editar_context_consultorio_02]

#@[p_editar_context_consultorio_03]
		context['nombre'] = consultorio.nombre
		return context

class CrearconsultorioView(CreateView):
#@[p_crear_consultorio_01]
	model = consultorio
	form_class = consultorioForm
#@[p_crear_consultorio_02]

	def get_success_url(self):
#@[p_crear_success_consultorio_01]
		return reverse_lazy('parametros:listar_consultorio') + '?correcto'
	def get_context_data(self,**kwargs):
#@[p_crear_successconsultorio_02]
		context = super(CrearconsultorioView, self).get_context_data(**kwargs)
#@[p_crear_successconsultorio_03]
		return context

class BorrarconsultorioView(DeleteView):
#@[p_borrar_consultorio_01]
	model = consultorio
#@[p_borrar_consultorio_02]

	def get_success_url(self):
#@[p_borrar_success_consultorio_01]
		return reverse_lazy('parametros:listar_consultorio') + '?correcto'
	def get_context_data(self,**kwargs):
#@[p_borrar_context_consultorio_01]
		context = super(BorrarconsultorioView, self).get_context_data(**kwargs)
		consultorio_borra_consultorio_borra = consultorio.objects.get(id=self.object.id)
		context['nombreborrar'] = consultorio_borra_consultorio_borra.nombre
#@[p_borrar_context_consultorio_02]
		return context

class ListarturnoView(ListView):
#@[p_listar_turno_01]
	model = turno
#@[p_listar_turno_02]

	def get_context_data(self,**kwargs):
#@[p_listar_context_turno_01]
		context = super(ListarturnoView, self).get_context_data(**kwargs)
#@[p_listar_context_turno_02]
		return context

class EditarturnoView(UpdateView):
#@[p_editar_turno_01]
	model = turno
	form_class = turnoForm
	template_name_suffix = '_update_form'
#@[p_editar_turno_02]

	def get_success_url(self):
#@[p_editar_success_turno_01]
		return reverse_lazy('parametros:editar_turno', args=[self.object.id]) + '?correcto'

	def get_context_data(self,**kwargs):
#@[p_editar_context_turno_01]
		context = super(EditarturnoView, self).get_context_data(**kwargs)
		turno = (self.object)
		context['turno_id'] = self.object.id
#@[p_editar_context_turno_02]

#@[p_editar_context_turno_03]
		context['nombre'] = turno.numero
		return context

class CrearturnoView(CreateView):
#@[p_crear_turno_01]
	model = turno
	form_class = turnoForm
#@[p_crear_turno_02]

	def get_success_url(self):
#@[p_crear_success_turno_01]
		return reverse_lazy('parametros:listar_turno') + '?correcto'
	def get_context_data(self,**kwargs):
#@[p_crear_successturno_02]
		context = super(CrearturnoView, self).get_context_data(**kwargs)
#@[p_crear_successturno_03]
		return context

class BorrarturnoView(DeleteView):
#@[p_borrar_turno_01]
	model = turno
#@[p_borrar_turno_02]

	def get_success_url(self):
#@[p_borrar_success_turno_01]
		return reverse_lazy('parametros:listar_turno') + '?correcto'
	def get_context_data(self,**kwargs):
#@[p_borrar_context_turno_01]
		context = super(BorrarturnoView, self).get_context_data(**kwargs)
		turno_borra_turno_borra = turno.objects.get(id=self.object.id)
		context['nombreborrar'] = turno_borra_turno_borra.numero
#@[p_borrar_context_turno_02]
		return context

class ListarimagenesView(ListView):
#@[p_listar_imagenes_01]
	model = imagenes
#@[p_listar_imagenes_02]

	def get_context_data(self,**kwargs):
#@[p_listar_context_imagenes_01]
		context = super(ListarimagenesView, self).get_context_data(**kwargs)
#@[p_listar_context_imagenes_02]
		return context

class EditarimagenesView(UpdateView):
#@[p_editar_imagenes_01]
	model = imagenes
	form_class = imagenesForm
	template_name_suffix = '_update_form'
#@[p_editar_imagenes_02]

	def get_success_url(self):
#@[p_editar_success_imagenes_01]
		return reverse_lazy('parametros:editar_imagenes', args=[self.object.id]) + '?correcto'

	def get_context_data(self,**kwargs):
#@[p_editar_context_imagenes_01]
		context = super(EditarimagenesView, self).get_context_data(**kwargs)
		imagenes = (self.object)
		context['imagenes_id'] = self.object.id
#@[p_editar_context_imagenes_02]

#@[p_editar_context_imagenes_03]
		context['nombre'] = imagenes.lista
		return context

class CrearimagenesView(CreateView):
#@[p_crear_imagenes_01]
	model = imagenes
	form_class = imagenesForm
#@[p_crear_imagenes_02]

	def get_success_url(self):
#@[p_crear_success_imagenes_01]
		return reverse_lazy('parametros:listar_imagenes') + '?correcto'
	def get_context_data(self,**kwargs):
#@[p_crear_successimagenes_02]
		context = super(CrearimagenesView, self).get_context_data(**kwargs)
#@[p_crear_successimagenes_03]
		return context

class BorrarimagenesView(DeleteView):
#@[p_borrar_imagenes_01]
	model = imagenes
#@[p_borrar_imagenes_02]

	def get_success_url(self):
#@[p_borrar_success_imagenes_01]
		return reverse_lazy('parametros:listar_imagenes') + '?correcto'
	def get_context_data(self,**kwargs):
#@[p_borrar_context_imagenes_01]
		context = super(BorrarimagenesView, self).get_context_data(**kwargs)
		imagenes_borra_imagenes_borra = imagenes.objects.get(id=self.object.id)
		context['nombreborrar'] = imagenes_borra_imagenes_borra.lista
#@[p_borrar_context_imagenes_02]
		return context


#@[p_modelospadre_02]




#@[p_modeloshijo_02]



