from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from pacientes.models import paciente


#@[p_importmodelos_01]



#@[p_listachoices_01]

#@[p_forms_01]

class pacienteForm(forms.ModelForm):
#@[p_Meta_paciente_01]
	class Meta:
#@[p_Meta_paciente_02]
		model = paciente
#@[p_Meta_paciente_03]
#@[p_fields_paciente_01]
		fields = ('nombre','ci','codigo','fechaNacimiento','domicilio',)
#@[p_fields_paciente_02]
#@[p_widgets_paciente_01]
		widgets = {
#@[p_listawidgets_paciente_01]
			'nombre': forms.TextInput(attrs={'class':'form-control font_control_paciente mt-1', 'placeholder': ''}),
			'ci': forms.TextInput(attrs={'class':'form-control font_control_paciente mt-1', 'placeholder': ''}),
			'codigo': forms.TextInput(attrs={'class':'form-control font_control_paciente mt-1', 'placeholder': ''}),
			'fechaNacimiento': forms.DateInput(attrs={'class':'datepicker form-control  font_control_paciente mt-1'},format="%m/%d/%Y"),
			'domicilio': forms.TextInput(attrs={'class':'form-control font_control_paciente mt-1', 'placeholder': ''}),

#@[p_listawidgets_paciente_02]
		}
#@[p_widgets_paciente_02]
#@[p_labels_paciente_01]
		labels = {
#@[p_listalabels_paciente_01]
		'nombre':'nombre','ci':'ci','codigo':'codigo','fechaNacimiento':'fechaNacimiento','domicilio':'domicilio',
#@[p_listalabels_paciente_02]
		}
#@[p_labels_paciente_02]
#@[p_reglas_paciente_01]

#@[p_reglas_paciente_02]




