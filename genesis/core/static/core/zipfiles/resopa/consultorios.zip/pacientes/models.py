from django.db import models
from ckeditor.fields import RichTextField
from django.core.exceptions import ValidationError
from django.utils.translation import ugettext_lazy as _
from django.urls import reverse, reverse_lazy
from django.utils import timezone
from django.contrib.auth.models import User

# Modelos Foreign



#@[p_foraneos_01]	

# Create your models here.

#@[p_modelos_01]

class paciente(models.Model):

#@[p_propiedades_paciente_01]

	nombre = models.CharField(max_length=50,default='')
	ci = models.CharField(max_length=30,default='')
	codigo = models.CharField(max_length=30,default='')
	fechaNacimiento = models.DateField(default=timezone.now)
	domicilio = models.CharField(max_length=30,default='')

#@[p_propiedades_paciente_02]

	def __str__(self):
#@[p_self_paciente_01]
		return self.nombre
#@[p_self_paciente_02]



#@[p_modelos_02]	
