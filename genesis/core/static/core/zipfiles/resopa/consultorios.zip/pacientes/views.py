from django.shortcuts import render
from django.views.generic.list import ListView
from django.views.generic.edit import CreateView, UpdateView, DeleteView, FormView
from django.views.generic.base import TemplateView
from django.urls import reverse, reverse_lazy
from django.http import HttpResponseRedirect
from django.db.models import Sum, Count, Avg, Q
import random
import datetime

from pacientes.models import paciente

#@[p_importmodelos_02]


from .forms import pacienteForm

#@[p_importforms_02]



# Create your views here.
class HomeView(TemplateView):
	template_name = 'pacientes/home.html'

class ListarpacienteView(ListView):
#@[p_listar_paciente_01]
	model = paciente
#@[p_listar_paciente_02]

	def get_context_data(self,**kwargs):
#@[p_listar_context_paciente_01]
		context = super(ListarpacienteView, self).get_context_data(**kwargs)
#@[p_listar_context_paciente_02]
		return context

class EditarpacienteView(UpdateView):
#@[p_editar_paciente_01]
	model = paciente
	form_class = pacienteForm
	template_name_suffix = '_update_form'
#@[p_editar_paciente_02]

	def get_success_url(self):
#@[p_editar_success_paciente_01]
		return reverse_lazy('pacientes:editar_paciente', args=[self.object.id]) + '?correcto'

	def get_context_data(self,**kwargs):
#@[p_editar_context_paciente_01]
		context = super(EditarpacienteView, self).get_context_data(**kwargs)
		paciente = (self.object)
		context['paciente_id'] = self.object.id
#@[p_editar_context_paciente_02]

#@[p_editar_context_paciente_03]
		context['nombre'] = paciente.nombre
		return context

class CrearpacienteView(CreateView):
#@[p_crear_paciente_01]
	model = paciente
	form_class = pacienteForm
#@[p_crear_paciente_02]

	def get_success_url(self):
#@[p_crear_success_paciente_01]
		return reverse_lazy('pacientes:listar_paciente') + '?correcto'
	def get_context_data(self,**kwargs):
#@[p_crear_successpaciente_02]
		context = super(CrearpacienteView, self).get_context_data(**kwargs)
#@[p_crear_successpaciente_03]
		return context

class BorrarpacienteView(DeleteView):
#@[p_borrar_paciente_01]
	model = paciente
#@[p_borrar_paciente_02]

	def get_success_url(self):
#@[p_borrar_success_paciente_01]
		return reverse_lazy('pacientes:listar_paciente') + '?correcto'
	def get_context_data(self,**kwargs):
#@[p_borrar_context_paciente_01]
		context = super(BorrarpacienteView, self).get_context_data(**kwargs)
		paciente_borra_paciente_borra = paciente.objects.get(id=self.object.id)
		context['nombreborrar'] = paciente_borra_paciente_borra.nombre
#@[p_borrar_context_paciente_02]
		return context


#@[p_modelospadre_02]




#@[p_modeloshijo_02]



