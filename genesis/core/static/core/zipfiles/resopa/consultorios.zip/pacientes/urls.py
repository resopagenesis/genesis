from django.urls import path
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required

from .views import HomeView
from .views import ListarpacienteView, CrearpacienteView, EditarpacienteView, BorrarpacienteView


#@[p_listaviews_01]

pacientes_patterns = ([
	path('',(HomeView.as_view()), name='home'),
	path('listar_paciente/',(ListarpacienteView.as_view()), name='listar_paciente'),
	path('editar_paciente/<int:pk>/',(EditarpacienteView.as_view()), name='editar_paciente'),
	path('crear_paciente/',(CrearpacienteView.as_view()), name='crear_paciente'),
	path('borrar_paciente/<int:pk>/',(BorrarpacienteView.as_view()), name='borrar_paciente'),


#@[p_listaurls_01]
], 'pacientes')

#@[p_views_01]
