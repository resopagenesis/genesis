from django.db import models
from django.contrib.auth.models import User
from django.dispatch import receiver
from django.db.models.signals import post_save

#@[p_models_seguridad_01]

# def custom_upload_to(instance,filename):
# 	old_instance = Profile.objects.get(pk=instance.pk)
# 	old_instance.avatar.delete()
# 	return 'profiles/' + filename
	
# Create your models here.
class Profile(models.Model):
	user = models.OneToOneField(User,on_delete=models.CASCADE)
	avatar = models.ImageField(upload_to='profile',blank=True,null=True)
	biografia = models.TextField(null=True,blank=True)
#@[p_models_seguridad_02]

# @receiver(post_save,sender=User)
# def ensure_profile_exists(sender, instance, **kwargs):
# 	if kwargs.get('created', False):
# 		Profile.objects.get_or_create(user=instance)
# 		print("Se acaba de crear un usuario y u perfil enlazado")




