from django.urls import path
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required

from .views import HomeView
from .views import ListardepartamentoView, CreardepartamentoView, EditardepartamentoView, BorrardepartamentoView
from .views import CrearciudadView, EditarciudadView, BorrarciudadView
from .views import ListarpaisView, CrearpaisView, EditarpaisView, BorrarpaisView


#@[p_listaviews_01]

lugares_patterns = ([
	path('',(HomeView.as_view()), name='home'),
	path('listar_departamento/',(ListardepartamentoView.as_view()), name='listar_departamento'),
	path('editar_departamento/<int:pk>/',(EditardepartamentoView.as_view()), name='editar_departamento'),
	path('crear_departamento/',(CreardepartamentoView.as_view()), name='crear_departamento'),
	path('borrar_departamento/<int:pk>/',(BorrardepartamentoView.as_view()), name='borrar_departamento'),

	path('editar_ciudad/<int:pk>/',(EditarciudadView.as_view()), name='editar_ciudad'),
	path('crear_ciudad/',(CrearciudadView.as_view()), name='crear_ciudad'),
	path('borrar_ciudad/<int:pk>/',(BorrarciudadView.as_view()), name='borrar_ciudad'),

	path('listar_pais/',(ListarpaisView.as_view()), name='listar_pais'),
	path('editar_pais/<int:pk>/',(EditarpaisView.as_view()), name='editar_pais'),
	path('crear_pais/',(CrearpaisView.as_view()), name='crear_pais'),
	path('borrar_pais/<int:pk>/',(BorrarpaisView.as_view()), name='borrar_pais'),


#@[p_listaurls_01]
], 'lugares')

#@[p_views_01]

