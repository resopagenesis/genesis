from django.shortcuts import render
from django.views.generic.list import ListView
from django.views.generic.edit import CreateView, UpdateView, DeleteView, FormView
from django.views.generic.base import TemplateView
from django.urls import reverse, reverse_lazy
from django.http import HttpResponseRedirect
from django.db.models import Sum, Count, Avg, Q
import random
import datetime
from django import forms

from lugares.models import departamento
from lugares.models import ciudad
from lugares.models import ciudad
from lugares.models import departamento
from lugares.models import departamento
from lugares.models import pais

#@[p_importmodelos_02]


from .forms import departamentoForm
from .forms import ciudadForm
from .forms import paisForm

#@[p_importforms_02]



# Create your views here.
class HomeView(TemplateView):
	template_name = 'lugares/home.html'

class ListardepartamentoView(ListView):
#@[p_listar_departamento_01]
	model = departamento
#@[p_listar_departamento_02]
	template_name = 'lugares/departamento_list.html'
#@[p_listar_departamento_03]

	def get_context_data(self,**kwargs):
#@[p_listar_context_departamento_01]
		context = super(ListardepartamentoView, self).get_context_data(**kwargs)
#@[p_listar_context_departamento_02]
		return context

class EditardepartamentoView(UpdateView):
#@[p_editar_departamento_01]
	model = departamento
	form_class = departamentoForm
#@[p_editar_departamento_02]
	template_name = 'lugares/departamento_update_form.html'
#@[p_editar_departamento_03]

	def get_success_url(self):
#@[p_editar_success_departamento_01]
		return reverse_lazy('lugares:editar_departamento', args=[self.object.id]) + '?correcto'

	def get_context_data(self,**kwargs):
#@[p_editar_context_departamento_01]
		context = super(EditardepartamentoView, self).get_context_data(**kwargs)
		departamento = (self.object)
		context['departamento_id'] = self.object.id
#@[p_editar_context_departamento_02]
		ciudad_lista = ciudad.objects.filter(departamento = departamento)
		context['listaciudad'] =  ciudad_lista

#@[p_editar_context_departamento_03]
		context['nombre'] = departamento.nombre
		context['numerociudad'] = ciudad.objects.filter(departamento=departamento).count()
		return context

class CreardepartamentoView(CreateView):
#@[p_crear_departamento_01]
	model = departamento
	form_class = departamentoForm
#@[p_crear_departamento_02]
	template_name = 'lugares/departamento_form.html'
#@[p_crear_departamento_03]

	def get_success_url(self):
#@[p_crear_success_departamento_01]
		return reverse_lazy('lugares:listar_departamento') + '?correcto'
	def get_context_data(self,**kwargs):
#@[p_crear_successdepartamento_02]
		context = super(CreardepartamentoView, self).get_context_data(**kwargs)
#@[p_crear_successdepartamento_03]
		return context

class BorrardepartamentoView(DeleteView):
#@[p_borrar_departamento_01]
	model = departamento
#@[p_borrar_departamento_02]
	template_name = 'lugares/departamento_confirm_delete.html'
#@[p_borrar_departamento_03]

	def get_success_url(self):
#@[p_borrar_success_departamento_01]
		return reverse_lazy('lugares:listar_departamento') + '?correcto'
	def get_context_data(self,**kwargs):
#@[p_borrar_context_departamento_01]
		context = super(BorrardepartamentoView, self).get_context_data(**kwargs)
		departamento_borra_departamento_borra = departamento.objects.get(id=self.object.id)
		context['nombreborrar'] = departamento_borra_departamento_borra.nombre
#@[p_borrar_context_departamento_02]
		return context

class ListarpaisView(ListView):
#@[p_listar_pais_01]
	model = pais
#@[p_listar_pais_02]
	template_name = 'lugares/pais_list.html'
#@[p_listar_pais_03]

	def get_context_data(self,**kwargs):
#@[p_listar_context_pais_01]
		context = super(ListarpaisView, self).get_context_data(**kwargs)
#@[p_listar_context_pais_02]
		return context

class EditarpaisView(UpdateView):
#@[p_editar_pais_01]
	model = pais
	form_class = paisForm
#@[p_editar_pais_02]
	template_name = 'lugares/pais_update_form.html'
#@[p_editar_pais_03]

	def get_success_url(self):
#@[p_editar_success_pais_01]
		return reverse_lazy('lugares:editar_pais', args=[self.object.id]) + '?correcto'

	def get_context_data(self,**kwargs):
#@[p_editar_context_pais_01]
		context = super(EditarpaisView, self).get_context_data(**kwargs)
		pais = (self.object)
		context['pais_id'] = self.object.id
#@[p_editar_context_pais_02]

#@[p_editar_context_pais_03]
		context['nombre'] = pais.nombre
		return context

class CrearpaisView(CreateView):
#@[p_crear_pais_01]
	model = pais
	form_class = paisForm
#@[p_crear_pais_02]
	template_name = 'lugares/pais_form.html'
#@[p_crear_pais_03]

	def get_success_url(self):
#@[p_crear_success_pais_01]
		return reverse_lazy('lugares:listar_pais') + '?correcto'
	def get_context_data(self,**kwargs):
#@[p_crear_successpais_02]
		context = super(CrearpaisView, self).get_context_data(**kwargs)
#@[p_crear_successpais_03]
		return context

class BorrarpaisView(DeleteView):
#@[p_borrar_pais_01]
	model = pais
#@[p_borrar_pais_02]
	template_name = 'lugares/pais_confirm_delete.html'
#@[p_borrar_pais_03]

	def get_success_url(self):
#@[p_borrar_success_pais_01]
		return reverse_lazy('lugares:listar_pais') + '?correcto'
	def get_context_data(self,**kwargs):
#@[p_borrar_context_pais_01]
		context = super(BorrarpaisView, self).get_context_data(**kwargs)
		pais_borra_pais_borra = pais.objects.get(id=self.object.id)
		context['nombreborrar'] = pais_borra_pais_borra.nombre
#@[p_borrar_context_pais_02]
		return context


#@[p_modelospadre_02]



class EditarciudadView(UpdateView):
#@[p_editar_ciudad_01]
	model = ciudad
#@[p_editar_ciudad_02]
	form_class = ciudadForm
#@[p_editar_ciudad_03]
	template_name = 'lugares/ciudad_update_form.html'

#@[p_editar_ciudad_04]
	def get_success_url(self):
#@[p_editar_success_ciudad_03]
		return reverse_lazy('lugares:editar_departamento', args=[self.request.GET['departamento_id']]) + '?correcto'

	def get_context_data(self,**kwargs):
		context = super(EditarciudadView, self).get_context_data(**kwargs)
#@[p_editar_context_ciudad_01]
		ciudad = (self.object)
		context['ciudad_id'] = self.object.id
		context['nombre'] = ciudad.nombre

		context['departamento_id'] = self.object.departamento.id
#@[p_borrar_context_ciudad_04]


#@[p_editar_context_ciudad_02]
		return context

class CrearciudadView(CreateView):
#@[p_crear_ciudad_01]
	model = ciudad
#@[p_crear_ciudad_02]
	form_class = ciudadForm
#@[p_crear_ciudad_03]
	template_name = 'lugares/ciudad_form.html'
#@[p_crear_ciudad_04]

	def get_success_url(self):
#@[p_crear_success_ciudad_01]
		return reverse_lazy('lugares:editar_departamento', args=[self.request.GET['departamento_id']]) + '?correcto'

	def post(self,request,*args,**kwargs):
#@[p_crear_post_ciudad_01]
		form = self.form_class(request.POST)
		departamento_post = departamento.objects.get(id = request.GET['departamento_id'])
#@[p_crear_post_ciudad_02]
		if form.is_valid():
#@[p_crear_post_ciudad_03]
			ciudad= form.save(commit=False)
#@[p_crear_post_ciudad_03_A]
			ciudad.departamento = departamento_post
			ciudad.save()
#@[p_crear_post_ciudad_04]
			return HttpResponseRedirect(self.get_success_url())
#@[p_crear_post_ciudad_05]
		else:
#@[p_crear_post_ciudad_06]
			return self.render_to_response(self.get_context_data(form=form))

	def get_context_data(self,**kwargs):
		context = super(CrearciudadView, self).get_context_data(**kwargs)
#@[p_crear_context_ciudad_01]
		context['departamento_id'] = self.request.GET['departamento_id']
#@[p_crear_context_ciudad_02]
		return context

class BorrarciudadView(DeleteView):
#@[p_borrar_ciudad_01]
	model = ciudad
#@[p_borrar_ciudad_02]
	template_name = 'lugares/ciudad_confirm_delete.html'
#@[p_borrar_ciudad_03]

	def get_success_url(self):
#@[p_borrar_success_ciudad_01]
		return reverse_lazy('lugares:editar_departamento', args=[self.request.GET['departamento_id']]) + '?correcto'
#@[p_borrar_success_ciudad_02]

	def get_context_data(self,**kwargs):
		context = super(BorrarciudadView, self).get_context_data(**kwargs)
#@[p_borrar_context_ciudad_01]
		ciudad_borra_ciudad_borra = ciudad.objects.get(id=self.object.id)
		context['nombreborrar'] = ciudad_borra_ciudad_borra.nombre
		context['departamento_id'] = self.object.departamento.id
#@[p_borrar_context_ciudad_04]

#@[p_borrar_context_ciudad_02]
		return context


#@[p_modeloshijo_02]




