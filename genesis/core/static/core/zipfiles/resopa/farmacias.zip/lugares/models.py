from django.db import models
from ckeditor.fields import RichTextField
from django.core.exceptions import ValidationError
from django.utils.translation import ugettext_lazy as _
from django.urls import reverse, reverse_lazy
from django.utils import timezone
from django.contrib.auth.models import User


# Modelos Foreign



#@[p_foraneos_01]	

# Create your models here.

#@[p_modelos_01]

class pais(models.Model):

#@[p_propiedades_pais_01]

	nombre = models.CharField(max_length=30)

#@[p_propiedades_pais_02]

	def __str__(self):
#@[p_self_pais_01]
		return self.nombre
#@[p_self_pais_02]

class departamento(models.Model):

#@[p_propiedades_departamento_01]

	nombre = models.CharField(max_length=30)

#@[p_propiedades_departamento_02]

	def __str__(self):
#@[p_self_departamento_01]
		return self.nombre
#@[p_self_departamento_02]

class ciudad(models.Model):

#@[p_propiedades_ciudad_01]

	nombre = models.CharField(max_length=30)
	departamento =  models.ForeignKey(departamento, on_delete=models.CASCADE)

#@[p_propiedades_ciudad_02]

	def __str__(self):
#@[p_self_ciudad_01]
		return self.nombre
#@[p_self_ciudad_02]



#@[p_modelos_02]	


