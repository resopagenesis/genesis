from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from lugares.models import departamento
from lugares.models import ciudad
from lugares.models import pais


#@[p_importmodelos_01]



#@[p_listachoices_01]

#@[p_forms_01]

class departamentoForm(forms.ModelForm):
#@[p_Meta_departamento_01]
	class Meta:
#@[p_Meta_departamento_02]
		model = departamento
#@[p_Meta_departamento_03]
#@[p_fields_departamento_01]
		fields = ('nombre',)
#@[p_fields_departamento_02]
#@[p_widgets_departamento_01]
		widgets = {
#@[p_listawidgets_departamento_01]
			'nombre': forms.TextInput(attrs={'class':'form-control font_control_departamento mt-1', 'placeholder': ''}),

#@[p_listawidgets_departamento_02]
		}
#@[p_widgets_departamento_02]
#@[p_labels_departamento_01]
		labels = {
#@[p_listalabels_departamento_01]
		'nombre':'Nombre',
#@[p_listalabels_departamento_02]
		}
#@[p_labels_departamento_02]
#@[p_reglas_departamento_01]

#@[p_reglas_departamento_02]

class ciudadForm(forms.ModelForm):
#@[p_Meta_ciudad_01]
	class Meta:
#@[p_Meta_ciudad_02]
		model = ciudad
#@[p_Meta_ciudad_03]
#@[p_fields_ciudad_01]
		fields = ('nombre',)
#@[p_fields_ciudad_02]
#@[p_widgets_ciudad_01]
		widgets = {
#@[p_listawidgets_ciudad_01]
			'nombre': forms.TextInput(attrs={'class':'form-control font_control_ciudad mt-1', 'placeholder': ''}),

#@[p_listawidgets_ciudad_02]
		}
#@[p_widgets_ciudad_02]
#@[p_labels_ciudad_01]
		labels = {
#@[p_listalabels_ciudad_01]
		'nombre':'Nombre',
#@[p_listalabels_ciudad_02]
		}
#@[p_labels_ciudad_02]
#@[p_reglas_ciudad_01]

#@[p_reglas_ciudad_02]

class paisForm(forms.ModelForm):
#@[p_Meta_pais_01]
	class Meta:
#@[p_Meta_pais_02]
		model = pais
#@[p_Meta_pais_03]
#@[p_fields_pais_01]
		fields = ('nombre',)
#@[p_fields_pais_02]
#@[p_widgets_pais_01]
		widgets = {
#@[p_listawidgets_pais_01]
			'nombre': forms.TextInput(attrs={'class':'form-control font_control_pais mt-1', 'placeholder': ''}),

#@[p_listawidgets_pais_02]
		}
#@[p_widgets_pais_02]
#@[p_labels_pais_01]
		labels = {
#@[p_listalabels_pais_01]
		'nombre':'Nombre',
#@[p_listalabels_pais_02]
		}
#@[p_labels_pais_02]
#@[p_reglas_pais_01]

#@[p_reglas_pais_02]





