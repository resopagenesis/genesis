from django.shortcuts import render
from django.views.generic.list import ListView
from django.views.generic.edit import CreateView, UpdateView, DeleteView, FormView
from django.views.generic.base import TemplateView
from django.urls import reverse, reverse_lazy
from django.http import HttpResponseRedirect
from django.db.models import Sum, Count, Avg, Q
import random
import datetime
from django import forms

from inventarios.models import medicamento

#@[p_importmodelos_02]


from .forms import medicamentoForm

#@[p_importforms_02]



# Create your views here.
class HomeView(TemplateView):
	template_name = 'inventarios/home.html'

class ListarmedicamentoView(ListView):
#@[p_listar_medicamento_01]
	model = medicamento
#@[p_listar_medicamento_02]
	template_name = 'inventarios/medicamento_list.html'
#@[p_listar_medicamento_03]

	def get_context_data(self,**kwargs):
#@[p_listar_context_medicamento_01]
		context = super(ListarmedicamentoView, self).get_context_data(**kwargs)
#@[p_listar_context_medicamento_02]
		return context

class EditarmedicamentoView(UpdateView):
#@[p_editar_medicamento_01]
	model = medicamento
	form_class = medicamentoForm
#@[p_editar_medicamento_02]
	template_name = 'inventarios/medicamento_update_form.html'
#@[p_editar_medicamento_03]

	def get_success_url(self):
#@[p_editar_success_medicamento_01]
		return reverse_lazy('inventarios:editar_medicamento', args=[self.object.id]) + '?correcto'

	def get_context_data(self,**kwargs):
#@[p_editar_context_medicamento_01]
		context = super(EditarmedicamentoView, self).get_context_data(**kwargs)
		medicamento = (self.object)
		context['medicamento_id'] = self.object.id
#@[p_editar_context_medicamento_02]

#@[p_editar_context_medicamento_03]
		context['nombre'] = medicamento.nombre
		return context

class CrearmedicamentoView(CreateView):
#@[p_crear_medicamento_01]
	model = medicamento
	form_class = medicamentoForm
#@[p_crear_medicamento_02]
	template_name = 'inventarios/medicamento_form.html'
#@[p_crear_medicamento_03]

	def get_success_url(self):
#@[p_crear_success_medicamento_01]
		return reverse_lazy('inventarios:listar_medicamento') + '?correcto'
	def get_context_data(self,**kwargs):
#@[p_crear_successmedicamento_02]
		context = super(CrearmedicamentoView, self).get_context_data(**kwargs)
#@[p_crear_successmedicamento_03]
		return context

class BorrarmedicamentoView(DeleteView):
#@[p_borrar_medicamento_01]
	model = medicamento
#@[p_borrar_medicamento_02]
	template_name = 'inventarios/medicamento_confirm_delete.html'
#@[p_borrar_medicamento_03]

	def get_success_url(self):
#@[p_borrar_success_medicamento_01]
		return reverse_lazy('inventarios:listar_medicamento') + '?correcto'
	def get_context_data(self,**kwargs):
#@[p_borrar_context_medicamento_01]
		context = super(BorrarmedicamentoView, self).get_context_data(**kwargs)
		medicamento_borra_medicamento_borra = medicamento.objects.get(id=self.object.id)
		context['nombreborrar'] = medicamento_borra_medicamento_borra.nombre
#@[p_borrar_context_medicamento_02]
		return context


#@[p_modelospadre_02]




#@[p_modeloshijo_02]




