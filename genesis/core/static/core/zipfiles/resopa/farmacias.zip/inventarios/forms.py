from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from inventarios.models import medicamento
from parametros.models import tipoGenerico
from parametros.models import tipoAdministracion
from parametros.models import tipoMedicamento
from generales.models import laboratorio


#@[p_importmodelos_01]



#@[p_listachoices_01]

#@[p_forms_01]

class medicamentoForm(forms.ModelForm):
#@[p_Meta_medicamento_01]
	class Meta:
#@[p_Meta_medicamento_02]
		model = medicamento
#@[p_Meta_medicamento_03]
#@[p_fields_medicamento_01]
		fields = ('nombreComercial','fechaVencimiento','tipoGenerico','tipoAdministracion','tipoMedicamento','concentracion','laboratorio',)
#@[p_fields_medicamento_02]
#@[p_widgets_medicamento_01]
		widgets = {
#@[p_listawidgets_medicamento_01]
			'nombreComercial': forms.TextInput(attrs={'class':'form-control font_control_medicamento mt-1', 'placeholder': ''}),
			'fechaVencimiento': forms.DateInput(attrs={'class':'datepicker form-control  font_control_medicamento mt-1'},format="%m/%d/%Y"),
			'tipoGenerico': forms.Select(attrs={'class':'form-control  font_control_medicamento mt-1'},choices=tipoGenerico.objects.all()),
			'tipoAdministracion': forms.Select(attrs={'class':'form-control  font_control_medicamento mt-1'},choices=tipoAdministracion.objects.all()),
			'tipoMedicamento': forms.Select(attrs={'class':'form-control  font_control_medicamento mt-1'},choices=tipoMedicamento.objects.all()),
			'concentracion': forms.Textarea(attrs={'class':'form-control  font_control_medicamento mt-1', 'placeholder': ''}),
			'laboratorio': forms.Select(attrs={'class':'form-control  font_control_medicamento mt-1'},choices=laboratorio.objects.all()),

#@[p_listawidgets_medicamento_02]
		}
#@[p_widgets_medicamento_02]
#@[p_labels_medicamento_01]
		labels = {
#@[p_listalabels_medicamento_01]
		'nombreComercial':'Nombre comercial','fechaVencimiento':'Expiracion','tipoGenerico':'Generico','tipoAdministracion':'Administracion','tipoMedicamento':'Tipo','concentracion':'Concentracion','laboratorio':'Laboratorio',
#@[p_listalabels_medicamento_02]
		}
#@[p_labels_medicamento_02]
#@[p_reglas_medicamento_01]

#@[p_reglas_medicamento_02]





