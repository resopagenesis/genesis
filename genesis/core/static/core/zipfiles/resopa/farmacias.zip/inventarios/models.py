from django.db import models
from ckeditor.fields import RichTextField
from django.core.exceptions import ValidationError
from django.utils.translation import ugettext_lazy as _
from django.urls import reverse, reverse_lazy
from django.utils import timezone
from django.contrib.auth.models import User


# Modelos Foreign

from parametros.models import tipoGenerico
from parametros.models import tipoAdministracion
from parametros.models import tipoMedicamento
from generales.models import laboratorio


#@[p_foraneos_01]	

# Create your models here.

#@[p_modelos_01]

class medicamento(models.Model):

#@[p_propiedades_medicamento_01]

	nombreComercial = models.CharField(max_length=30)
	fechaVencimiento = models.DateField()
	tipoGenerico =  models.ForeignKey(tipoGenerico, on_delete=models.CASCADE, related_name='%(class)s_tipoGenerico')
	tipoAdministracion =  models.ForeignKey(tipoAdministracion, on_delete=models.CASCADE, related_name='%(class)s_tipoAdministracion')
	tipoMedicamento =  models.ForeignKey(tipoMedicamento, on_delete=models.CASCADE, related_name='%(class)s_tipoMedicamento')
	concentracion = models.TextField()
	laboratorio =  models.ForeignKey(laboratorio, on_delete=models.CASCADE, related_name='%(class)s_laboratorio')

#@[p_propiedades_medicamento_02]

	def __str__(self):
#@[p_self_medicamento_01]
		return self.nombre
#@[p_self_medicamento_02]



#@[p_modelos_02]	


