from django.urls import path
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required

from .views import HomeView
from .views import ListarmedicamentoView, CrearmedicamentoView, EditarmedicamentoView, BorrarmedicamentoView


#@[p_listaviews_01]

inventarios_patterns = ([
	path('',(HomeView.as_view()), name='home'),
	path('listar_medicamento/',(ListarmedicamentoView.as_view()), name='listar_medicamento'),
	path('editar_medicamento/<int:pk>/',(EditarmedicamentoView.as_view()), name='editar_medicamento'),
	path('crear_medicamento/',(CrearmedicamentoView.as_view()), name='crear_medicamento'),
	path('borrar_medicamento/<int:pk>/',(BorrarmedicamentoView.as_view()), name='borrar_medicamento'),


#@[p_listaurls_01]
], 'inventarios')

#@[p_views_01]

