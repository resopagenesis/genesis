from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from generales.models import cadena
from generales.models import tienda
from lugares.models import departamento
from generales.models import laboratorio
from lugares.models import pais


#@[p_importmodelos_01]



#@[p_listachoices_01]

#@[p_forms_01]

class cadenaForm(forms.ModelForm):
#@[p_Meta_cadena_01]
	class Meta:
#@[p_Meta_cadena_02]
		model = cadena
#@[p_Meta_cadena_03]
#@[p_fields_cadena_01]
		fields = ('nombre','fechaFundacion','responsable','nit',)
#@[p_fields_cadena_02]
#@[p_widgets_cadena_01]
		widgets = {
#@[p_listawidgets_cadena_01]
			'nombre': forms.TextInput(attrs={'class':'form-control font_control_cadena mt-1', 'placeholder': ''}),
			'fechaFundacion': forms.DateInput(attrs={'class':'datepicker form-control  font_control_cadena mt-1'},format="%m/%d/%Y"),
			'responsable': forms.TextInput(attrs={'class':'form-control font_control_cadena mt-1', 'placeholder': ''}),
			'nit': forms.TextInput(attrs={'class':'form-control font_control_cadena mt-1', 'placeholder': ''}),

#@[p_listawidgets_cadena_02]
		}
#@[p_widgets_cadena_02]
#@[p_labels_cadena_01]
		labels = {
#@[p_listalabels_cadena_01]
		'nombre':'Nombre','fechaFundacion':'Fundacion','responsable':'Responsable','nit':'NIT',
#@[p_listalabels_cadena_02]
		}
#@[p_labels_cadena_02]
#@[p_reglas_cadena_01]

#@[p_reglas_cadena_02]

class tiendaForm(forms.ModelForm):
#@[p_Meta_tienda_01]
	class Meta:
#@[p_Meta_tienda_02]
		model = tienda
#@[p_Meta_tienda_03]
#@[p_fields_tienda_01]
		fields = ('nombre','departamento','ciudad',)
#@[p_fields_tienda_02]
#@[p_widgets_tienda_01]
		widgets = {
#@[p_listawidgets_tienda_01]
			'nombre': forms.TextInput(attrs={'class':'form-control font_control_tienda mt-1', 'placeholder': ''}),
			'departamento': forms.Select(attrs={'class':'form-control  font_control_tienda mt-1'},choices=departamento.objects.all()),
			'ciudad': forms.TextInput(attrs={'class':'form-control font_control_tienda mt-1', 'placeholder': ''}),

#@[p_listawidgets_tienda_02]
		}
#@[p_widgets_tienda_02]
#@[p_labels_tienda_01]
		labels = {
#@[p_listalabels_tienda_01]
		'nombre':'Nombre','departamento':'Departamento','ciudad':'Ciudad',
#@[p_listalabels_tienda_02]
		}
#@[p_labels_tienda_02]
#@[p_reglas_tienda_01]

#@[p_reglas_tienda_02]

class laboratorioForm(forms.ModelForm):
#@[p_Meta_laboratorio_01]
	class Meta:
#@[p_Meta_laboratorio_02]
		model = laboratorio
#@[p_Meta_laboratorio_03]
#@[p_fields_laboratorio_01]
		fields = ('nombre','pais',)
#@[p_fields_laboratorio_02]
#@[p_widgets_laboratorio_01]
		widgets = {
#@[p_listawidgets_laboratorio_01]
			'nombre': forms.TextInput(attrs={'class':'form-control font_control_laboratorio mt-1', 'placeholder': ''}),
			'pais': forms.Select(attrs={'class':'form-control  font_control_laboratorio mt-1'},choices=pais.objects.all()),

#@[p_listawidgets_laboratorio_02]
		}
#@[p_widgets_laboratorio_02]
#@[p_labels_laboratorio_01]
		labels = {
#@[p_listalabels_laboratorio_01]
		'nombre':'Nombre','pais':'Pais',
#@[p_listalabels_laboratorio_02]
		}
#@[p_labels_laboratorio_02]
#@[p_reglas_laboratorio_01]

#@[p_reglas_laboratorio_02]





