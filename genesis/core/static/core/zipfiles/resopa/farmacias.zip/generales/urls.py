from django.urls import path
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required

from .views import HomeView
from .views import ListarcadenaView, CrearcadenaView, EditarcadenaView, BorrarcadenaView
from .views import CreartiendaView, EditartiendaView, BorrartiendaView
from .views import ListarlaboratorioView, CrearlaboratorioView, EditarlaboratorioView, BorrarlaboratorioView


#@[p_listaviews_01]

generales_patterns = ([
	path('',(HomeView.as_view()), name='home'),
	path('listar_cadena/',(ListarcadenaView.as_view()), name='listar_cadena'),
	path('editar_cadena/<int:pk>/',(EditarcadenaView.as_view()), name='editar_cadena'),
	path('crear_cadena/',(CrearcadenaView.as_view()), name='crear_cadena'),
	path('borrar_cadena/<int:pk>/',(BorrarcadenaView.as_view()), name='borrar_cadena'),

	path('editar_tienda/<int:pk>/',(EditartiendaView.as_view()), name='editar_tienda'),
	path('crear_tienda/',(CreartiendaView.as_view()), name='crear_tienda'),
	path('borrar_tienda/<int:pk>/',(BorrartiendaView.as_view()), name='borrar_tienda'),

	path('listar_laboratorio/',(ListarlaboratorioView.as_view()), name='listar_laboratorio'),
	path('editar_laboratorio/<int:pk>/',(EditarlaboratorioView.as_view()), name='editar_laboratorio'),
	path('crear_laboratorio/',(CrearlaboratorioView.as_view()), name='crear_laboratorio'),
	path('borrar_laboratorio/<int:pk>/',(BorrarlaboratorioView.as_view()), name='borrar_laboratorio'),


#@[p_listaurls_01]
], 'generales')

#@[p_views_01]

