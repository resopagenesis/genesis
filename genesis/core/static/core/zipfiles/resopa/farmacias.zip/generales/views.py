from django.shortcuts import render
from django.views.generic.list import ListView
from django.views.generic.edit import CreateView, UpdateView, DeleteView, FormView
from django.views.generic.base import TemplateView
from django.urls import reverse, reverse_lazy
from django.http import HttpResponseRedirect
from django.db.models import Sum, Count, Avg, Q
import random
import datetime
from django import forms

from generales.models import cadena
from generales.models import tienda
from generales.models import tienda
from generales.models import cadena
from generales.models import cadena
from generales.models import laboratorio

#@(p_importmodelos_02)
from lugares.models import ciudad

#@()


from .forms import cadenaForm
from .forms import tiendaForm
from .forms import laboratorioForm

#@[p_importforms_02]



# Create your views here.
class HomeView(TemplateView):
    template_name = 'generales/home.html'

class ListarcadenaView(ListView):
#@[p_listar_cadena_01]
    model = cadena
#@[p_listar_cadena_02]
    template_name = 'generales/cadena_list.html'
#@[p_listar_cadena_03]

    def get_context_data(self,**kwargs):
#@[p_listar_context_cadena_01]
        context = super(ListarcadenaView, self).get_context_data(**kwargs)
#@[p_listar_context_cadena_02]
        return context

class EditarcadenaView(UpdateView):
#@[p_editar_cadena_01]
    model = cadena
    form_class = cadenaForm
#@[p_editar_cadena_02]
    template_name = 'generales/cadena_update_form.html'
#@[p_editar_cadena_03]

    def get_success_url(self):
#@[p_editar_success_cadena_01]
        return reverse_lazy('generales:editar_cadena', args=[self.object.id]) + '?correcto'

    def get_context_data(self,**kwargs):
#@[p_editar_context_cadena_01]
        context = super(EditarcadenaView, self).get_context_data(**kwargs)
        cadena = (self.object)
        context['cadena_id'] = self.object.id
#@[p_editar_context_cadena_02]
        tienda_lista = tienda.objects.filter(cadena = cadena)
        context['listatienda'] =  tienda_lista

#@[p_editar_context_cadena_03]
        context['nombre'] = cadena.nombre
        context['numerotienda'] = tienda.objects.filter(cadena=cadena).count()
        return context

class CrearcadenaView(CreateView):
#@[p_crear_cadena_01]
    model = cadena
    form_class = cadenaForm
#@[p_crear_cadena_02]
    template_name = 'generales/cadena_form.html'
#@[p_crear_cadena_03]

    def get_success_url(self):
#@[p_crear_success_cadena_01]
        return reverse_lazy('generales:listar_cadena') + '?correcto'
    def get_context_data(self,**kwargs):
#@[p_crear_successcadena_02]
        context = super(CrearcadenaView, self).get_context_data(**kwargs)
#@[p_crear_successcadena_03]
        return context

class BorrarcadenaView(DeleteView):
#@[p_borrar_cadena_01]
    model = cadena
#@[p_borrar_cadena_02]
    template_name = 'generales/cadena_confirm_delete.html'
#@[p_borrar_cadena_03]

    def get_success_url(self):
#@[p_borrar_success_cadena_01]
        return reverse_lazy('generales:listar_cadena') + '?correcto'
    def get_context_data(self,**kwargs):
#@[p_borrar_context_cadena_01]
        context = super(BorrarcadenaView, self).get_context_data(**kwargs)
        cadena_borra_cadena_borra = cadena.objects.get(id=self.object.id)
        context['nombreborrar'] = cadena_borra_cadena_borra.nombre
#@[p_borrar_context_cadena_02]
        return context

class ListarlaboratorioView(ListView):
#@[p_listar_laboratorio_01]
    model = laboratorio
#@[p_listar_laboratorio_02]
    template_name = 'generales/laboratorio_list.html'
#@[p_listar_laboratorio_03]

    def get_context_data(self,**kwargs):
#@[p_listar_context_laboratorio_01]
        context = super(ListarlaboratorioView, self).get_context_data(**kwargs)
#@[p_listar_context_laboratorio_02]
        return context

class EditarlaboratorioView(UpdateView):
#@[p_editar_laboratorio_01]
    model = laboratorio
    form_class = laboratorioForm
#@[p_editar_laboratorio_02]
    template_name = 'generales/laboratorio_update_form.html'
#@[p_editar_laboratorio_03]

    def get_success_url(self):
#@[p_editar_success_laboratorio_01]
        return reverse_lazy('generales:editar_laboratorio', args=[self.object.id]) + '?correcto'

    def get_context_data(self,**kwargs):
#@[p_editar_context_laboratorio_01]
        context = super(EditarlaboratorioView, self).get_context_data(**kwargs)
        laboratorio = (self.object)
        context['laboratorio_id'] = self.object.id
#@[p_editar_context_laboratorio_02]

#@[p_editar_context_laboratorio_03]
        context['nombre'] = laboratorio.nombre
        return context

class CrearlaboratorioView(CreateView):
#@[p_crear_laboratorio_01]
    model = laboratorio
    form_class = laboratorioForm
#@[p_crear_laboratorio_02]
    template_name = 'generales/laboratorio_form.html'
#@[p_crear_laboratorio_03]

    def get_success_url(self):
#@[p_crear_success_laboratorio_01]
        return reverse_lazy('generales:listar_laboratorio') + '?correcto'
    def get_context_data(self,**kwargs):
#@[p_crear_successlaboratorio_02]
        context = super(CrearlaboratorioView, self).get_context_data(**kwargs)
#@[p_crear_successlaboratorio_03]
        return context

class BorrarlaboratorioView(DeleteView):
#@[p_borrar_laboratorio_01]
    model = laboratorio
#@[p_borrar_laboratorio_02]
    template_name = 'generales/laboratorio_confirm_delete.html'
#@[p_borrar_laboratorio_03]

    def get_success_url(self):
#@[p_borrar_success_laboratorio_01]
        return reverse_lazy('generales:listar_laboratorio') + '?correcto'
    def get_context_data(self,**kwargs):
#@[p_borrar_context_laboratorio_01]
        context = super(BorrarlaboratorioView, self).get_context_data(**kwargs)
        laboratorio_borra_laboratorio_borra = laboratorio.objects.get(id=self.object.id)
        context['nombreborrar'] = laboratorio_borra_laboratorio_borra.nombre
#@[p_borrar_context_laboratorio_02]
        return context


#@[p_modelospadre_02]



class EditartiendaView(UpdateView):
#@[p_editar_tienda_01]
    model = tienda
#@[p_editar_tienda_02]
    form_class = tiendaForm
#@[p_editar_tienda_03]
    template_name = 'generales/tienda_update_form.html'

#@[p_editar_tienda_04]
    def get_success_url(self):
#@[p_editar_success_tienda_03]
        return reverse_lazy('generales:editar_cadena', args=[self.request.GET['cadena_id']]) + '?correcto'

    def get_context_data(self,**kwargs):
        context = super(EditartiendaView, self).get_context_data(**kwargs)
#@[p_editar_context_tienda_01]
        tienda = (self.object)
        context['tienda_id'] = self.object.id
        context['nombre'] = tienda.nombre

        context['cadena_id'] = self.object.cadena.id
#@[p_borrar_context_tienda_04]


#@[p_editar_context_tienda_02]
        return context

class CreartiendaView(CreateView):
#@[p_crear_tienda_01]
    model = tienda
#@[p_crear_tienda_02]
    form_class = tiendaForm
#@[p_crear_tienda_03]
    template_name = 'generales/tienda_form.html'
#@(p_crear_tienda_04)
    def get_form(self,form_class=None):
        form = super(CreartiendaView, self).get_form()
        CIUDAD_LIST = []
        for ml in ciudad.objects.all():
           CIUDAD_LIST.append([ml.nombre, ml.nombre + '-' + ml.departamento.nombre])
        print(CIUDAD_LIST)
        form.fields['ciudad'].widget = forms.Select(attrs={'class':'form-control  font_control_tienda mt-1'},choices=CIUDAD_LIST)
        return form

#@()

    def get_success_url(self):
#@[p_crear_success_tienda_01]
        return reverse_lazy('generales:editar_cadena', args=[self.request.GET['cadena_id']]) + '?correcto'

    def post(self,request,*args,**kwargs):
#@[p_crear_post_tienda_01]
        form = self.form_class(request.POST)
        cadena_post = cadena.objects.get(id = request.GET['cadena_id'])
#@[p_crear_post_tienda_02]
        if form.is_valid():
#@[p_crear_post_tienda_03]
            tienda= form.save(commit=False)
#@[p_crear_post_tienda_03_A]
            tienda.cadena = cadena_post
            tienda.save()
#@[p_crear_post_tienda_04]
            return HttpResponseRedirect(self.get_success_url())
#@[p_crear_post_tienda_05]
        else:
#@[p_crear_post_tienda_06]
            return self.render_to_response(self.get_context_data(form=form))

    def get_context_data(self,**kwargs):
        context = super(CreartiendaView, self).get_context_data(**kwargs)
#@[p_crear_context_tienda_01]
        context['cadena_id'] = self.request.GET['cadena_id']
#@[p_crear_context_tienda_02]
        return context

class BorrartiendaView(DeleteView):
#@[p_borrar_tienda_01]
    model = tienda
#@[p_borrar_tienda_02]
    template_name = 'generales/tienda_confirm_delete.html'
#@[p_borrar_tienda_03]

    def get_success_url(self):
#@[p_borrar_success_tienda_01]
        return reverse_lazy('generales:editar_cadena', args=[self.request.GET['cadena_id']]) + '?correcto'
#@[p_borrar_success_tienda_02]

    def get_context_data(self,**kwargs):
        context = super(BorrartiendaView, self).get_context_data(**kwargs)
#@[p_borrar_context_tienda_01]
        tienda_borra_tienda_borra = tienda.objects.get(id=self.object.id)
        context['nombreborrar'] = tienda_borra_tienda_borra.nombre
        context['cadena_id'] = self.object.cadena.id
#@[p_borrar_context_tienda_04]

#@[p_borrar_context_tienda_02]
        return context


#@[p_modeloshijo_02]






