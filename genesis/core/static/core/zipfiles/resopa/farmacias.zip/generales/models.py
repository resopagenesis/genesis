from django.db import models
from ckeditor.fields import RichTextField
from django.core.exceptions import ValidationError
from django.utils.translation import ugettext_lazy as _
from django.urls import reverse, reverse_lazy
from django.utils import timezone
from django.contrib.auth.models import User


# Modelos Foreign

from lugares.models import pais
from lugares.models import departamento


#@[p_foraneos_01]	

# Create your models here.

#@[p_modelos_01]

class laboratorio(models.Model):

#@[p_propiedades_laboratorio_01]

	nombre = models.CharField(max_length=30)
	pais =  models.ForeignKey(pais, on_delete=models.CASCADE, related_name='%(class)s_pais')

#@[p_propiedades_laboratorio_02]

	def __str__(self):
#@[p_self_laboratorio_01]
		return self.nombre
#@[p_self_laboratorio_02]

class cadena(models.Model):

#@[p_propiedades_cadena_01]

	nombre = models.CharField(max_length=30,default='')
	fechaFundacion = models.DateField(default=timezone.now)
	responsable = models.CharField(max_length=30,default='')
	nit = models.CharField(max_length=30)

#@[p_propiedades_cadena_02]

	def __str__(self):
#@[p_self_cadena_01]
		return self.nombre
#@[p_self_cadena_02]

class tienda(models.Model):

#@[p_propiedades_tienda_01]

	nombre = models.CharField(max_length=30)
	departamento =  models.ForeignKey(departamento, on_delete=models.CASCADE, related_name='%(class)s_departamento')
	ciudad = models.CharField(max_length=30,default='')
	cadena =  models.ForeignKey(cadena, on_delete=models.CASCADE)

#@[p_propiedades_tienda_02]

	def __str__(self):
#@[p_self_tienda_01]
		return self.nombre
#@[p_self_tienda_02]



#@[p_modelos_02]	


