from django.shortcuts import render
from django.views.generic.list import ListView
from django.views.generic.edit import CreateView, UpdateView, DeleteView, FormView
from django.views.generic.base import TemplateView
from django.urls import reverse, reverse_lazy
from django.http import HttpResponseRedirect
from django.db.models import Sum, Count, Avg, Q
import random
import datetime
from django import forms

from parametros.models import tipoMedicamento
from parametros.models import tipoGenerico
from parametros.models import tipoAdministracion

#@[p_importmodelos_02]


from .forms import tipoMedicamentoForm
from .forms import tipoGenericoForm
from .forms import tipoAdministracionForm

#@[p_importforms_02]



# Create your views here.
class HomeView(TemplateView):
	template_name = 'parametros/home.html'

class ListartipoMedicamentoView(ListView):
#@[p_listar_tipoMedicamento_01]
	model = tipoMedicamento
#@[p_listar_tipoMedicamento_02]
	template_name = 'parametros/tipoMedicamento_list.html'
#@[p_listar_tipoMedicamento_03]

	def get_context_data(self,**kwargs):
#@[p_listar_context_tipoMedicamento_01]
		context = super(ListartipoMedicamentoView, self).get_context_data(**kwargs)
#@[p_listar_context_tipoMedicamento_02]
		return context

class EditartipoMedicamentoView(UpdateView):
#@[p_editar_tipoMedicamento_01]
	model = tipoMedicamento
	form_class = tipoMedicamentoForm
#@[p_editar_tipoMedicamento_02]
	template_name = 'parametros/tipoMedicamento_update_form.html'
#@[p_editar_tipoMedicamento_03]

	def get_success_url(self):
#@[p_editar_success_tipoMedicamento_01]
		return reverse_lazy('parametros:editar_tipoMedicamento', args=[self.object.id]) + '?correcto'

	def get_context_data(self,**kwargs):
#@[p_editar_context_tipoMedicamento_01]
		context = super(EditartipoMedicamentoView, self).get_context_data(**kwargs)
		tipoMedicamento = (self.object)
		context['tipoMedicamento_id'] = self.object.id
#@[p_editar_context_tipoMedicamento_02]

#@[p_editar_context_tipoMedicamento_03]
		context['nombre'] = tipoMedicamento.descripcion
		return context

class CreartipoMedicamentoView(CreateView):
#@[p_crear_tipoMedicamento_01]
	model = tipoMedicamento
	form_class = tipoMedicamentoForm
#@[p_crear_tipoMedicamento_02]
	template_name = 'parametros/tipoMedicamento_form.html'
#@[p_crear_tipoMedicamento_03]

	def get_success_url(self):
#@[p_crear_success_tipoMedicamento_01]
		return reverse_lazy('parametros:listar_tipoMedicamento') + '?correcto'
	def get_context_data(self,**kwargs):
#@[p_crear_successtipoMedicamento_02]
		context = super(CreartipoMedicamentoView, self).get_context_data(**kwargs)
#@[p_crear_successtipoMedicamento_03]
		return context

class BorrartipoMedicamentoView(DeleteView):
#@[p_borrar_tipoMedicamento_01]
	model = tipoMedicamento
#@[p_borrar_tipoMedicamento_02]
	template_name = 'parametros/tipoMedicamento_confirm_delete.html'
#@[p_borrar_tipoMedicamento_03]

	def get_success_url(self):
#@[p_borrar_success_tipoMedicamento_01]
		return reverse_lazy('parametros:listar_tipoMedicamento') + '?correcto'
	def get_context_data(self,**kwargs):
#@[p_borrar_context_tipoMedicamento_01]
		context = super(BorrartipoMedicamentoView, self).get_context_data(**kwargs)
		tipoMedicamento_borra_tipoMedicamento_borra = tipoMedicamento.objects.get(id=self.object.id)
		context['nombreborrar'] = tipoMedicamento_borra_tipoMedicamento_borra.descripcion
#@[p_borrar_context_tipoMedicamento_02]
		return context

class ListartipoGenericoView(ListView):
#@[p_listar_tipoGenerico_01]
	model = tipoGenerico
#@[p_listar_tipoGenerico_02]
	template_name = 'parametros/tipoGenerico_list.html'
#@[p_listar_tipoGenerico_03]

	def get_context_data(self,**kwargs):
#@[p_listar_context_tipoGenerico_01]
		context = super(ListartipoGenericoView, self).get_context_data(**kwargs)
#@[p_listar_context_tipoGenerico_02]
		return context

class EditartipoGenericoView(UpdateView):
#@[p_editar_tipoGenerico_01]
	model = tipoGenerico
	form_class = tipoGenericoForm
#@[p_editar_tipoGenerico_02]
	template_name = 'parametros/tipoGenerico_update_form.html'
#@[p_editar_tipoGenerico_03]

	def get_success_url(self):
#@[p_editar_success_tipoGenerico_01]
		return reverse_lazy('parametros:editar_tipoGenerico', args=[self.object.id]) + '?correcto'

	def get_context_data(self,**kwargs):
#@[p_editar_context_tipoGenerico_01]
		context = super(EditartipoGenericoView, self).get_context_data(**kwargs)
		tipoGenerico = (self.object)
		context['tipoGenerico_id'] = self.object.id
#@[p_editar_context_tipoGenerico_02]

#@[p_editar_context_tipoGenerico_03]
		context['nombre'] = tipoGenerico.descripcion
		return context

class CreartipoGenericoView(CreateView):
#@[p_crear_tipoGenerico_01]
	model = tipoGenerico
	form_class = tipoGenericoForm
#@[p_crear_tipoGenerico_02]
	template_name = 'parametros/tipoGenerico_form.html'
#@[p_crear_tipoGenerico_03]

	def get_success_url(self):
#@[p_crear_success_tipoGenerico_01]
		return reverse_lazy('parametros:listar_tipoGenerico') + '?correcto'
	def get_context_data(self,**kwargs):
#@[p_crear_successtipoGenerico_02]
		context = super(CreartipoGenericoView, self).get_context_data(**kwargs)
#@[p_crear_successtipoGenerico_03]
		return context

class BorrartipoGenericoView(DeleteView):
#@[p_borrar_tipoGenerico_01]
	model = tipoGenerico
#@[p_borrar_tipoGenerico_02]
	template_name = 'parametros/tipoGenerico_confirm_delete.html'
#@[p_borrar_tipoGenerico_03]

	def get_success_url(self):
#@[p_borrar_success_tipoGenerico_01]
		return reverse_lazy('parametros:listar_tipoGenerico') + '?correcto'
	def get_context_data(self,**kwargs):
#@[p_borrar_context_tipoGenerico_01]
		context = super(BorrartipoGenericoView, self).get_context_data(**kwargs)
		tipoGenerico_borra_tipoGenerico_borra = tipoGenerico.objects.get(id=self.object.id)
		context['nombreborrar'] = tipoGenerico_borra_tipoGenerico_borra.descripcion
#@[p_borrar_context_tipoGenerico_02]
		return context

class ListartipoAdministracionView(ListView):
#@[p_listar_tipoAdministracion_01]
	model = tipoAdministracion
#@[p_listar_tipoAdministracion_02]
	template_name = 'parametros/tipoAdministracion_list.html'
#@[p_listar_tipoAdministracion_03]

	def get_context_data(self,**kwargs):
#@[p_listar_context_tipoAdministracion_01]
		context = super(ListartipoAdministracionView, self).get_context_data(**kwargs)
#@[p_listar_context_tipoAdministracion_02]
		return context

class EditartipoAdministracionView(UpdateView):
#@[p_editar_tipoAdministracion_01]
	model = tipoAdministracion
	form_class = tipoAdministracionForm
#@[p_editar_tipoAdministracion_02]
	template_name = 'parametros/tipoAdministracion_update_form.html'
#@[p_editar_tipoAdministracion_03]

	def get_success_url(self):
#@[p_editar_success_tipoAdministracion_01]
		return reverse_lazy('parametros:editar_tipoAdministracion', args=[self.object.id]) + '?correcto'

	def get_context_data(self,**kwargs):
#@[p_editar_context_tipoAdministracion_01]
		context = super(EditartipoAdministracionView, self).get_context_data(**kwargs)
		tipoAdministracion = (self.object)
		context['tipoAdministracion_id'] = self.object.id
#@[p_editar_context_tipoAdministracion_02]

#@[p_editar_context_tipoAdministracion_03]
		context['nombre'] = tipoAdministracion.descripcion
		return context

class CreartipoAdministracionView(CreateView):
#@[p_crear_tipoAdministracion_01]
	model = tipoAdministracion
	form_class = tipoAdministracionForm
#@[p_crear_tipoAdministracion_02]
	template_name = 'parametros/tipoAdministracion_form.html'
#@[p_crear_tipoAdministracion_03]

	def get_success_url(self):
#@[p_crear_success_tipoAdministracion_01]
		return reverse_lazy('parametros:listar_tipoAdministracion') + '?correcto'
	def get_context_data(self,**kwargs):
#@[p_crear_successtipoAdministracion_02]
		context = super(CreartipoAdministracionView, self).get_context_data(**kwargs)
#@[p_crear_successtipoAdministracion_03]
		return context

class BorrartipoAdministracionView(DeleteView):
#@[p_borrar_tipoAdministracion_01]
	model = tipoAdministracion
#@[p_borrar_tipoAdministracion_02]
	template_name = 'parametros/tipoAdministracion_confirm_delete.html'
#@[p_borrar_tipoAdministracion_03]

	def get_success_url(self):
#@[p_borrar_success_tipoAdministracion_01]
		return reverse_lazy('parametros:listar_tipoAdministracion') + '?correcto'
	def get_context_data(self,**kwargs):
#@[p_borrar_context_tipoAdministracion_01]
		context = super(BorrartipoAdministracionView, self).get_context_data(**kwargs)
		tipoAdministracion_borra_tipoAdministracion_borra = tipoAdministracion.objects.get(id=self.object.id)
		context['nombreborrar'] = tipoAdministracion_borra_tipoAdministracion_borra.descripcion
#@[p_borrar_context_tipoAdministracion_02]
		return context


#@[p_modelospadre_02]




#@[p_modeloshijo_02]




