from django.urls import path
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required

from .views import HomeView
from .views import ListartipoMedicamentoView, CreartipoMedicamentoView, EditartipoMedicamentoView, BorrartipoMedicamentoView
from .views import ListartipoGenericoView, CreartipoGenericoView, EditartipoGenericoView, BorrartipoGenericoView
from .views import ListartipoAdministracionView, CreartipoAdministracionView, EditartipoAdministracionView, BorrartipoAdministracionView


#@[p_listaviews_01]

parametros_patterns = ([
	path('',(HomeView.as_view()), name='home'),
	path('listar_tipoMedicamento/',(ListartipoMedicamentoView.as_view()), name='listar_tipoMedicamento'),
	path('editar_tipoMedicamento/<int:pk>/',(EditartipoMedicamentoView.as_view()), name='editar_tipoMedicamento'),
	path('crear_tipoMedicamento/',(CreartipoMedicamentoView.as_view()), name='crear_tipoMedicamento'),
	path('borrar_tipoMedicamento/<int:pk>/',(BorrartipoMedicamentoView.as_view()), name='borrar_tipoMedicamento'),

	path('listar_tipoGenerico/',(ListartipoGenericoView.as_view()), name='listar_tipoGenerico'),
	path('editar_tipoGenerico/<int:pk>/',(EditartipoGenericoView.as_view()), name='editar_tipoGenerico'),
	path('crear_tipoGenerico/',(CreartipoGenericoView.as_view()), name='crear_tipoGenerico'),
	path('borrar_tipoGenerico/<int:pk>/',(BorrartipoGenericoView.as_view()), name='borrar_tipoGenerico'),

	path('listar_tipoAdministracion/',(ListartipoAdministracionView.as_view()), name='listar_tipoAdministracion'),
	path('editar_tipoAdministracion/<int:pk>/',(EditartipoAdministracionView.as_view()), name='editar_tipoAdministracion'),
	path('crear_tipoAdministracion/',(CreartipoAdministracionView.as_view()), name='crear_tipoAdministracion'),
	path('borrar_tipoAdministracion/<int:pk>/',(BorrartipoAdministracionView.as_view()), name='borrar_tipoAdministracion'),


#@[p_listaurls_01]
], 'parametros')

#@[p_views_01]

