from django.db import models
from ckeditor.fields import RichTextField
from django.core.exceptions import ValidationError
from django.utils.translation import ugettext_lazy as _
from django.urls import reverse, reverse_lazy
from django.utils import timezone
from django.contrib.auth.models import User


# Modelos Foreign



#@[p_foraneos_01]	

# Create your models here.

#@[p_modelos_01]

class tipoMedicamento(models.Model):

#@[p_propiedades_tipoMedicamento_01]

	descripcion = models.CharField(max_length=30,default='')

#@[p_propiedades_tipoMedicamento_02]

	def __str__(self):
#@[p_self_tipoMedicamento_01]
		return self.descripcion
#@[p_self_tipoMedicamento_02]

class tipoGenerico(models.Model):

#@[p_propiedades_tipoGenerico_01]

	descripcion = models.CharField(max_length=30)

#@[p_propiedades_tipoGenerico_02]

	def __str__(self):
#@[p_self_tipoGenerico_01]
		return self.descripcion
#@[p_self_tipoGenerico_02]

class tipoAdministracion(models.Model):

#@[p_propiedades_tipoAdministracion_01]

	descripcion = models.CharField(max_length=30,default='')

#@[p_propiedades_tipoAdministracion_02]

	def __str__(self):
#@[p_self_tipoAdministracion_01]
		return self.descripcion
#@[p_self_tipoAdministracion_02]



#@[p_modelos_02]	


