from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from parametros.models import tipoMedicamento
from parametros.models import tipoGenerico
from parametros.models import tipoAdministracion


#@[p_importmodelos_01]



#@[p_listachoices_01]

#@[p_forms_01]

class tipoMedicamentoForm(forms.ModelForm):
#@[p_Meta_tipoMedicamento_01]
	class Meta:
#@[p_Meta_tipoMedicamento_02]
		model = tipoMedicamento
#@[p_Meta_tipoMedicamento_03]
#@[p_fields_tipoMedicamento_01]
		fields = ('descripcion',)
#@[p_fields_tipoMedicamento_02]
#@[p_widgets_tipoMedicamento_01]
		widgets = {
#@[p_listawidgets_tipoMedicamento_01]
			'descripcion': forms.TextInput(attrs={'class':'form-control font_control_tipoMedicamento mt-1', 'placeholder': ''}),

#@[p_listawidgets_tipoMedicamento_02]
		}
#@[p_widgets_tipoMedicamento_02]
#@[p_labels_tipoMedicamento_01]
		labels = {
#@[p_listalabels_tipoMedicamento_01]
		'descripcion':'Descripcion',
#@[p_listalabels_tipoMedicamento_02]
		}
#@[p_labels_tipoMedicamento_02]
#@[p_reglas_tipoMedicamento_01]

#@[p_reglas_tipoMedicamento_02]

class tipoGenericoForm(forms.ModelForm):
#@[p_Meta_tipoGenerico_01]
	class Meta:
#@[p_Meta_tipoGenerico_02]
		model = tipoGenerico
#@[p_Meta_tipoGenerico_03]
#@[p_fields_tipoGenerico_01]
		fields = ('descripcion',)
#@[p_fields_tipoGenerico_02]
#@[p_widgets_tipoGenerico_01]
		widgets = {
#@[p_listawidgets_tipoGenerico_01]
			'descripcion': forms.TextInput(attrs={'class':'form-control font_control_tipoGenerico mt-1', 'placeholder': ''}),

#@[p_listawidgets_tipoGenerico_02]
		}
#@[p_widgets_tipoGenerico_02]
#@[p_labels_tipoGenerico_01]
		labels = {
#@[p_listalabels_tipoGenerico_01]
		'descripcion':'Descripcion',
#@[p_listalabels_tipoGenerico_02]
		}
#@[p_labels_tipoGenerico_02]
#@[p_reglas_tipoGenerico_01]

#@[p_reglas_tipoGenerico_02]

class tipoAdministracionForm(forms.ModelForm):
#@[p_Meta_tipoAdministracion_01]
	class Meta:
#@[p_Meta_tipoAdministracion_02]
		model = tipoAdministracion
#@[p_Meta_tipoAdministracion_03]
#@[p_fields_tipoAdministracion_01]
		fields = ('descripcion',)
#@[p_fields_tipoAdministracion_02]
#@[p_widgets_tipoAdministracion_01]
		widgets = {
#@[p_listawidgets_tipoAdministracion_01]
			'descripcion': forms.TextInput(attrs={'class':'form-control font_control_tipoAdministracion mt-1', 'placeholder': ''}),

#@[p_listawidgets_tipoAdministracion_02]
		}
#@[p_widgets_tipoAdministracion_02]
#@[p_labels_tipoAdministracion_01]
		labels = {
#@[p_listalabels_tipoAdministracion_01]
		'descripcion':'Descripcion',
#@[p_listalabels_tipoAdministracion_02]
		}
#@[p_labels_tipoAdministracion_02]
#@[p_reglas_tipoAdministracion_01]

#@[p_reglas_tipoAdministracion_02]





