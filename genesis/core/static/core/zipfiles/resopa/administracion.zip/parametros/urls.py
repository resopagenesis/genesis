from django.urls import path
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required

from .views import HomeView
from .views import ListarcentroView, CrearcentroView, EditarcentroView, BorrarcentroView, ReportecentroView




parametros_patterns = ([
	path('',(HomeView.as_view()), name='home'),
	path('listar_centro/',(ListarcentroView.as_view()), name='listar_centro'),
	path('reporte_centro/',ReportecentroView, name='reporte_centro'),
	path('editar_centro/<int:pk>/',(EditarcentroView.as_view()), name='editar_centro'),
	path('crear_centro/',(CrearcentroView.as_view()), name='crear_centro'),
	path('borrar_centro/<int:pk>/',(BorrarcentroView.as_view()), name='borrar_centro'),



], 'parametros')

