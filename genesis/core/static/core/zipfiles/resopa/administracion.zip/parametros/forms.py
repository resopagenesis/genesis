from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from parametros.models import centro







class centroForm(forms.ModelForm):
	class Meta:
		model = centro
		fields = ('codigo',)
		widgets = {
			'codigo': forms.TextInput(attrs={'class':'form-control font_control_centro mt-1', 'placeholder': ''}),

		}
		labels = {
		'codigo':'Codigo',
		}





