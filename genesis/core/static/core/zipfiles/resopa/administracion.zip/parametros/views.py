from django.shortcuts import render
from django.views.generic.list import ListView
from django.views.generic.edit import CreateView, UpdateView, DeleteView, FormView
from django.views.generic.base import TemplateView
from django.urls import reverse, reverse_lazy
from django.http import HttpResponseRedirect
from django.db.models import Sum, Count, Avg, Q
import random
import datetime
from django import forms
import time
import os

# Reporte

from core.views import Reporte
from reportlab.lib.pagesizes import letter,landscape,portrait,A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch, mm, cm
from reportlab.lib import colors


from parametros.models import centro




from .forms import centroForm




# Create your views here.
class HomeView(TemplateView):
	template_name = 'parametros/home.html'

# Este modelo es independiente por lo que
# se elabora una lista de sus registros
class ListarcentroView(ListView):
	# Definir el modelo a utilizar
	model = centro
	# Especificar el template HTML
	template_name = 'parametros/centro_list.html'

	# Prepara los context para el HTML
	def get_context_data(self,**kwargs):
		context = super(ListarcentroView, self).get_context_data(**kwargs)
		context['lista'] = centro.objects.all()
		return context

# Este modelo es independiente y esta vista
# es la utilizada para la edicion de un registro
# ya grabado en la Base de Datos
class EditarcentroView(UpdateView):
	# Define el modelo
	model = centro
	# Define el formulario
	form_class = centroForm
	# Define el HTML de edicion
	template_name = 'parametros/centro_update_form.html'

	# Procedimiento de salida despues de actualizacion exitosa
	def get_success_url(self):
		# Retorna al HTML de edicion con la comunicacion de correcta actualizacion
		return reverse_lazy('parametros:editar_centro', args=[self.object.id]) + '?correcto'

	# Prepara los context para el HTML de edicion
	def get_context_data(self,**kwargs):
		context = super(EditarcentroView, self).get_context_data(**kwargs)
		# Recupera el modelo a ser editado y envia su id
		centro = (self.object)
		context['centro_id'] = self.object.id

		# Envia el context con la identificacion que se dio al borrado
		context['nombre'] = centro.codigo
		return context

# Este modelo es independiente y esta vista
# es la utilizada para la insercion de un nuevo registro
# en la Base de Datos
class CrearcentroView(CreateView):
	# Define el modelo cuyo registro se inserta
	model = centro
	# Define el formulario de controles
	form_class = centroForm
	# Define el HTML de insercion
	template_name = 'parametros/centro_form.html'

	# Procedimiento de retorno por insercion exitosa
	def get_success_url(self):
		# Retorna al HTML de la lista de registros del modelo
		return reverse_lazy('parametros:listar_centro') + '?correcto'
	# Prepara los context de insercion
	def get_context_data(self,**kwargs):
		context = super(CrearcentroView, self).get_context_data(**kwargs)
		return context

# Este modelo es independiente y esta vista
# es la utilizada para el borrado de un registro
# ya grabado en la Base de Datos
class BorrarcentroView(DeleteView):
	# Define le modelo a borrar
	model = centro
	# Define el HTML de borrado
	template_name = 'parametros/centro_confirm_delete.html'

	# Procedimiento de retorno por borrado exitoso
	def get_success_url(self):
		# Retorna al HTML de lista de registros del modelo
		return reverse_lazy('parametros:listar_centro') + '?correcto'
	# Prepara los context de borrado
	def get_context_data(self,**kwargs):
		context = super(BorrarcentroView, self).get_context_data(**kwargs)
		# Recupera el modelo a borrar y envia su id
		centro_borra_centro_borra = centro.objects.get(id=self.object.id)
		context['nombreborrar'] = centro_borra_centro_borra.codigo
		return context

def ReportecentroView(request):

    # Variables del proyecto para el reporte
    primeralinea = 24.50
    maxlineas = 44

    numeroLineas = 0
    salto = 0
    pagina = 1
    
    # Lista de transferencia
    datos_detalle = []

    # Variables de reporte
    datos_reporte = []
    datos_reporte.append(numeroLineas)
    datos_reporte.append(salto)
    datos_reporte.append(pagina)
    datos_reporte.append(maxlineas)

    # Control de titulos por modelos
    primer_centro = True




    for reg_centro in centro.objects.all():
        if primer_centro:
            datos_titulo = []
            datos_titulo.append(['Lista de registros',10.50])
            datos_titulo.append([True,10.50])
            datos_titulo.append(1.00)
            datos_titulo.append(20.50)
            datos_titulo.append(0.30)
            datos_titulo.append([1.50,'codigo'])
            Acomoda(datos_detalle,datos_reporte,primeralinea,True,datos_titulo)
            primer_centro=False
        datos_reporte[0] += 1
        Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
        datos_detalle.append([1,['Helvetica',9,colors.black],[1.50,primeralinea-datos_reporte[1]],str(reg_centro.codigo),'l'])
        datos_reporte[1] += 0.4
    if not primer_centro:
        datos_reporte[0] += 2
        Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
        datos_detalle.append([4,[1.00,primeralinea-datos_reporte[1]+0.2,20.50,primeralinea-datos_reporte[1]+0.2,0.3]])
        datos_detalle.append([4,[1.00,primeralinea-datos_reporte[1]+0.15,20.50,primeralinea-datos_reporte[1]+0.15,0.3]])
        datos_reporte[1] += 0.8


    plan = Reporte("centro.pdf",letter,'portrait',datos_detalle)
    plan.detalle()
    plan.grabar()
    return HttpResponseRedirect('/parametros/listar_centro')

# def Acomoda(datos,datos_reporte,primeralinea,titulo=False,datos_titulo=[]):

#     numeroLineas = datos_reporte[0]
#     pagina = datos_reporte[2]
#     salto = datos_reporte[1]
#     maxlineas = datos_reporte[3]

#     nuevapagina = False
#     if pagina == 1:
#         # encabezado
#         Encabezado(datos,pagina)
#         salto = 0
#         pagina += 1
#     if numeroLineas == maxlineas:
#         nuevapagina = True
#         numeroLineas = 0
#         maxlineas = 50
#         datos.append([0])
#     if nuevapagina:
#         # encabezado
#         Encabezado(datos,pagina)
#         salto = 0
#         pass
#     if titulo:
#         datos.append([1,['Helvetica-Bold',9,colors.black],[datos_titulo[0][1],primeralinea-salto],datos_titulo[0][0],'c'])
#         numeroLineas += 1
#         salto += 0.4
#         # Fecha
#         if datos_titulo[1][0]:
#             datos.append([3,['Helvetica',8,colors.red],[datos_titulo[1][1],primeralinea-salto],'c'])
#             salto += 0.5
#             numeroLineas += 1
#         # Linea superior de columnas
#         datos.append([4,[datos_titulo[2],primeralinea-salto,datos_titulo[3],primeralinea-salto,datos_titulo[4]]])    
#         salto += 0.4
#         # Columnas
#         pos = 0
#         for col in range(0,len(datos_titulo[5]),2):
#             datos.append([1,['Helvetica-Bold',9,colors.black],[datos_titulo[5][col],primeralinea-salto],datos_titulo[5][col+1],'l'])
#             pos+=2
#         salto += 0.2
#         # Linea inferior de columnas
#         datos.append([4,[datos_titulo[2],primeralinea-salto,datos_titulo[3],primeralinea-salto,datos_titulo[4]]])    
#         numeroLineas += 2
#         salto += 0.5

#     datos_reporte[0] =  numeroLineas
#     datos_reporte[1] = salto 
#     datos_reporte[2] = pagina 
#     datos_reporte[3] = maxlineas 

# def Encabezado(datos,pagina):

#     anchologo=1.50
#     altologo=1.50
#     posxlogo=1.00
#     posylogo=25.70
#     posxnombre=15.00
#     posynombre=26.00
#     iniciolineax=1.00
#     finallineax=20.50
#     iniciolineay=25.30
#     grosorlinea=0.90
#     piex=20.50
#     piey=1.00
#     lineapiex = 20.50
#     lineapiey=1.70
#     nombre = administracion

#     logo = None
#     try:
#         cd = os.getcwd()
#         logo = cd + '/core/static/core/img/logo.png'
#     except:
#         pass     

#     datos.append([2,logo,[posxlogo,posylogo],[anchologo,altologo]])       
#     datos.append([1,['Helvetica',20,colors.black],[posxnombre,posynombre],nombre,'c'])
#     datos.append([4,[iniciolineax,iniciolineay,finallineax, iniciolineay,grosorlinea]])
#     # Pie
#     datos.append([1,['Helvetica',8,colors.black],[piex,piey],'Pag. ' + str(pagina),'c'])
#     datos.append([4,[iniciolineax,lineapiey,lineapiex,lineapiey,grosorlinea]])    










# General de Reportes
def Acomoda(datos,datos_reporte,primeralinea,titulo=False,datos_titulo=[]):

    numeroLineas = datos_reporte[0]
    pagina = datos_reporte[2]
    salto = datos_reporte[1]
    maxlineas = datos_reporte[3]

    nuevapagina = False
    if pagina == 1:
        # encabezado
        Encabezado(datos,pagina)
        salto = 0
        pagina += 1
    if numeroLineas >= maxlineas:
        nuevapagina = True
        numeroLineas = 0
        maxlineas = 50
        datos.append([0])
    if nuevapagina:
        # encabezado
        Encabezado(datos,pagina)
        salto = 0
        pass
    if titulo:
        numeroLineas += 1
        salto += 0.5    	
        datos.append([1,['Helvetica-Bold',9,colors.black],[datos_titulo[0][1],primeralinea-salto],datos_titulo[0][0],'c'])
        numeroLineas += 1
        salto += 0.4
        # Fecha
        if datos_titulo[1][0]:
            datos.append([3,['Helvetica',8,colors.red],[datos_titulo[1][1],primeralinea-salto],'c'])
            salto += 0.5
            numeroLineas += 1
        # Linea superior de columnas
        datos.append([4,[datos_titulo[2],primeralinea-salto,datos_titulo[3],primeralinea-salto,datos_titulo[4]]])    
        salto += 0.4
        # Columnas
        pos = 0
        for col in range(0,len(datos_titulo[5]),2):
            datos.append([1,['Helvetica-Bold',9,colors.black],[datos_titulo[5][col],primeralinea-salto],datos_titulo[5][col+1],'l'])
            pos+=2
        salto += 0.2
        # Linea inferior de columnas
        datos.append([4,[datos_titulo[2],primeralinea-salto,datos_titulo[3],primeralinea-salto,datos_titulo[4]]])    
        numeroLineas += 2
        salto += 0.5

    datos_reporte[0] =  numeroLineas
    datos_reporte[1] = salto 
    datos_reporte[2] = pagina 
    datos_reporte[3] = maxlineas 

def Encabezado(datos,pagina):

    anchologo=1.50
    altologo=1.50
    posxlogo=1.00
    posylogo=25.70
    posxnombre=15.00
    posynombre=26.00
    iniciolineax=1.00
    finallineax=20.50
    iniciolineay=25.30
    grosorlinea=0.90
    piex=20.50
    piey=1.00
    lineapiex = 20.50
    lineapiey=1.70
    nombre = 'administracion'

    logo = None
    try:
        cd = os.getcwd()
        logo = cd + '/core/static/core/img/logo.png'
    except:
        pass     

    datos.append([2,logo,[posxlogo,posylogo],[anchologo,altologo]])       
    datos.append([1,['Helvetica',20,colors.black],[posxnombre,posynombre],nombre,'c'])
    datos.append([4,[iniciolineax,iniciolineay,finallineax, iniciolineay,grosorlinea]])
    # Pie
    datos.append([1,['Helvetica',8,colors.black],[piex,piey],'Pag. ' + str(pagina),'c'])
    datos.append([4,[iniciolineax,lineapiey,lineapiex,lineapiey,grosorlinea]])    
