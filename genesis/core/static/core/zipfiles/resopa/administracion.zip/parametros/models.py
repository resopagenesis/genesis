from django.db import models
from ckeditor.fields import RichTextField
from django.core.exceptions import ValidationError
from django.utils.translation import ugettext_lazy as _
from django.urls import reverse, reverse_lazy
from django.utils import timezone
from django.contrib.auth.models import User


# Modelos Foreign




# Crear los modelo aqui.


class centro(models.Model):


	codigo = models.CharField(max_length=5,default='')


	def __str__(self):
		return self.codigo



