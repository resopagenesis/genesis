from django.shortcuts import render
from django.views.generic.list import ListView
from django.views.generic.edit import CreateView, UpdateView, DeleteView, FormView
from django.views.generic.base import TemplateView
from django.urls import reverse, reverse_lazy
from django.http import HttpResponseRedirect
from django.db.models import Sum, Count, Avg, Q
import random
import datetime
from django import forms
import time
import os

# Reporte

from core.views import Reporte
from reportlab.lib.pagesizes import letter,landscape,portrait,A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch, mm, cm
from reportlab.lib import colors


from contabilidad.models import cuenta
from contabilidad.models import asiento
from contabilidad.models import comprobante
from contabilidad.models import comprobante
from contabilidad.models import centrocosto
from contabilidad.models import presupuesto
from contabilidad.models import comprobante
from contabilidad.models import asiento
from contabilidad.models import centrocosto
from contabilidad.models import comprobante
from contabilidad.models import asiento
from contabilidad.models import asiento
from contabilidad.models import comprobante
from contabilidad.models import presupuesto
from contabilidad.models import comprobante
from contabilidad.models import asiento
from contabilidad.models import asiento
from contabilidad.models import comprobante




from .forms import cuentaForm
from .forms import asientoForm
from .forms import comprobanteForm
from .forms import centrocostoForm
from .forms import presupuestoForm




# Create your views here.
class HomeView(TemplateView):
	template_name = 'contabilidad/home.html'

# Este modelo es independiente por lo que
# se elabora una lista de sus registros
class ListarcuentaView(ListView):
	# Definir el modelo a utilizar
	model = cuenta
	# Especificar el template HTML
	template_name = 'contabilidad/cuenta_list.html'

	# Prepara los context para el HTML
	def get_context_data(self,**kwargs):
		context = super(ListarcuentaView, self).get_context_data(**kwargs)
		context['lista'] = cuenta.objects.all()
		return context

# Este modelo es independiente y esta vista
# es la utilizada para la edicion de un registro
# ya grabado en la Base de Datos
class EditarcuentaView(UpdateView):
	# Define el modelo
	model = cuenta
	# Define el formulario
	form_class = cuentaForm
	# Define el HTML de edicion
	template_name = 'contabilidad/cuenta_update_form.html'

	# Procedimiento de salida despues de actualizacion exitosa
	def get_success_url(self):
		# Retorna al HTML de edicion con la comunicacion de correcta actualizacion
		return reverse_lazy('contabilidad:editar_cuenta', args=[self.object.id]) + '?correcto'

	# Prepara los context para el HTML de edicion
	def get_context_data(self,**kwargs):
		context = super(EditarcuentaView, self).get_context_data(**kwargs)
		# Recupera el modelo a ser editado y envia su id
		cuenta = (self.object)
		context['cuenta_id'] = self.object.id

		# Envia el context con la identificacion que se dio al borrado
		context['nombre'] = cuenta.codigo
		return context

# Este modelo es independiente y esta vista
# es la utilizada para la insercion de un nuevo registro
# en la Base de Datos
class CrearcuentaView(CreateView):
	# Define el modelo cuyo registro se inserta
	model = cuenta
	# Define el formulario de controles
	form_class = cuentaForm
	# Define el HTML de insercion
	template_name = 'contabilidad/cuenta_form.html'

	# Procedimiento de retorno por insercion exitosa
	def get_success_url(self):
		# Retorna al HTML de la lista de registros del modelo
		return reverse_lazy('contabilidad:listar_cuenta') + '?correcto'
	# Prepara los context de insercion
	def get_context_data(self,**kwargs):
		context = super(CrearcuentaView, self).get_context_data(**kwargs)
		return context

# Este modelo es independiente y esta vista
# es la utilizada para el borrado de un registro
# ya grabado en la Base de Datos
class BorrarcuentaView(DeleteView):
	# Define le modelo a borrar
	model = cuenta
	# Define el HTML de borrado
	template_name = 'contabilidad/cuenta_confirm_delete.html'

	# Procedimiento de retorno por borrado exitoso
	def get_success_url(self):
		# Retorna al HTML de lista de registros del modelo
		return reverse_lazy('contabilidad:listar_cuenta') + '?correcto'
	# Prepara los context de borrado
	def get_context_data(self,**kwargs):
		context = super(BorrarcuentaView, self).get_context_data(**kwargs)
		# Recupera el modelo a borrar y envia su id
		cuenta_borra_cuenta_borra = cuenta.objects.get(id=self.object.id)
		context['nombreborrar'] = cuenta_borra_cuenta_borra.codigo
		return context

def ReportecuentaView(request):

    # Variables del proyecto para el reporte
    primeralinea = 24.50
    maxlineas = 44

    numeroLineas = 0
    salto = 0
    pagina = 1
    
    # Lista de transferencia
    datos_detalle = []

    # Variables de reporte
    datos_reporte = []
    datos_reporte.append(numeroLineas)
    datos_reporte.append(salto)
    datos_reporte.append(pagina)
    datos_reporte.append(maxlineas)

    # Control de titulos por modelos
    primer_cuenta = True




    for reg_cuenta in cuenta.objects.all():
        if primer_cuenta:
            datos_titulo = []
            datos_titulo.append(['Lista de registros',10.50])
            datos_titulo.append([True,10.50])
            datos_titulo.append(1.00)
            datos_titulo.append(20.50)
            datos_titulo.append(0.30)
            datos_titulo.append([1.50,'codigo',4.50,'Descripcion',9.00,'foto'])
            Acomoda(datos_detalle,datos_reporte,primeralinea,True,datos_titulo)
            primer_cuenta=False
        datos_reporte[0] += 1
        Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
        datos_detalle.append([1,['Helvetica',9,colors.black],[1.50,primeralinea-datos_reporte[1]],str(reg_cuenta.codigo),'l'])
        datos_detalle.append([1,['Helvetica',9,colors.black],[4.50,primeralinea-datos_reporte[1]],str(reg_cuenta.Descripcion),'l'])
        try:
            cd = os.getcwd()
            img = cd + '/' + reg_cuenta.foto.url
        except:
            pass
        datos_detalle.append([8,img,[9.00,primeralinea-datos_reporte[1]],[1/2.5,1/2.5]])
        datos_reporte[1] += 0.4
    if not primer_cuenta:
        datos_reporte[0] += 2
        Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
        datos_detalle.append([4,[1.00,primeralinea-datos_reporte[1]+0.2,20.50,primeralinea-datos_reporte[1]+0.2,0.3]])
        datos_detalle.append([4,[1.00,primeralinea-datos_reporte[1]+0.15,20.50,primeralinea-datos_reporte[1]+0.15,0.3]])
        datos_reporte[1] += 0.8


    plan = Reporte("cuenta.pdf",letter,'portrait',datos_detalle)
    plan.detalle()
    plan.grabar()
    return HttpResponseRedirect('/contabilidad/listar_cuenta')

# def Acomoda(datos,datos_reporte,primeralinea,titulo=False,datos_titulo=[]):

#     numeroLineas = datos_reporte[0]
#     pagina = datos_reporte[2]
#     salto = datos_reporte[1]
#     maxlineas = datos_reporte[3]

#     nuevapagina = False
#     if pagina == 1:
#         # encabezado
#         Encabezado(datos,pagina)
#         salto = 0
#         pagina += 1
#     if numeroLineas == maxlineas:
#         nuevapagina = True
#         numeroLineas = 0
#         maxlineas = 50
#         datos.append([0])
#     if nuevapagina:
#         # encabezado
#         Encabezado(datos,pagina)
#         salto = 0
#         pass
#     if titulo:
#         datos.append([1,['Helvetica-Bold',9,colors.black],[datos_titulo[0][1],primeralinea-salto],datos_titulo[0][0],'c'])
#         numeroLineas += 1
#         salto += 0.4
#         # Fecha
#         if datos_titulo[1][0]:
#             datos.append([3,['Helvetica',8,colors.red],[datos_titulo[1][1],primeralinea-salto],'c'])
#             salto += 0.5
#             numeroLineas += 1
#         # Linea superior de columnas
#         datos.append([4,[datos_titulo[2],primeralinea-salto,datos_titulo[3],primeralinea-salto,datos_titulo[4]]])    
#         salto += 0.4
#         # Columnas
#         pos = 0
#         for col in range(0,len(datos_titulo[5]),2):
#             datos.append([1,['Helvetica-Bold',9,colors.black],[datos_titulo[5][col],primeralinea-salto],datos_titulo[5][col+1],'l'])
#             pos+=2
#         salto += 0.2
#         # Linea inferior de columnas
#         datos.append([4,[datos_titulo[2],primeralinea-salto,datos_titulo[3],primeralinea-salto,datos_titulo[4]]])    
#         numeroLineas += 2
#         salto += 0.5

#     datos_reporte[0] =  numeroLineas
#     datos_reporte[1] = salto 
#     datos_reporte[2] = pagina 
#     datos_reporte[3] = maxlineas 

# def Encabezado(datos,pagina):

#     anchologo=1.50
#     altologo=1.50
#     posxlogo=1.00
#     posylogo=25.70
#     posxnombre=15.00
#     posynombre=26.00
#     iniciolineax=1.00
#     finallineax=20.50
#     iniciolineay=25.30
#     grosorlinea=0.90
#     piex=20.50
#     piey=1.00
#     lineapiex = 20.50
#     lineapiey=1.70
#     nombre = administracion

#     logo = None
#     try:
#         cd = os.getcwd()
#         logo = cd + '/core/static/core/img/logo.png'
#     except:
#         pass     

#     datos.append([2,logo,[posxlogo,posylogo],[anchologo,altologo]])       
#     datos.append([1,['Helvetica',20,colors.black],[posxnombre,posynombre],nombre,'c'])
#     datos.append([4,[iniciolineax,iniciolineay,finallineax, iniciolineay,grosorlinea]])
#     # Pie
#     datos.append([1,['Helvetica',8,colors.black],[piex,piey],'Pag. ' + str(pagina),'c'])
#     datos.append([4,[iniciolineax,lineapiey,lineapiex,lineapiey,grosorlinea]])    
# Este modelo es independiente por lo que
# se elabora una lista de sus registros
class ListarcomprobanteView(ListView):
	# Definir el modelo a utilizar
	model = comprobante
	# Especificar el template HTML
	template_name = 'contabilidad/comprobante_list.html'

	# Prepara los context para el HTML
	def get_context_data(self,**kwargs):
		context = super(ListarcomprobanteView, self).get_context_data(**kwargs)
		context['lista'] = comprobante.objects.all()
		return context

# Este modelo es independiente y esta vista
# es la utilizada para la edicion de un registro
# ya grabado en la Base de Datos
class EditarcomprobanteView(UpdateView):
	# Define el modelo
	model = comprobante
	# Define el formulario
	form_class = comprobanteForm
	# Define el HTML de edicion
	template_name = 'contabilidad/comprobante_update_form.html'

	# Procedimiento de salida despues de actualizacion exitosa
	def get_success_url(self):
		# Retorna al HTML de edicion con la comunicacion de correcta actualizacion
		return reverse_lazy('contabilidad:editar_comprobante', args=[self.object.id]) + '?correcto'

	# Prepara los context para el HTML de edicion
	def get_context_data(self,**kwargs):
		context = super(EditarcomprobanteView, self).get_context_data(**kwargs)
		# Recupera el modelo a ser editado y envia su id
		comprobante = (self.object)
		context['comprobante_id'] = self.object.id
		asiento_lista = asiento.objects.filter(comprobante = comprobante)
		context['listaasiento'] =  asiento_lista

		# Envia el context con la identificacion que se dio al borrado
		context['nombre'] = comprobante.numero
		# Envia el cotext con el numero de modelos dependientes
		context['numeroasiento'] = asiento.objects.filter(comprobante=comprobante).count()
		return context

# Este modelo es independiente y esta vista
# es la utilizada para la insercion de un nuevo registro
# en la Base de Datos
class CrearcomprobanteView(CreateView):
	# Define el modelo cuyo registro se inserta
	model = comprobante
	# Define el formulario de controles
	form_class = comprobanteForm
	# Define el HTML de insercion
	template_name = 'contabilidad/comprobante_form.html'

	# Procedimiento de retorno por insercion exitosa
	def get_success_url(self):
		# Retorna al HTML de la lista de registros del modelo
		return reverse_lazy('contabilidad:listar_comprobante') + '?correcto'
	# Prepara los context de insercion
	def get_context_data(self,**kwargs):
		context = super(CrearcomprobanteView, self).get_context_data(**kwargs)
		return context

# Este modelo es independiente y esta vista
# es la utilizada para el borrado de un registro
# ya grabado en la Base de Datos
class BorrarcomprobanteView(DeleteView):
	# Define le modelo a borrar
	model = comprobante
	# Define el HTML de borrado
	template_name = 'contabilidad/comprobante_confirm_delete.html'

	# Procedimiento de retorno por borrado exitoso
	def get_success_url(self):
		# Retorna al HTML de lista de registros del modelo
		return reverse_lazy('contabilidad:listar_comprobante') + '?correcto'
	# Prepara los context de borrado
	def get_context_data(self,**kwargs):
		context = super(BorrarcomprobanteView, self).get_context_data(**kwargs)
		# Recupera el modelo a borrar y envia su id
		comprobante_borra_comprobante_borra = comprobante.objects.get(id=self.object.id)
		context['nombreborrar'] = comprobante_borra_comprobante_borra.numero
		return context

def ReportecomprobanteView(request):

    # Variables del proyecto para el reporte
    primeralinea = 24.50
    maxlineas = 44

    numeroLineas = 0
    salto = 0
    pagina = 1
    
    # Lista de transferencia
    datos_detalle = []

    # Variables de reporte
    datos_reporte = []
    datos_reporte.append(numeroLineas)
    datos_reporte.append(salto)
    datos_reporte.append(pagina)
    datos_reporte.append(maxlineas)

    # Control de titulos por modelos
    primer_comprobante = True
    primer_asiento = True
    primer_centrocosto = True
    primer_presupuesto = True




    for reg_comprobante in comprobante.objects.all():
        if primer_comprobante:
            datos_titulo = []
            datos_titulo.append(['Lista de Comprobantes',10.50])
            datos_titulo.append([True,10.50])
            datos_titulo.append(1.00)
            datos_titulo.append(20.50)
            datos_titulo.append(0.30)
            datos_titulo.append([1.50,'numero',4.50,'glosa'])
            Acomoda(datos_detalle,datos_reporte,primeralinea,True,datos_titulo)
            primer_comprobante=False
        primer_asiento=True
        datos_reporte[0] += 1
        Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
        datos_detalle.append([1,['Helvetica',9,colors.black],[1.50,primeralinea-datos_reporte[1]],str(reg_comprobante.numero),'l'])
        datos_detalle.append([1,['Helvetica',9,colors.black],[4.50,primeralinea-datos_reporte[1]],str(reg_comprobante.glosa),'l'])
        datos_reporte[1] += 0.4
        for reg_asiento in asiento.objects.filter(comprobante=reg_comprobante):
            if primer_asiento:
                datos_titulo = []
                datos_titulo.append(['Lista de Asientos',11.50])
                datos_titulo.append([False,11.50])
                datos_titulo.append(2.00)
                datos_titulo.append(20.50)
                datos_titulo.append(0.30)
                datos_titulo.append([2.50,'cuenta',5.50,'debe',10.00,'fecha'])
                Acomoda(datos_detalle,datos_reporte,primeralinea,True,datos_titulo)
                primer_asiento=False
            primer_centrocosto=True
            primer_presupuesto=True
            datos_reporte[0] += 1
            Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
            datos_detalle.append([1,['Helvetica',9,colors.black],[2.50,primeralinea-datos_reporte[1]],str(reg_asiento.cuenta),'l'])
            datos_detalle.append([1,['Helvetica',9,colors.black],[4.50,primeralinea-datos_reporte[1]],str(reg_asiento.debe),'l'])
            datos_detalle.append([1,['Helvetica',9,colors.black],[8.00,primeralinea-datos_reporte[1]],str(reg_asiento.fecha),'l'])
            datos_reporte[1] += 0.4
            for reg_centrocosto in centrocosto.objects.filter(asiento=reg_asiento):
                if primer_centrocosto:
                    datos_titulo = []
                    datos_titulo.append(['Lista de Centros de Costo',12.50])
                    datos_titulo.append([False,12.50])
                    datos_titulo.append(3.00)
                    datos_titulo.append(20.50)
                    datos_titulo.append(0.30)
                    datos_titulo.append([3.50,'centro',6.50,'importe'])
                    Acomoda(datos_detalle,datos_reporte,primeralinea,True,datos_titulo)
                    primer_centrocosto=False
                datos_reporte[0] += 1
                Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
                datos_detalle.append([1,['Helvetica',9,colors.black],[3.50,primeralinea-datos_reporte[1]],str(reg_centrocosto.centro),'l'])
                datos_detalle.append([1,['Helvetica',9,colors.black],[6.50,primeralinea-datos_reporte[1]],str(reg_centrocosto.importe),'l'])
                datos_reporte[1] += 0.4
            if not primer_centrocosto:
                datos_reporte[0] += 2
                Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
                datos_detalle.append([4,[3.00,primeralinea-datos_reporte[1]+0.2,20.50,primeralinea-datos_reporte[1]+0.2,0.3]])
                datos_detalle.append([4,[3.00,primeralinea-datos_reporte[1]+0.15,20.50,primeralinea-datos_reporte[1]+0.15,0.3]])
                datos_reporte[1] += 0.8
            for reg_presupuesto in presupuesto.objects.filter(asiento=reg_asiento):
                if primer_presupuesto:
                    datos_titulo = []
                    datos_titulo.append(['Lista de los Presupuestos',12.50])
                    datos_titulo.append([False,12.50])
                    datos_titulo.append(3.00)
                    datos_titulo.append(20.50)
                    datos_titulo.append(0.30)
                    datos_titulo.append([3.50,'fecha'])
                    Acomoda(datos_detalle,datos_reporte,primeralinea,True,datos_titulo)
                    primer_presupuesto=False
                datos_reporte[0] += 1
                Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
                datos_detalle.append([1,['Helvetica',9,colors.black],[3.50,primeralinea-datos_reporte[1]],str(reg_presupuesto.fecha),'l'])
                datos_reporte[1] += 0.4
            if not primer_presupuesto:
                datos_reporte[0] += 2
                Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
                datos_detalle.append([4,[3.00,primeralinea-datos_reporte[1]+0.2,20.50,primeralinea-datos_reporte[1]+0.2,0.3]])
                datos_detalle.append([4,[3.00,primeralinea-datos_reporte[1]+0.15,20.50,primeralinea-datos_reporte[1]+0.15,0.3]])
                datos_reporte[1] += 0.8
        if not primer_asiento:
            datos_reporte[0] += 2
            Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
            datos_detalle.append([4,[2.00,primeralinea-datos_reporte[1]+0.2,20.50,primeralinea-datos_reporte[1]+0.2,0.3]])
            datos_detalle.append([4,[2.00,primeralinea-datos_reporte[1]+0.15,20.50,primeralinea-datos_reporte[1]+0.15,0.3]])
            datos_reporte[1] += 0.8
    if not primer_comprobante:
        datos_reporte[0] += 2
        Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
        datos_detalle.append([4,[1.00,primeralinea-datos_reporte[1]+0.2,20.50,primeralinea-datos_reporte[1]+0.2,0.3]])
        datos_detalle.append([4,[1.00,primeralinea-datos_reporte[1]+0.15,20.50,primeralinea-datos_reporte[1]+0.15,0.3]])
        datos_reporte[1] += 0.8


    plan = Reporte("comprobante.pdf",letter,'portrait',datos_detalle)
    plan.detalle()
    plan.grabar()
    return HttpResponseRedirect('/contabilidad/listar_comprobante')

# def Acomoda(datos,datos_reporte,primeralinea,titulo=False,datos_titulo=[]):

#     numeroLineas = datos_reporte[0]
#     pagina = datos_reporte[2]
#     salto = datos_reporte[1]
#     maxlineas = datos_reporte[3]

#     nuevapagina = False
#     if pagina == 1:
#         # encabezado
#         Encabezado(datos,pagina)
#         salto = 0
#         pagina += 1
#     if numeroLineas == maxlineas:
#         nuevapagina = True
#         numeroLineas = 0
#         maxlineas = 50
#         datos.append([0])
#     if nuevapagina:
#         # encabezado
#         Encabezado(datos,pagina)
#         salto = 0
#         pass
#     if titulo:
#         datos.append([1,['Helvetica-Bold',9,colors.black],[datos_titulo[0][1],primeralinea-salto],datos_titulo[0][0],'c'])
#         numeroLineas += 1
#         salto += 0.4
#         # Fecha
#         if datos_titulo[1][0]:
#             datos.append([3,['Helvetica',8,colors.red],[datos_titulo[1][1],primeralinea-salto],'c'])
#             salto += 0.5
#             numeroLineas += 1
#         # Linea superior de columnas
#         datos.append([4,[datos_titulo[2],primeralinea-salto,datos_titulo[3],primeralinea-salto,datos_titulo[4]]])    
#         salto += 0.4
#         # Columnas
#         pos = 0
#         for col in range(0,len(datos_titulo[5]),2):
#             datos.append([1,['Helvetica-Bold',9,colors.black],[datos_titulo[5][col],primeralinea-salto],datos_titulo[5][col+1],'l'])
#             pos+=2
#         salto += 0.2
#         # Linea inferior de columnas
#         datos.append([4,[datos_titulo[2],primeralinea-salto,datos_titulo[3],primeralinea-salto,datos_titulo[4]]])    
#         numeroLineas += 2
#         salto += 0.5

#     datos_reporte[0] =  numeroLineas
#     datos_reporte[1] = salto 
#     datos_reporte[2] = pagina 
#     datos_reporte[3] = maxlineas 

# def Encabezado(datos,pagina):

#     anchologo=1.50
#     altologo=1.50
#     posxlogo=1.00
#     posylogo=25.70
#     posxnombre=15.00
#     posynombre=26.00
#     iniciolineax=1.00
#     finallineax=20.50
#     iniciolineay=25.30
#     grosorlinea=0.90
#     piex=20.50
#     piey=1.00
#     lineapiex = 20.50
#     lineapiey=1.70
#     nombre = administracion

#     logo = None
#     try:
#         cd = os.getcwd()
#         logo = cd + '/core/static/core/img/logo.png'
#     except:
#         pass     

#     datos.append([2,logo,[posxlogo,posylogo],[anchologo,altologo]])       
#     datos.append([1,['Helvetica',20,colors.black],[posxnombre,posynombre],nombre,'c'])
#     datos.append([4,[iniciolineax,iniciolineay,finallineax, iniciolineay,grosorlinea]])
#     # Pie
#     datos.append([1,['Helvetica',8,colors.black],[piex,piey],'Pag. ' + str(pagina),'c'])
#     datos.append([4,[iniciolineax,lineapiey,lineapiex,lineapiey,grosorlinea]])    




# Este modelo es dependiente de comprobante
# Vista que es utilizada para la edicion del
# modelo asiento cuyos registros y se encuentran
# grabados en la Base de Datos
class EditarasientoView(UpdateView):
	# El modelo que se edita
	model = asiento
	# El formulario para la edicion
	form_class = asientoForm
	# El HTML que se despliega ante el usuario
	template_name = 'contabilidad/asiento_update_form.html'

	# El procedimiento de salida de la edicion
	def get_success_url(self):
		# El modelo asiento es independiente
		# Despues de editar el modelo se vuelve al HTML de edicion
		# con el mensaje de actualizacion correcta del registro
		return reverse_lazy('contabilidad:editar_comprobante', args=[self.request.GET['comprobante_id']]) + '?correcto'

	# Se preparan los context para enviarlos al HTML de edicion
	def get_context_data(self,**kwargs):
		context = super(EditarasientoView, self).get_context_data(**kwargs)
		# Se recupera el registro de asiento que se edita
		asiento = (self.object)
		# Se envian al HTML el id del modelo y su campo que lo identifica
		# Este campo fue el que se definio como identificador de borrado del modelo
		context['asiento_id'] = self.object.id
		context['nombre'] = asiento.fecha
		# Se envia al HTML la lista de los modelos dependientes de @modelo
		centrocosto_centrocosto = centrocosto.objects.filter(asiento = asiento)
		context['listacentrocosto'] =  centrocosto_centrocosto
		# Se envia al HTML la lista de los modelos dependientes de @modelo
		presupuesto_presupuesto = presupuesto.objects.filter(asiento = asiento)
		context['listapresupuesto'] =  presupuesto_presupuesto

		# Se recupera el modelo padre y se envia su id
		context['comprobante_id'] = self.object.comprobante.id

# Se envia al HTML el numero de modelos dependientes de asiento
		context['numerocentrocosto'] = centrocosto.objects.filter(asiento=asiento).count()
# Se envia al HTML el numero de modelos dependientes de asiento
		context['numeropresupuesto'] = presupuesto.objects.filter(asiento=asiento).count()

		return context

# Este modelo es dependiente de comprobante
# Esta vista es utilizada para el registro de nuevos
# registros del modelo asiento
class CrearasientoView(CreateView):
	# Se define el modelo cuyo registro de inserta
	model = asiento
	# El formulario para el nuevo registro
	form_class = asientoForm
	# El HTML para el nuevo registro
	template_name = 'contabilidad/asiento_form.html'

	# El procedimiento de salida de la insercion
	def get_success_url(self):
		# Despues de la insercion del registro, el control
		# retorna al HTML de edicion del modelo padre
		return reverse_lazy('contabilidad:editar_comprobante', args=[self.request.GET['comprobante_id']]) + '?correcto'

	# Procedimiento para el clik de insercion
	def post(self,request,*args,**kwargs):
		# Se recupera el formulario con los controles ya llenos
		form = self.form_class(request.POST)
		# Se recupera el registro del modelo padre 
		comprobante_post = comprobante.objects.get(id = request.GET['comprobante_id'])
		if form.is_valid():
		# El formulario es valido, no existen incongruencias
		# Se graba el registro en la base de datos pero 
		# la grabacion se mantiene pendiente, sin commit 
			asiento= form.save(commit=False)
			# Se asigna a asiento la dependencia con el modelo padre
			asiento.comprobante = comprobante_post
			# Se graba el registro definitivamente en la base de datos 
			asiento.save()
			# Se leva el control al procedimiento de salida por grabacion exitosa
			return HttpResponseRedirect(self.get_success_url())
		else:
			# Se leva el control al HTML de insercion grabacion no exitosa
			return self.render_to_response(self.get_context_data(form=form))

	def get_context_data(self,**kwargs):
		print('horror')
		context = super(CrearasientoView, self).get_context_data(**kwargs)
		# Se recupera el objeto padre y se envia su id
		context['comprobante_id'] = self.request.GET['comprobante_id']
		return context

# Este modelo es dependiente de comprobante
# Esta vista es utilizada para el borrado de
# registros del modelo asiento
class BorrarasientoView(DeleteView):
	# Se define el modelo a borrar
	model = asiento
	# El template HTML para desplegar la opcion de borrado
	template_name = 'contabilidad/asiento_confirm_delete.html'

	# El procedimiento de salida del borrado
	def get_success_url(self):
		# El control vuelve a la edicion del modelo padre
		return reverse_lazy('contabilidad:editar_comprobante', args=[self.request.GET['comprobante_id']]) + '?correcto'

	# Se preparan los contextos para el HTML de borrado
	def get_context_data(self,**kwargs):
		context = super(BorrarasientoView, self).get_context_data(**kwargs)
		# Se recupera el modelo y se envia el nombre definido para el borrado
		asiento_borra_asiento_borra = asiento.objects.get(id=self.object.id)
		context['nombreborrar'] = asiento_borra_asiento_borra.fecha
		# Se recupera el modelo padre y se envia su id
		context['comprobante_id'] = self.object.comprobante.id

		return context

# Este modelo es dependiente de asiento
# Vista que es utilizada para la edicion del
# modelo centrocosto cuyos registros y se encuentran
# grabados en la Base de Datos
class EditarcentrocostoView(UpdateView):
	# El modelo que se edita
	model = centrocosto
	# El formulario para la edicion
	form_class = centrocostoForm
	# El HTML que se despliega ante el usuario
	template_name = 'contabilidad/centrocosto_update_form.html'

	# El procedimiento de salida de la edicion
	def get_success_url(self):
		# Despues de editar el modelo se vuelve al HTML de edicion
		# con el mensaje de actualizacion correcta del registro
		return reverse_lazy('contabilidad:editar_asiento', args=[self.request.GET['asiento_id']]) + '?correcto' + '&centrocostoabuelo_id=' + str(self.request.GET['centrocostoabuelo_id'])
# Este modelo es dependiente de asiento
# Vista que es utilizada para la edicion del
# modelo centrocosto cuyos registros y se encuentran
# grabados en la Base de Datos
class EditarcentrocostoView(UpdateView):
	# El modelo que se edita
	model = centrocosto
	# El formulario para la edicion
	form_class = centrocostoForm
	# El HTML que se despliega ante el usuario
	template_name = 'contabilidad/centrocosto_update_form.html'

	# El procedimiento de salida de la edicion
	def get_success_url(self):
		# Despues de editar el modelo se vuelve al HTML de edicion
		# con el mensaje de actualizacion correcta del registro
		return reverse_lazy('contabilidad:editar_asiento', args=[self.request.GET['asiento_id']]) + '?correcto' + '&comprobante_id=' + str(self.request.GET['comprobante_id'])

	# Se preparan los context para enviarlos al HTML de edicion
	def get_context_data(self,**kwargs):
		context = super(EditarcentrocostoView, self).get_context_data(**kwargs)
		# Se recupera el registro de centrocosto que se edita
		centrocosto = (self.object)
		# Se envian al HTML el id del modelo y su campo que lo identifica
		# Este campo fue el que se definio como identificador de borrado del modelo
		context['centrocosto_id'] = self.object.id
		context['nombre'] = centrocosto.centro

		context['asiento_id'] = self.object.asiento.id
		# Se recupera el modelo abuelo y se envia su id
		asiento_asiento = asiento.objects.get(id=self.object.asiento.id)
		context['comprobante_id'] = asiento_asiento.comprobante.id


		return context

# Este modelo es dependiente de asiento
# Esta vista es utilizada para el registro de nuevos
# registros del modelo centrocosto
class CrearcentrocostoView(CreateView):
	# Se define el modelo cuyo registro de inserta
	model = centrocosto
	# El formulario para el nuevo registro
	form_class = centrocostoForm
	# El HTML para el nuevo registro
	template_name = 'contabilidad/centrocosto_form.html'

	# El procedimiento de salida de la insercion
	def get_success_url(self):
		# Despues de la insercion del registro, el control
		# retorna al HTML de edicion del modelo padre
		return reverse_lazy('contabilidad:editar_asiento', args=[self.request.GET['asiento_id']]) + '?correcto'

	# Procedimiento para el clik de insercion
	def post(self,request,*args,**kwargs):
		# Se recupera el formulario con los controles ya llenos
		form = self.form_class(request.POST)
		# Se recupera el registro del modelo padre 
		asiento_post = asiento.objects.get(id = request.GET['asiento_id'])
		if form.is_valid():
		# El formulario es valido, no existen incongruencias
		# Se graba el registro en la base de datos pero 
		# la grabacion se mantiene pendiente, sin commit 
			centrocosto= form.save(commit=False)
			# Se asigna a centrocosto la dependencia con el modelo padre
			centrocosto.asiento = asiento_post
			# Se graba el registro definitivamente en la base de datos 
			centrocosto.save()
			# Se leva el control al procedimiento de salida por grabacion exitosa
			return HttpResponseRedirect(self.get_success_url())
		else:
			# Se leva el control al HTML de insercion grabacion no exitosa
			return self.render_to_response(self.get_context_data(form=form))

	# Se preparan los context para enviarlos al HTML de insercion
	def get_context_data(self,**kwargs):
		context = super(CrearcentrocostoView, self).get_context_data(**kwargs)
		# Se recupera el objeto padre y se envia su id
		obj = asiento.objects.get(id=self.request.GET['asiento_id'])
		context['asiento_id'] = obj.id
		# Se recupera el modelo abuelo y se envia su id
		comprobante_comprobante = comprobante.objects.get(id=obj.comprobante.id)
		context['comprobante_id'] = comprobante_comprobante.id
		return context

# Este modelo es dependiente de asiento
# Esta vista es utilizada para el borrado de
# registros del modelo centrocosto
class BorrarcentrocostoView(DeleteView):
	# Se define el modelo a borrar
	model = centrocosto
	# El template HTML para desplegar la opcion de borrado
	template_name = 'contabilidad/centrocosto_confirm_delete.html'

	# El procedimiento de salida del borrado
	def get_success_url(self):
		# El control vuelve a la edicion del modelo padre
		return reverse_lazy('contabilidad:editar_asiento', args=[self.request.GET['asiento_id']]) + '?correcto'

	# Se preparan los contextos para el HTML de borrado
	def get_context_data(self,**kwargs):
		context = super(BorrarcentrocostoView, self).get_context_data(**kwargs)
		# Se recupera el modelo y se envia el nombre definido para el borrado
		centrocosto_borra_centrocosto_borra = centrocosto.objects.get(id=self.object.id)
		context['nombreborrar'] = centrocosto_borra_centrocosto_borra.centro
		context['asiento_id'] = self.object.asiento.id
		# Se recupera el modelo abuelo y se envia su id
		asiento_asiento = asiento.objects.get(id=self.object.asiento.id)
		context['comprobante_id'] = asiento_asiento.comprobante.id

		return context

# Este modelo es dependiente de asiento
# Vista que es utilizada para la edicion del
# modelo presupuesto cuyos registros y se encuentran
# grabados en la Base de Datos
class EditarpresupuestoView(UpdateView):
	# El modelo que se edita
	model = presupuesto
	# El formulario para la edicion
	form_class = presupuestoForm
	# El HTML que se despliega ante el usuario
	template_name = 'contabilidad/presupuesto_update_form.html'

	# El procedimiento de salida de la edicion
	def get_success_url(self):
		# Despues de editar el modelo se vuelve al HTML de edicion
		# con el mensaje de actualizacion correcta del registro
		return reverse_lazy('contabilidad:editar_asiento', args=[self.request.GET['asiento_id']]) + '?correcto' + '&presupuestoabuelo_id=' + str(self.request.GET['presupuestoabuelo_id'])
# Este modelo es dependiente de asiento
# Vista que es utilizada para la edicion del
# modelo presupuesto cuyos registros y se encuentran
# grabados en la Base de Datos
class EditarpresupuestoView(UpdateView):
	# El modelo que se edita
	model = presupuesto
	# El formulario para la edicion
	form_class = presupuestoForm
	# El HTML que se despliega ante el usuario
	template_name = 'contabilidad/presupuesto_update_form.html'

	# El procedimiento de salida de la edicion
	def get_success_url(self):
		# Despues de editar el modelo se vuelve al HTML de edicion
		# con el mensaje de actualizacion correcta del registro
		return reverse_lazy('contabilidad:editar_asiento', args=[self.request.GET['asiento_id']]) + '?correcto' + '&comprobante_id=' + str(self.request.GET['comprobante_id'])

	# Se preparan los context para enviarlos al HTML de edicion
	def get_context_data(self,**kwargs):
		context = super(EditarpresupuestoView, self).get_context_data(**kwargs)
		# Se recupera el registro de presupuesto que se edita
		presupuesto = (self.object)
		# Se envian al HTML el id del modelo y su campo que lo identifica
		# Este campo fue el que se definio como identificador de borrado del modelo
		context['presupuesto_id'] = self.object.id
		context['nombre'] = presupuesto.fecha

		context['asiento_id'] = self.object.asiento.id
		# Se recupera el modelo abuelo y se envia su id
		asiento_asiento = asiento.objects.get(id=self.object.asiento.id)
		context['comprobante_id'] = asiento_asiento.comprobante.id


		return context

# Este modelo es dependiente de asiento
# Esta vista es utilizada para el registro de nuevos
# registros del modelo presupuesto
class CrearpresupuestoView(CreateView):
	# Se define el modelo cuyo registro de inserta
	model = presupuesto
	# El formulario para el nuevo registro
	form_class = presupuestoForm
	# El HTML para el nuevo registro
	template_name = 'contabilidad/presupuesto_form.html'

	# El procedimiento de salida de la insercion
	def get_success_url(self):
		# Despues de la insercion del registro, el control
		# retorna al HTML de edicion del modelo padre
		return reverse_lazy('contabilidad:editar_asiento', args=[self.request.GET['asiento_id']]) + '?correcto'

	# Procedimiento para el clik de insercion
	def post(self,request,*args,**kwargs):
		# Se recupera el formulario con los controles ya llenos
		form = self.form_class(request.POST)
		# Se recupera el registro del modelo padre 
		asiento_post = asiento.objects.get(id = request.GET['asiento_id'])
		if form.is_valid():
		# El formulario es valido, no existen incongruencias
		# Se graba el registro en la base de datos pero 
		# la grabacion se mantiene pendiente, sin commit 
			presupuesto= form.save(commit=False)
			# Se asigna a presupuesto la dependencia con el modelo padre
			presupuesto.asiento = asiento_post
			# Se graba el registro definitivamente en la base de datos 
			presupuesto.save()
			# Se leva el control al procedimiento de salida por grabacion exitosa
			return HttpResponseRedirect(self.get_success_url())
		else:
			# Se leva el control al HTML de insercion grabacion no exitosa
			return self.render_to_response(self.get_context_data(form=form))

	# Se preparan los context para enviarlos al HTML de insercion
	def get_context_data(self,**kwargs):
		context = super(CrearpresupuestoView, self).get_context_data(**kwargs)
		# Se recupera el objeto padre y se envia su id
		obj = asiento.objects.get(id=self.request.GET['asiento_id'])
		context['asiento_id'] = obj.id
		# Se recupera el modelo abuelo y se envia su id
		comprobante_comprobante = comprobante.objects.get(id=obj.comprobante.id)
		context['comprobante_id'] = comprobante_comprobante.id
		return context

# Este modelo es dependiente de asiento
# Esta vista es utilizada para el borrado de
# registros del modelo presupuesto
class BorrarpresupuestoView(DeleteView):
	# Se define el modelo a borrar
	model = presupuesto
	# El template HTML para desplegar la opcion de borrado
	template_name = 'contabilidad/presupuesto_confirm_delete.html'

	# El procedimiento de salida del borrado
	def get_success_url(self):
		# El control vuelve a la edicion del modelo padre
		return reverse_lazy('contabilidad:editar_asiento', args=[self.request.GET['asiento_id']]) + '?correcto'

	# Se preparan los contextos para el HTML de borrado
	def get_context_data(self,**kwargs):
		context = super(BorrarpresupuestoView, self).get_context_data(**kwargs)
		# Se recupera el modelo y se envia el nombre definido para el borrado
		presupuesto_borra_presupuesto_borra = presupuesto.objects.get(id=self.object.id)
		context['nombreborrar'] = presupuesto_borra_presupuesto_borra.fecha
		context['asiento_id'] = self.object.asiento.id
		# Se recupera el modelo abuelo y se envia su id
		asiento_asiento = asiento.objects.get(id=self.object.asiento.id)
		context['comprobante_id'] = asiento_asiento.comprobante.id

		return context







# General de Reportes
def Acomoda(datos,datos_reporte,primeralinea,titulo=False,datos_titulo=[]):

    numeroLineas = datos_reporte[0]
    pagina = datos_reporte[2]
    salto = datos_reporte[1]
    maxlineas = datos_reporte[3]

    nuevapagina = False
    if pagina == 1:
        # encabezado
        Encabezado(datos,pagina)
        salto = 0
        pagina += 1
    if numeroLineas >= maxlineas:
        nuevapagina = True
        numeroLineas = 0
        maxlineas = 50
        datos.append([0])
    if nuevapagina:
        # encabezado
        Encabezado(datos,pagina)
        salto = 0
        pass
    if titulo:
        numeroLineas += 1
        salto += 0.5    	
        datos.append([1,['Helvetica-Bold',9,colors.black],[datos_titulo[0][1],primeralinea-salto],datos_titulo[0][0],'c'])
        numeroLineas += 1
        salto += 0.4
        # Fecha
        if datos_titulo[1][0]:
            datos.append([3,['Helvetica',8,colors.red],[datos_titulo[1][1],primeralinea-salto],'c'])
            salto += 0.5
            numeroLineas += 1
        # Linea superior de columnas
        datos.append([4,[datos_titulo[2],primeralinea-salto,datos_titulo[3],primeralinea-salto,datos_titulo[4]]])    
        salto += 0.4
        # Columnas
        pos = 0
        for col in range(0,len(datos_titulo[5]),2):
            datos.append([1,['Helvetica-Bold',9,colors.black],[datos_titulo[5][col],primeralinea-salto],datos_titulo[5][col+1],'l'])
            pos+=2
        salto += 0.2
        # Linea inferior de columnas
        datos.append([4,[datos_titulo[2],primeralinea-salto,datos_titulo[3],primeralinea-salto,datos_titulo[4]]])    
        numeroLineas += 2
        salto += 0.5

    datos_reporte[0] =  numeroLineas
    datos_reporte[1] = salto 
    datos_reporte[2] = pagina 
    datos_reporte[3] = maxlineas 

def Encabezado(datos,pagina):

    anchologo=1.50
    altologo=1.50
    posxlogo=1.00
    posylogo=25.70
    posxnombre=15.00
    posynombre=26.00
    iniciolineax=1.00
    finallineax=20.50
    iniciolineay=25.30
    grosorlinea=0.90
    piex=20.50
    piey=1.00
    lineapiex = 20.50
    lineapiey=1.70
    nombre = 'administracion'

    logo = None
    try:
        cd = os.getcwd()
        logo = cd + '/core/static/core/img/logo.png'
    except:
        pass     

    datos.append([2,logo,[posxlogo,posylogo],[anchologo,altologo]])       
    datos.append([1,['Helvetica',20,colors.black],[posxnombre,posynombre],nombre,'c'])
    datos.append([4,[iniciolineax,iniciolineay,finallineax, iniciolineay,grosorlinea]])
    # Pie
    datos.append([1,['Helvetica',8,colors.black],[piex,piey],'Pag. ' + str(pagina),'c'])
    datos.append([4,[iniciolineax,lineapiey,lineapiex,lineapiey,grosorlinea]])    
