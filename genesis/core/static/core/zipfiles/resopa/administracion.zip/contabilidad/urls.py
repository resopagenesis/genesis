from django.urls import path
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required

from .views import HomeView
from .views import ListarcuentaView, CrearcuentaView, EditarcuentaView, BorrarcuentaView, ReportecuentaView
from .views import CrearasientoView, EditarasientoView, BorrarasientoView
from .views import ListarcomprobanteView, CrearcomprobanteView, EditarcomprobanteView, BorrarcomprobanteView, ReportecomprobanteView
from .views import CrearcentrocostoView, EditarcentrocostoView, BorrarcentrocostoView
from .views import CrearpresupuestoView, EditarpresupuestoView, BorrarpresupuestoView




contabilidad_patterns = ([
	path('',(HomeView.as_view()), name='home'),
	path('listar_cuenta/',(ListarcuentaView.as_view()), name='listar_cuenta'),
	path('reporte_cuenta/',ReportecuentaView, name='reporte_cuenta'),
	path('editar_cuenta/<int:pk>/',(EditarcuentaView.as_view()), name='editar_cuenta'),
	path('crear_cuenta/',(CrearcuentaView.as_view()), name='crear_cuenta'),
	path('borrar_cuenta/<int:pk>/',(BorrarcuentaView.as_view()), name='borrar_cuenta'),

	path('editar_asiento/<int:pk>/',(EditarasientoView.as_view()), name='editar_asiento'),
	path('crear_asiento/',(CrearasientoView.as_view()), name='crear_asiento'),
	path('borrar_asiento/<int:pk>/',(BorrarasientoView.as_view()), name='borrar_asiento'),

	path('listar_comprobante/',(ListarcomprobanteView.as_view()), name='listar_comprobante'),
	path('reporte_comprobante/',ReportecomprobanteView, name='reporte_comprobante'),
	path('editar_comprobante/<int:pk>/',(EditarcomprobanteView.as_view()), name='editar_comprobante'),
	path('crear_comprobante/',(CrearcomprobanteView.as_view()), name='crear_comprobante'),
	path('borrar_comprobante/<int:pk>/',(BorrarcomprobanteView.as_view()), name='borrar_comprobante'),

	path('editar_centrocosto/<int:pk>/',(EditarcentrocostoView.as_view()), name='editar_centrocosto'),
	path('crear_centrocosto/',(CrearcentrocostoView.as_view()), name='crear_centrocosto'),
	path('borrar_centrocosto/<int:pk>/',(BorrarcentrocostoView.as_view()), name='borrar_centrocosto'),

	path('editar_presupuesto/<int:pk>/',(EditarpresupuestoView.as_view()), name='editar_presupuesto'),
	path('crear_presupuesto/',(CrearpresupuestoView.as_view()), name='crear_presupuesto'),
	path('borrar_presupuesto/<int:pk>/',(BorrarpresupuestoView.as_view()), name='borrar_presupuesto'),



], 'contabilidad')

