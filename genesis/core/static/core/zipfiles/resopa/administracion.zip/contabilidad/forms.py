from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from contabilidad.models import cuenta
from contabilidad.models import asiento
from contabilidad.models import cuenta
from contabilidad.models import comprobante
from contabilidad.models import centrocosto
from parametros.models import centro
from contabilidad.models import presupuesto







class cuentaForm(forms.ModelForm):
	class Meta:
		model = cuenta
		fields = ('codigo','Descripcion','foto',)
		widgets = {
			'codigo': forms.TextInput(attrs={'class':'form-control  font_control_cuenta mt-1', 'placeholder': ''}),
			'Descripcion': forms.TextInput(attrs={'class':'form-control font_control_cuenta mt-1', 'placeholder': ''}),
			'foto': forms.ClearableFileInput(attrs={'class':'form-control-file  font_control_cuenta mt-1'}),

		}
		labels = {
		'codigo':'Codigo','Descripcion':'Descripcion','foto':'foto',
		}


class asientoForm(forms.ModelForm):
	class Meta:
		model = asiento
		fields = ('cuenta','debe','fecha',)
		widgets = {
			'cuenta': forms.Select(attrs={'class':'form-control  font_control_asiento mt-1'},choices=cuenta.objects.all()),
			'debe': forms.TextInput(attrs={'class':'form-control  font_control_asiento mt-1', 'placeholder': ''}),
			'fecha': forms.DateInput(attrs={'class':'datepicker form-control  font_control_asiento mt-1'},format="%m/%d/%Y"),

		}
		labels = {
		'cuenta':'Cuenta','debe':'Debe','fecha':'Fecha',
		}


class comprobanteForm(forms.ModelForm):
	class Meta:
		model = comprobante
		fields = ('numero','glosa',)
		widgets = {
			'numero': forms.TextInput(attrs={'class':'form-control  font_control_comprobante mt-1', 'placeholder': ''}),
			'glosa': forms.TextInput(attrs={'class':'form-control font_control_comprobante mt-1', 'placeholder': ''}),

		}
		labels = {
		'numero':'Numero','glosa':'Glosa',
		}


class centrocostoForm(forms.ModelForm):
	class Meta:
		model = centrocosto
		fields = ('centro','importe',)
		widgets = {
			'centro': forms.Select(attrs={'class':'form-control  font_control_centrocosto mt-1'},choices=centro.objects.all()),
			'importe': forms.TextInput(attrs={'class':'form-control font_control_centrocosto mt-1', 'placeholder': ''}),

		}
		labels = {
		'centro':'Centro','importe':'Importe',
		}


class presupuestoForm(forms.ModelForm):
	class Meta:
		model = presupuesto
		fields = ('fecha',)
		widgets = {
			'fecha': forms.DateInput(attrs={'class':'datepicker form-control  font_control_presupuesto mt-1'},format="%m/%d/%Y"),

		}
		labels = {
		'fecha':'Fecha',
		}





