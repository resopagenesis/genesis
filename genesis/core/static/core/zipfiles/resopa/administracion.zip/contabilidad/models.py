from django.db import models
from ckeditor.fields import RichTextField
from django.core.exceptions import ValidationError
from django.utils.translation import ugettext_lazy as _
from django.urls import reverse, reverse_lazy
from django.utils import timezone
from django.contrib.auth.models import User


# Modelos Foreign

from parametros.models import centro



# Crear los modelo aqui.


class cuenta(models.Model):


	codigo =  models.IntegerField(default=0)
	Descripcion = models.CharField(max_length=30,default='')
	foto = models.ImageField(upload_to='cuenta',blank=True,null=True)


	def __str__(self):
		return str(self.codigo)

class comprobante(models.Model):


	numero =  models.SmallIntegerField(default=0)
	glosa = models.CharField(max_length=30,default='')


	def __str__(self):
		return str(self.numero)

class asiento(models.Model):


	cuenta =  models.ForeignKey(cuenta, on_delete=models.CASCADE, related_name='%(class)s_cuenta')
	debe =  models.DecimalField(default=0,decimal_places=2,max_digits=10)
	fecha = models.DateField(default=timezone.now)
	comprobante =  models.ForeignKey(comprobante, on_delete=models.CASCADE)


	def __str__(self):
		return str(self.fecha)

class centrocosto(models.Model):


	centro =  models.ForeignKey(centro, on_delete=models.CASCADE, related_name='%(class)s_centro')
	importe = models.CharField(max_length=30,default='')
	asiento =  models.ForeignKey(asiento, on_delete=models.CASCADE)


	def __str__(self):
		return self.centro

class presupuesto(models.Model):


	fecha = models.DateField(default=timezone.now)
	asiento =  models.ForeignKey(asiento, on_delete=models.CASCADE)


	def __str__(self):
		return str(self.fecha)



