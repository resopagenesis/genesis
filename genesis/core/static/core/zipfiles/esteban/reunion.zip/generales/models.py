from django.db import models
from ckeditor.fields import RichTextField
from django.core.exceptions import ValidationError
from django.urls import reverse, reverse_lazy
from django.utils import timezone
from django.contrib.auth.models import User


# Modelos Foreign




# Crear los modelo aqui.


class tipo_mensaje(models.Model):


	descripcion = models.CharField(max_length=50,default='')


	def __str__(self):
		return self.descripcion




