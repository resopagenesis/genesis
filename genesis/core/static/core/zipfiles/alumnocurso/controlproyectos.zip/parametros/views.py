from django.shortcuts import render
from django.views.generic.list import ListView
from django.views.generic.edit import CreateView, UpdateView, DeleteView, FormView
from django.views.generic.base import TemplateView
from django.urls import reverse, reverse_lazy
from django.http import HttpResponseRedirect
from django.db.models import Sum, Count, Avg, Q
import random
import datetime
from django import forms
import time
import os

# Reporte

from core.views import Reporte
from reportlab.lib.pagesizes import letter,landscape,portrait,A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch, mm, cm
from reportlab.lib import colors


from parametros.models import tipo
from parametros.models import moneda
from parametros.models import tipocambio
from parametros.models import tipocosto
from parametros.models import especialidad




from .forms import tipoForm
from .forms import monedaForm
from .forms import tipocambioForm
from .forms import tipocostoForm
from .forms import especialidadForm




# Create your views here.
class HomeView(TemplateView):
	template_name = 'parametros/home.html'

# Este modelo es independiente por lo que
# se elabora una lista de sus registros
class ListartipoView(ListView):
	# Definir el modelo a utilizar
	model = tipo
	# Especificar el template HTML
	template_name = 'parametros/tipo_list.html'

	# Prepara los context para el HTML
	def get_context_data(self,**kwargs):
		context = super(ListartipoView, self).get_context_data(**kwargs)
		context['lista'] = tipo.objects.all()
		return context

# Este modelo es independiente y esta vista
# es la utilizada para la edicion de un registro
# ya grabado en la Base de Datos
class EditartipoView(UpdateView):
	# Define el modelo
	model = tipo
	# Define el formulario
	form_class = tipoForm
	# Define el HTML de edicion
	template_name = 'parametros/tipo_update_form.html'

	# Procedimiento de salida despues de actualizacion exitosa
	def get_success_url(self):
		# Retorna al HTML de edicion con la comunicacion de correcta actualizacion
		return reverse_lazy('parametros:editar_tipo', args=[self.object.id]) + '?correcto'

	# Prepara los context para el HTML de edicion
	def get_context_data(self,**kwargs):
		context = super(EditartipoView, self).get_context_data(**kwargs)
		# Recupera el modelo a ser editado y envia su id
		tipo = (self.object)
		modelo = (self.object)
		context['tipo_id'] = self.object.id

		# Envia el context con la identificacion que se dio al borrado
		context['nombre'] = str(modelo.nombre)
		return context

# Este modelo es independiente y esta vista
# es la utilizada para la insercion de un nuevo registro
# en la Base de Datos
class CreartipoView(CreateView):
	# Define el modelo cuyo registro se inserta
	model = tipo
	# Define el formulario de controles
	form_class = tipoForm
	# Define el HTML de insercion
	template_name = 'parametros/tipo_form.html'

	# Procedimiento de retorno por insercion exitosa
	def get_success_url(self):
		# Retorna al HTML de la lista de registros del modelo
		return reverse_lazy('parametros:listar_tipo') + '?correcto'
	# Prepara los context de insercion
	def get_context_data(self,**kwargs):
		context = super(CreartipoView, self).get_context_data(**kwargs)
		return context

# Este modelo es independiente y esta vista
# es la utilizada para el borrado de un registro
# ya grabado en la Base de Datos
class BorrartipoView(DeleteView):
	# Define le modelo a borrar
	model = tipo
	# Define el HTML de borrado
	template_name = 'parametros/tipo_confirm_delete.html'

	# Procedimiento de retorno por borrado exitoso
	def get_success_url(self):
		# Retorna al HTML de lista de registros del modelo
		return reverse_lazy('parametros:listar_tipo') + '?correcto'
	# Prepara los context de borrado
	def get_context_data(self,**kwargs):
		context = super(BorrartipoView, self).get_context_data(**kwargs)
		# Recupera el modelo a borrar y envia su id
		modelo = tipo.objects.get(id=self.object.id)
		context['nombreborrar'] = str(modelo.nombre)
		return context

def ReportetipoView(request):

    # Variables del proyecto para el reporte
    primeralinea = 24.50
    maxlineas = 44

    numeroLineas = 0
    salto = 0
    pagina = 1
    
    # Lista de transferencia
    datos_detalle = []

    # Variables de reporte
    datos_reporte = []
    datos_reporte.append(numeroLineas)
    datos_reporte.append(salto)
    datos_reporte.append(pagina)
    datos_reporte.append(maxlineas)

    # Control de titulos por modelos
    primer_tipo = True




    for reg_tipo in tipo.objects.all():
        if primer_tipo:
            datos_titulo = []
            datos_titulo.append(['Lista de Tipos de Proyectos',10.50])
            datos_titulo.append([True,10.50])
            datos_titulo.append(1.00)
            datos_titulo.append(20.50)
            datos_titulo.append(0.30)
            datos_titulo.append([1.50,'nombre'])
            Acomoda(datos_detalle,datos_reporte,primeralinea,True,datos_titulo)
            primer_tipo=False
        datos_reporte[0] += 1
        Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
        datos_detalle.append([1,['Helvetica',9,colors.black],[1.50,primeralinea-datos_reporte[1]],str(reg_tipo.nombre),'l'])
        datos_reporte[1] += 0.4
    if not primer_tipo:
        datos_reporte[0] += 2
        Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
        datos_detalle.append([4,[1.00,primeralinea-datos_reporte[1]+0.2,20.50,primeralinea-datos_reporte[1]+0.2,0.3]])
        datos_detalle.append([4,[1.00,primeralinea-datos_reporte[1]+0.15,20.50,primeralinea-datos_reporte[1]+0.15,0.3]])
        datos_reporte[1] += 0.8


    plan = Reporte("tipo.pdf",letter,'portrait',datos_detalle)
    plan.detalle()
    plan.grabar()
    return HttpResponseRedirect('/parametros/listar_tipo')


# Este modelo es independiente por lo que
# se elabora una lista de sus registros
class ListarmonedaView(ListView):
	# Definir el modelo a utilizar
	model = moneda
	# Especificar el template HTML
	template_name = 'parametros/moneda_list.html'

	# Prepara los context para el HTML
	def get_context_data(self,**kwargs):
		context = super(ListarmonedaView, self).get_context_data(**kwargs)
		context['lista'] = moneda.objects.all()
		return context

# Este modelo es independiente y esta vista
# es la utilizada para la edicion de un registro
# ya grabado en la Base de Datos
class EditarmonedaView(UpdateView):
	# Define el modelo
	model = moneda
	# Define el formulario
	form_class = monedaForm
	# Define el HTML de edicion
	template_name = 'parametros/moneda_update_form.html'

	# Procedimiento de salida despues de actualizacion exitosa
	def get_success_url(self):
		# Retorna al HTML de edicion con la comunicacion de correcta actualizacion
		return reverse_lazy('parametros:editar_moneda', args=[self.object.id]) + '?correcto'

	# Prepara los context para el HTML de edicion
	def get_context_data(self,**kwargs):
		context = super(EditarmonedaView, self).get_context_data(**kwargs)
		# Recupera el modelo a ser editado y envia su id
		moneda = (self.object)
		modelo = (self.object)
		context['moneda_id'] = self.object.id
		tipocambio_lista = tipocambio.objects.filter(moneda = moneda)
		context['listatipocambio'] =  tipocambio_lista

		# Envia el context con la identificacion que se dio al borrado
		context['nombre'] = str(modelo.nombre)
		# Envia el cotext con el numero de modelos dependientes
		context['numerotipocambio'] = tipocambio.objects.filter(moneda=moneda).count()
		return context

# Este modelo es independiente y esta vista
# es la utilizada para la insercion de un nuevo registro
# en la Base de Datos
class CrearmonedaView(CreateView):
	# Define el modelo cuyo registro se inserta
	model = moneda
	# Define el formulario de controles
	form_class = monedaForm
	# Define el HTML de insercion
	template_name = 'parametros/moneda_form.html'

	# Procedimiento de retorno por insercion exitosa
	def get_success_url(self):
		# Retorna al HTML de la lista de registros del modelo
		return reverse_lazy('parametros:listar_moneda') + '?correcto'
	# Prepara los context de insercion
	def get_context_data(self,**kwargs):
		context = super(CrearmonedaView, self).get_context_data(**kwargs)
		return context

# Este modelo es independiente y esta vista
# es la utilizada para el borrado de un registro
# ya grabado en la Base de Datos
class BorrarmonedaView(DeleteView):
	# Define le modelo a borrar
	model = moneda
	# Define el HTML de borrado
	template_name = 'parametros/moneda_confirm_delete.html'

	# Procedimiento de retorno por borrado exitoso
	def get_success_url(self):
		# Retorna al HTML de lista de registros del modelo
		return reverse_lazy('parametros:listar_moneda') + '?correcto'
	# Prepara los context de borrado
	def get_context_data(self,**kwargs):
		context = super(BorrarmonedaView, self).get_context_data(**kwargs)
		# Recupera el modelo a borrar y envia su id
		modelo = moneda.objects.get(id=self.object.id)
		context['nombreborrar'] = str(modelo.nombre)
		return context

def ReportemonedaView(request):

    # Variables del proyecto para el reporte
    primeralinea = 24.50
    maxlineas = 44

    numeroLineas = 0
    salto = 0
    pagina = 1
    
    # Lista de transferencia
    datos_detalle = []

    # Variables de reporte
    datos_reporte = []
    datos_reporte.append(numeroLineas)
    datos_reporte.append(salto)
    datos_reporte.append(pagina)
    datos_reporte.append(maxlineas)

    # Control de titulos por modelos
    primer_moneda = True
    primer_tipocambio = True




    for reg_moneda in moneda.objects.all():
        if primer_moneda:
            datos_titulo = []
            datos_titulo.append(['Lista de Monedas',10.50])
            datos_titulo.append([True,10.50])
            datos_titulo.append(1.00)
            datos_titulo.append(20.50)
            datos_titulo.append(0.30)
            datos_titulo.append([1.50,'nombre'])
            Acomoda(datos_detalle,datos_reporte,primeralinea,True,datos_titulo)
            primer_moneda=False
        primer_tipocambio=True
        datos_reporte[0] += 1
        Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
        datos_detalle.append([1,['Helvetica',9,colors.black],[1.50,primeralinea-datos_reporte[1]],str(reg_moneda.nombre),'l'])
        datos_reporte[1] += 0.4
        for reg_tipocambio in tipocambio.objects.filter(moneda=reg_moneda):
            if primer_tipocambio:
                datos_titulo = []
                datos_titulo.append(['Lista de Tipos de Cambio',11.50])
                datos_titulo.append([False,10.50])
                datos_titulo.append(2.00)
                datos_titulo.append(20.50)
                datos_titulo.append(0.30)
                datos_titulo.append([2.50,'fecha',5.50,'valor'])
                Acomoda(datos_detalle,datos_reporte,primeralinea,True,datos_titulo)
                primer_tipocambio=False
            datos_reporte[0] += 1
            Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
            datos_detalle.append([1,['Helvetica',9,colors.black],[2.50,primeralinea-datos_reporte[1]],str(reg_tipocambio.fecha),'l'])
            datos_detalle.append([1,['Helvetica',9,colors.black],[5.50,primeralinea-datos_reporte[1]],str(reg_tipocambio.valor),'l'])
            datos_reporte[1] += 0.4
        if not primer_tipocambio:
            datos_reporte[0] += 2
            Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
            datos_detalle.append([4,[2.00,primeralinea-datos_reporte[1]+0.2,20.50,primeralinea-datos_reporte[1]+0.2,0.3]])
            datos_detalle.append([4,[2.00,primeralinea-datos_reporte[1]+0.15,20.50,primeralinea-datos_reporte[1]+0.15,0.3]])
            datos_reporte[1] += 0.8
    if not primer_moneda:
        datos_reporte[0] += 2
        Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
        datos_detalle.append([4,[1.00,primeralinea-datos_reporte[1]+0.2,20.50,primeralinea-datos_reporte[1]+0.2,0.3]])
        datos_detalle.append([4,[1.00,primeralinea-datos_reporte[1]+0.15,20.50,primeralinea-datos_reporte[1]+0.15,0.3]])
        datos_reporte[1] += 0.8


    plan = Reporte("moneda.pdf",letter,'portrait',datos_detalle)
    plan.detalle()
    plan.grabar()
    return HttpResponseRedirect('/parametros/listar_moneda')


# Este modelo es independiente por lo que
# se elabora una lista de sus registros
class ListartipocostoView(ListView):
	# Definir el modelo a utilizar
	model = tipocosto
	# Especificar el template HTML
	template_name = 'parametros/tipocosto_list.html'

	# Prepara los context para el HTML
	def get_context_data(self,**kwargs):
		context = super(ListartipocostoView, self).get_context_data(**kwargs)
		context['lista'] = tipocosto.objects.all()
		return context

# Este modelo es independiente y esta vista
# es la utilizada para la edicion de un registro
# ya grabado en la Base de Datos
class EditartipocostoView(UpdateView):
	# Define el modelo
	model = tipocosto
	# Define el formulario
	form_class = tipocostoForm
	# Define el HTML de edicion
	template_name = 'parametros/tipocosto_update_form.html'

	# Procedimiento de salida despues de actualizacion exitosa
	def get_success_url(self):
		# Retorna al HTML de edicion con la comunicacion de correcta actualizacion
		return reverse_lazy('parametros:editar_tipocosto', args=[self.object.id]) + '?correcto'

	# Prepara los context para el HTML de edicion
	def get_context_data(self,**kwargs):
		context = super(EditartipocostoView, self).get_context_data(**kwargs)
		# Recupera el modelo a ser editado y envia su id
		tipocosto = (self.object)
		modelo = (self.object)
		context['tipocosto_id'] = self.object.id

		# Envia el context con la identificacion que se dio al borrado
		context['nombre'] = str(modelo.descripcion)
		return context

# Este modelo es independiente y esta vista
# es la utilizada para la insercion de un nuevo registro
# en la Base de Datos
class CreartipocostoView(CreateView):
	# Define el modelo cuyo registro se inserta
	model = tipocosto
	# Define el formulario de controles
	form_class = tipocostoForm
	# Define el HTML de insercion
	template_name = 'parametros/tipocosto_form.html'

	# Procedimiento de retorno por insercion exitosa
	def get_success_url(self):
		# Retorna al HTML de la lista de registros del modelo
		return reverse_lazy('parametros:listar_tipocosto') + '?correcto'
	# Prepara los context de insercion
	def get_context_data(self,**kwargs):
		context = super(CreartipocostoView, self).get_context_data(**kwargs)
		return context

# Este modelo es independiente y esta vista
# es la utilizada para el borrado de un registro
# ya grabado en la Base de Datos
class BorrartipocostoView(DeleteView):
	# Define le modelo a borrar
	model = tipocosto
	# Define el HTML de borrado
	template_name = 'parametros/tipocosto_confirm_delete.html'

	# Procedimiento de retorno por borrado exitoso
	def get_success_url(self):
		# Retorna al HTML de lista de registros del modelo
		return reverse_lazy('parametros:listar_tipocosto') + '?correcto'
	# Prepara los context de borrado
	def get_context_data(self,**kwargs):
		context = super(BorrartipocostoView, self).get_context_data(**kwargs)
		# Recupera el modelo a borrar y envia su id
		modelo = tipocosto.objects.get(id=self.object.id)
		context['nombreborrar'] = str(modelo.descripcion)
		return context

def ReportetipocostoView(request):

    # Variables del proyecto para el reporte
    primeralinea = 24.50
    maxlineas = 44

    numeroLineas = 0
    salto = 0
    pagina = 1
    
    # Lista de transferencia
    datos_detalle = []

    # Variables de reporte
    datos_reporte = []
    datos_reporte.append(numeroLineas)
    datos_reporte.append(salto)
    datos_reporte.append(pagina)
    datos_reporte.append(maxlineas)

    # Control de titulos por modelos
    primer_tipocosto = True




    for reg_tipocosto in tipocosto.objects.all():
        if primer_tipocosto:
            datos_titulo = []
            datos_titulo.append(['Lista de Tipos de Costo',10.50])
            datos_titulo.append([True,10.50])
            datos_titulo.append(1.00)
            datos_titulo.append(20.50)
            datos_titulo.append(0.30)
            datos_titulo.append([1.50,'descripcion'])
            Acomoda(datos_detalle,datos_reporte,primeralinea,True,datos_titulo)
            primer_tipocosto=False
        datos_reporte[0] += 1
        Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
        datos_detalle.append([1,['Helvetica',9,colors.black],[1.50,primeralinea-datos_reporte[1]],str(reg_tipocosto.descripcion),'l'])
        datos_reporte[1] += 0.4
    if not primer_tipocosto:
        datos_reporte[0] += 2
        Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
        datos_detalle.append([4,[1.00,primeralinea-datos_reporte[1]+0.2,20.50,primeralinea-datos_reporte[1]+0.2,0.3]])
        datos_detalle.append([4,[1.00,primeralinea-datos_reporte[1]+0.15,20.50,primeralinea-datos_reporte[1]+0.15,0.3]])
        datos_reporte[1] += 0.8


    plan = Reporte("tipocosto.pdf",letter,'portrait',datos_detalle)
    plan.detalle()
    plan.grabar()
    return HttpResponseRedirect('/parametros/listar_tipocosto')


# Este modelo es independiente por lo que
# se elabora una lista de sus registros
class ListarespecialidadView(ListView):
	# Definir el modelo a utilizar
	model = especialidad
	# Especificar el template HTML
	template_name = 'parametros/especialidad_list.html'

	# Prepara los context para el HTML
	def get_context_data(self,**kwargs):
		context = super(ListarespecialidadView, self).get_context_data(**kwargs)
		context['lista'] = especialidad.objects.all()
		return context

# Este modelo es independiente y esta vista
# es la utilizada para la edicion de un registro
# ya grabado en la Base de Datos
class EditarespecialidadView(UpdateView):
	# Define el modelo
	model = especialidad
	# Define el formulario
	form_class = especialidadForm
	# Define el HTML de edicion
	template_name = 'parametros/especialidad_update_form.html'

	# Procedimiento de salida despues de actualizacion exitosa
	def get_success_url(self):
		# Retorna al HTML de edicion con la comunicacion de correcta actualizacion
		return reverse_lazy('parametros:editar_especialidad', args=[self.object.id]) + '?correcto'

	# Prepara los context para el HTML de edicion
	def get_context_data(self,**kwargs):
		context = super(EditarespecialidadView, self).get_context_data(**kwargs)
		# Recupera el modelo a ser editado y envia su id
		especialidad = (self.object)
		modelo = (self.object)
		context['especialidad_id'] = self.object.id

		# Envia el context con la identificacion que se dio al borrado
		context['nombre'] = str(modelo.descripcion)
		return context

# Este modelo es independiente y esta vista
# es la utilizada para la insercion de un nuevo registro
# en la Base de Datos
class CrearespecialidadView(CreateView):
	# Define el modelo cuyo registro se inserta
	model = especialidad
	# Define el formulario de controles
	form_class = especialidadForm
	# Define el HTML de insercion
	template_name = 'parametros/especialidad_form.html'

	# Procedimiento de retorno por insercion exitosa
	def get_success_url(self):
		# Retorna al HTML de la lista de registros del modelo
		return reverse_lazy('parametros:listar_especialidad') + '?correcto'
	# Prepara los context de insercion
	def get_context_data(self,**kwargs):
		context = super(CrearespecialidadView, self).get_context_data(**kwargs)
		return context

# Este modelo es independiente y esta vista
# es la utilizada para el borrado de un registro
# ya grabado en la Base de Datos
class BorrarespecialidadView(DeleteView):
	# Define le modelo a borrar
	model = especialidad
	# Define el HTML de borrado
	template_name = 'parametros/especialidad_confirm_delete.html'

	# Procedimiento de retorno por borrado exitoso
	def get_success_url(self):
		# Retorna al HTML de lista de registros del modelo
		return reverse_lazy('parametros:listar_especialidad') + '?correcto'
	# Prepara los context de borrado
	def get_context_data(self,**kwargs):
		context = super(BorrarespecialidadView, self).get_context_data(**kwargs)
		# Recupera el modelo a borrar y envia su id
		modelo = especialidad.objects.get(id=self.object.id)
		context['nombreborrar'] = str(modelo.descripcion)
		return context

def ReporteespecialidadView(request):

    # Variables del proyecto para el reporte
    primeralinea = 24.50
    maxlineas = 44

    numeroLineas = 0
    salto = 0
    pagina = 1
    
    # Lista de transferencia
    datos_detalle = []

    # Variables de reporte
    datos_reporte = []
    datos_reporte.append(numeroLineas)
    datos_reporte.append(salto)
    datos_reporte.append(pagina)
    datos_reporte.append(maxlineas)

    # Control de titulos por modelos
    primer_especialidad = True




    for reg_especialidad in especialidad.objects.all():
        if primer_especialidad:
            datos_titulo = []
            datos_titulo.append(['Lista de Especialidades',10.50])
            datos_titulo.append([True,10.50])
            datos_titulo.append(1.00)
            datos_titulo.append(20.50)
            datos_titulo.append(0.30)
            datos_titulo.append([1.50,'descripcion'])
            Acomoda(datos_detalle,datos_reporte,primeralinea,True,datos_titulo)
            primer_especialidad=False
        datos_reporte[0] += 1
        Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
        datos_detalle.append([1,['Helvetica',9,colors.black],[1.50,primeralinea-datos_reporte[1]],str(reg_especialidad.descripcion),'l'])
        datos_reporte[1] += 0.4
    if not primer_especialidad:
        datos_reporte[0] += 2
        Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
        datos_detalle.append([4,[1.00,primeralinea-datos_reporte[1]+0.2,20.50,primeralinea-datos_reporte[1]+0.2,0.3]])
        datos_detalle.append([4,[1.00,primeralinea-datos_reporte[1]+0.15,20.50,primeralinea-datos_reporte[1]+0.15,0.3]])
        datos_reporte[1] += 0.8


    plan = Reporte("especialidad.pdf",letter,'portrait',datos_detalle)
    plan.detalle()
    plan.grabar()
    return HttpResponseRedirect('/parametros/listar_especialidad')






# Este modelo es dependiente de moneda
# Vista que es utilizada para la edicion del
# modelo tipocambio cuyos registros y se encuentran
# grabados en la Base de Datos
class EditartipocambioView(UpdateView):
	# El modelo que se edita
	model = tipocambio
	# El formulario para la edicion
	form_class = tipocambioForm
	# El HTML que se despliega ante el usuario
	template_name = 'parametros/tipocambio_update_form.html'

	# El procedimiento de salida de la edicion
	def get_success_url(self):
		# El modelo tipocambio es independiente
		# Despues de editar el modelo se vuelve al HTML de edicion
		# con el mensaje de actualizacion correcta del registro
		return reverse_lazy('parametros:editar_moneda', args=[self.request.GET['moneda_id']]) + '?correcto'

	# Se preparan los context para enviarlos al HTML de edicion
	def get_context_data(self,**kwargs):
		context = super(EditartipocambioView, self).get_context_data(**kwargs)
		# Se recupera el registro de tipocambio que se edita
		tipocambio = (self.object)
		modelo = (self.object)
		# Se envian al HTML el id del modelo y su campo que lo identifica
		# Este campo fue el que se definio como identificador de borrado del modelo
		context['tipocambio_id'] = self.object.id
		context['nombre'] = str(modelo.str(valor))

		# Se recupera el modelo padre y se envia su id
		context['moneda_id'] = self.object.moneda.id


		return context

# Este modelo es dependiente de moneda
# Esta vista es utilizada para el registro de nuevos
# registros del modelo tipocambio
class CreartipocambioView(CreateView):
	# Se define el modelo cuyo registro de inserta
	model = tipocambio
	# El formulario para el nuevo registro
	form_class = tipocambioForm
	# El HTML para el nuevo registro
	template_name = 'parametros/tipocambio_form.html'

	# El procedimiento de salida de la insercion
	def get_success_url(self):
		# Despues de la insercion del registro, el control
		# retorna al HTML de edicion del modelo padre
		return reverse_lazy('parametros:editar_moneda', args=[self.request.GET['moneda_id']]) + '?correcto'

	# Procedimiento para el clik de insercion
	def post(self,request,*args,**kwargs):
		# Se recupera el formulario con los controles ya llenos
		form = self.form_class(request.POST)
		# Se recupera el registro del modelo padre 
		moneda_post = moneda.objects.get(id = request.GET['moneda_id'])
		if form.is_valid():
		# El formulario es valido, no existen incongruencias
		# Se graba el registro en la base de datos pero 
		# la grabacion se mantiene pendiente, sin commit 
			tipocambio= form.save(commit=False)
			# Se asigna a tipocambio la dependencia con el modelo padre
			tipocambio.moneda = moneda_post
			# Se graba el registro definitivamente en la base de datos 
			tipocambio.save()
			# Se leva el control al procedimiento de salida por grabacion exitosa
			return HttpResponseRedirect(self.get_success_url())
		else:
			# Se leva el control al HTML de insercion grabacion no exitosa
			return self.render_to_response(self.get_context_data(form=form))

	def get_context_data(self,**kwargs):
		context = super(CreartipocambioView, self).get_context_data(**kwargs)
		# Se recupera el objeto padre y se envia su id
		context['moneda_id'] = self.request.GET['moneda_id']
		return context

# Este modelo es dependiente de moneda
# Esta vista es utilizada para el borrado de
# registros del modelo tipocambio
class BorrartipocambioView(DeleteView):
	# Se define el modelo a borrar
	model = tipocambio
	# El template HTML para desplegar la opcion de borrado
	template_name = 'parametros/tipocambio_confirm_delete.html'

	# El procedimiento de salida del borrado
	def get_success_url(self):
		# El control vuelve a la edicion del modelo padre
		return reverse_lazy('parametros:editar_moneda', args=[self.request.GET['moneda_id']]) + '?correcto'

	# Se preparan los contextos para el HTML de borrado
	def get_context_data(self,**kwargs):
		context = super(BorrartipocambioView, self).get_context_data(**kwargs)
		# Se recupera el modelo y se envia el nombre definido para el borrado
		tipocambio = tipocambio.objects.get(id=self.object.id)
		context['nombreborrar'] = str(modelo.str(valor))
		# Se recupera el modelo padre y se envia su id
		context['moneda_id'] = self.object.moneda.id

		return context







# General de Reportes
def Acomoda(datos,datos_reporte,primeralinea,titulo=False,datos_titulo=[]):

    numeroLineas = datos_reporte[0]
    pagina = datos_reporte[2]
    salto = datos_reporte[1]
    maxlineas = datos_reporte[3]

    nuevapagina = False
    if pagina == 1:
        # encabezado
        Encabezado(datos,pagina)
        salto = 0
        pagina += 1
    if numeroLineas >= maxlineas:
        nuevapagina = True
        numeroLineas = 0
        maxlineas = 50
        datos.append([0])
    if nuevapagina:
        # encabezado
        Encabezado(datos,pagina)
        salto = 0
        pass
    if titulo:
        numeroLineas += 1
        salto += 0.5    	
        datos.append([1,['Helvetica-Bold',9,colors.black],[datos_titulo[0][1],primeralinea-salto],datos_titulo[0][0],'c'])
        numeroLineas += 1
        salto += 0.4
        # Fecha
        if datos_titulo[1][0]:
            datos.append([3,['Helvetica',8,colors.red],[datos_titulo[1][1],primeralinea-salto],'c'])
            salto += 0.5
            numeroLineas += 1
        # Linea superior de columnas
        datos.append([4,[datos_titulo[2],primeralinea-salto,datos_titulo[3],primeralinea-salto,datos_titulo[4]]])    
        salto += 0.4
        # Columnas
        pos = 0
        for col in range(0,len(datos_titulo[5]),2):
            datos.append([1,['Helvetica-Bold',9,colors.black],[datos_titulo[5][col],primeralinea-salto],datos_titulo[5][col+1],'l'])
            pos+=2
        salto += 0.2
        # Linea inferior de columnas
        datos.append([4,[datos_titulo[2],primeralinea-salto,datos_titulo[3],primeralinea-salto,datos_titulo[4]]])    
        numeroLineas += 2
        salto += 0.5

    datos_reporte[0] =  numeroLineas
    datos_reporte[1] = salto 
    datos_reporte[2] = pagina 
    datos_reporte[3] = maxlineas 

def Encabezado(datos,pagina):

    anchologo=1.50
    altologo=1.50
    posxlogo=1.00
    posylogo=25.70
    posxnombre=15.00
    posynombre=26.00
    iniciolineax=1.00
    finallineax=20.50
    iniciolineay=25.30
    grosorlinea=0.90
    piex=20.50
    piey=1.00
    lineapiex = 20.50
    lineapiey=1.70
    nombre = 'controlproyectos'

    logo = None
    try:
        cd = os.getcwd()
        logo = cd + '/core/static/core/img/logo.png'
    except:
        pass     

    datos.append([2,logo,[posxlogo,posylogo],[anchologo,altologo]])       
    datos.append([1,['Helvetica',20,colors.black],[posxnombre,posynombre],nombre,'c'])
    datos.append([4,[iniciolineax,iniciolineay,finallineax, iniciolineay,grosorlinea]])
    # Pie
    datos.append([1,['Helvetica',8,colors.black],[piex,piey],'Pag. ' + str(pagina),'c'])
    datos.append([4,[iniciolineax,lineapiey,lineapiex,lineapiey,grosorlinea]])    
