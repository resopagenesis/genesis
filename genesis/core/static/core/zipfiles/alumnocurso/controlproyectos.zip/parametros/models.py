from django.db import models
from ckeditor.fields import RichTextField
from django.core.exceptions import ValidationError
from django.utils.translation import ugettext_lazy as _
from django.urls import reverse, reverse_lazy
from django.utils import timezone
from django.contrib.auth.models import User


# Modelos Foreign




# Crear los modelo aqui.


class tipo(models.Model):


	nombre = models.CharField(max_length=30,default='')


	def __str__(self):
		return self.nombre

class especialidad(models.Model):


	descripcion = models.CharField(max_length=30,default='')


	def __str__(self):
		return self.descripcion

class tipocosto(models.Model):


	descripcion = models.CharField(max_length=30,default='')


	def __str__(self):
		return self.descripcion

class moneda(models.Model):


	nombre = models.CharField(max_length=30,default='')


	def __str__(self):
		return self.nombre

class tipocambio(models.Model):


	fecha = models.DateField(default=timezone.now)
	valor =  models.DecimalField(default=0,decimal_places=2,max_digits=10)
	moneda =  models.ForeignKey(moneda, on_delete=models.CASCADE)


	def __str__(self):
		return str(self.valor)



