from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from parametros.models import tipo
from parametros.models import moneda
from parametros.models import tipocambio
from parametros.models import tipocosto
from parametros.models import especialidad







class tipoForm(forms.ModelForm):
	class Meta:
		model = tipo
		fields = ('nombre',)
		widgets = {
			'nombre': forms.TextInput(attrs={'class':'form-control font_control_tipo mt-1', 'placeholder': ''}),

		}
		labels = {
		'nombre':'nombre',
		}


class monedaForm(forms.ModelForm):
	class Meta:
		model = moneda
		fields = ('nombre',)
		widgets = {
			'nombre': forms.TextInput(attrs={'class':'form-control font_control_moneda mt-1', 'placeholder': ''}),

		}
		labels = {
		'nombre':'Nombre',
		}


class tipocambioForm(forms.ModelForm):
	class Meta:
		model = tipocambio
		fields = ('fecha','valor',)
		widgets = {
			'fecha': forms.DateInput(attrs={'class':'datepicker form-control  font_control_tipocambio mt-1'},format="%m/%d/%Y"),
			'valor': forms.TextInput(attrs={'class':'form-control  font_control_tipocambio mt-1', 'placeholder': ''}),

		}
		labels = {
		'fecha':'Fecha','valor':'Valor',
		}


class tipocostoForm(forms.ModelForm):
	class Meta:
		model = tipocosto
		fields = ('descripcion',)
		widgets = {
			'descripcion': forms.TextInput(attrs={'class':'form-control font_control_tipocosto mt-1', 'placeholder': ''}),

		}
		labels = {
		'descripcion':'Descripcion',
		}


class especialidadForm(forms.ModelForm):
	class Meta:
		model = especialidad
		fields = ('descripcion',)
		widgets = {
			'descripcion': forms.TextInput(attrs={'class':'form-control font_control_especialidad mt-1', 'placeholder': ''}),

		}
		labels = {
		'descripcion':'descripcion',
		}





