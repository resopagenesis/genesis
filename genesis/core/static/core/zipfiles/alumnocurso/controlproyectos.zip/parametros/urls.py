from django.urls import path
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required

from .views import HomeView
from .views import ListartipoView, CreartipoView, EditartipoView, BorrartipoView, ReportetipoView
from .views import ListarmonedaView, CrearmonedaView, EditarmonedaView, BorrarmonedaView, ReportemonedaView
from .views import CreartipocambioView, EditartipocambioView, BorrartipocambioView
from .views import ListartipocostoView, CreartipocostoView, EditartipocostoView, BorrartipocostoView, ReportetipocostoView
from .views import ListarespecialidadView, CrearespecialidadView, EditarespecialidadView, BorrarespecialidadView, ReporteespecialidadView




parametros_patterns = ([
	path('',(HomeView.as_view()), name='home'),
	path('listar_tipo/',(ListartipoView.as_view()), name='listar_tipo'),
	path('reporte_tipo/',ReportetipoView, name='reporte_tipo'),
	path('editar_tipo/<int:pk>/',(EditartipoView.as_view()), name='editar_tipo'),
	path('crear_tipo/',(CreartipoView.as_view()), name='crear_tipo'),
	path('borrar_tipo/<int:pk>/',(BorrartipoView.as_view()), name='borrar_tipo'),

	path('listar_moneda/',(ListarmonedaView.as_view()), name='listar_moneda'),
	path('reporte_moneda/',ReportemonedaView, name='reporte_moneda'),
	path('editar_moneda/<int:pk>/',(EditarmonedaView.as_view()), name='editar_moneda'),
	path('crear_moneda/',(CrearmonedaView.as_view()), name='crear_moneda'),
	path('borrar_moneda/<int:pk>/',(BorrarmonedaView.as_view()), name='borrar_moneda'),

	path('editar_tipocambio/<int:pk>/',(EditartipocambioView.as_view()), name='editar_tipocambio'),
	path('crear_tipocambio/',(CreartipocambioView.as_view()), name='crear_tipocambio'),
	path('borrar_tipocambio/<int:pk>/',(BorrartipocambioView.as_view()), name='borrar_tipocambio'),

	path('listar_tipocosto/',(ListartipocostoView.as_view()), name='listar_tipocosto'),
	path('reporte_tipocosto/',ReportetipocostoView, name='reporte_tipocosto'),
	path('editar_tipocosto/<int:pk>/',(EditartipocostoView.as_view()), name='editar_tipocosto'),
	path('crear_tipocosto/',(CreartipocostoView.as_view()), name='crear_tipocosto'),
	path('borrar_tipocosto/<int:pk>/',(BorrartipocostoView.as_view()), name='borrar_tipocosto'),

	path('listar_especialidad/',(ListarespecialidadView.as_view()), name='listar_especialidad'),
	path('reporte_especialidad/',ReporteespecialidadView, name='reporte_especialidad'),
	path('editar_especialidad/<int:pk>/',(EditarespecialidadView.as_view()), name='editar_especialidad'),
	path('crear_especialidad/',(CrearespecialidadView.as_view()), name='crear_especialidad'),
	path('borrar_especialidad/<int:pk>/',(BorrarespecialidadView.as_view()), name='borrar_especialidad'),



], 'parametros')

