from django.shortcuts import render
from django.views.generic.list import ListView
from django.views.generic.edit import CreateView, UpdateView, DeleteView, FormView
from django.views.generic.base import TemplateView
from django.urls import reverse, reverse_lazy
from django.http import HttpResponseRedirect
from django.db.models import Sum, Count, Avg, Q
import random
import datetime
from django import forms
import time
import os

# Reporte

from core.views import Reporte
from reportlab.lib.pagesizes import letter,landscape,portrait,A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch, mm, cm
from reportlab.lib import colors


from proyectos.models import recurso
from proyectos.models import proyecto
from proyectos.models import empresa
from proyectos.models import actividad
from proyectos.models import costo
from proyectos.models import asignacion

#@(p_importmodelos_02)
from parametros.models import tipocambio

#@()


from parametros.models import especialidad
from parametros.models import tipocosto
from parametros.models import moneda

from .forms import recursoForm
from .forms import proyectoForm
from .forms import actividadForm
from .forms import costoForm
from .forms import asignacionForm
from .forms import empresaForm




# Create your views here.
class HomeView(TemplateView):
	template_name = 'proyectos/home.html'

# Este modelo es independiente por lo que
# se elabora una lista de sus registros
class ListarrecursoView(ListView):
	# Definir el modelo a utilizar
	model = recurso
	# Especificar el template HTML
	template_name = 'proyectos/recurso_list.html'

	# Prepara los context para el HTML
	def get_context_data(self,**kwargs):
		context = super(ListarrecursoView, self).get_context_data(**kwargs)
		try:
		# La lista tiene un buscador para seleccionar los registros
		# a traves del parametro GET criterio
			context['criterio'] = self.request.GET['criterio']
			# Si criterio es * se buscan todos los registros
			if context['criterio'] =='*':
				context['lista'] = recurso.objects.all()
			# Si criterio es blaco no se buscan registros
			elif context['criterio'] =='':
				context['lista'] = None
			else:
				# Se busca el criterio en todas las propiedades marcadas para ese fin
				context['lista'] = recurso.objects.filter(nombre__icontains = context['criterio'])|recurso.objects.filter(costohora__icontains = context['criterio'])
		except:
			# En caso de error no se buscan registros
			context['criterio'] = ''
		return context

# Este modelo es independiente y esta vista
# es la utilizada para la edicion de un registro
# ya grabado en la Base de Datos
class EditarrecursoView(UpdateView):
	# Define el modelo
	model = recurso
	# Define el formulario
	form_class = recursoForm
	# Define el HTML de edicion
	template_name = 'proyectos/recurso_update_form.html'

	# Procedimiento de salida despues de actualizacion exitosa
	def get_success_url(self):
		# Retorna al HTML de edicion con la comunicacion de correcta actualizacion
		return reverse_lazy('proyectos:editar_recurso', args=[self.object.id]) + '?correcto'

	# Prepara los context para el HTML de edicion
	def get_context_data(self,**kwargs):
		context = super(EditarrecursoView, self).get_context_data(**kwargs)
		# Recupera el modelo a ser editado y envia su id
		recurso = (self.object)
		modelo = (self.object)
		context['recurso_id'] = self.object.id

		# Envia el context con la identificacion que se dio al borrado
		context['nombre'] = str(modelo.nombre)
		return context

# Este modelo es independiente y esta vista
# es la utilizada para la insercion de un nuevo registro
# en la Base de Datos
class CrearrecursoView(CreateView):
	# Define el modelo cuyo registro se inserta
	model = recurso
	# Define el formulario de controles
	form_class = recursoForm
	# Define el HTML de insercion
	template_name = 'proyectos/recurso_form.html'

	# Procedimiento de retorno por insercion exitosa
	def get_success_url(self):
		# Retorna al HTML de la lista de registros del modelo
		return reverse_lazy('proyectos:listar_recurso') + '?correcto'
	# Prepara los context de insercion
	def get_context_data(self,**kwargs):
		context = super(CrearrecursoView, self).get_context_data(**kwargs)
		return context

# Este modelo es independiente y esta vista
# es la utilizada para el borrado de un registro
# ya grabado en la Base de Datos
class BorrarrecursoView(DeleteView):
	# Define le modelo a borrar
	model = recurso
	# Define el HTML de borrado
	template_name = 'proyectos/recurso_confirm_delete.html'

	# Procedimiento de retorno por borrado exitoso
	def get_success_url(self):
		# Retorna al HTML de lista de registros del modelo
		return reverse_lazy('proyectos:listar_recurso') + '?correcto'
	# Prepara los context de borrado
	def get_context_data(self,**kwargs):
		context = super(BorrarrecursoView, self).get_context_data(**kwargs)
		# Recupera el modelo a borrar y envia su id
		modelo = recurso.objects.get(id=self.object.id)
		context['nombreborrar'] = str(modelo.nombre)
		return context

def ReporterecursoView(request):

    # Variables del proyecto para el reporte
    primeralinea = 24.50
    maxlineas = 44

    numeroLineas = 0
    salto = 0
    pagina = 1
    
    # Lista de transferencia
    datos_detalle = []

    # Variables de reporte
    datos_reporte = []
    datos_reporte.append(numeroLineas)
    datos_reporte.append(salto)
    datos_reporte.append(pagina)
    datos_reporte.append(maxlineas)

    # Control de titulos por modelos
    primer_recurso = True




    for reg_recurso in recurso.objects.all():
        if primer_recurso:
            datos_titulo = []
            datos_titulo.append(['Lista de los Recursos',10.50])
            datos_titulo.append([True,10.50])
            datos_titulo.append(1.00)
            datos_titulo.append(20.50)
            datos_titulo.append(0.30)
            datos_titulo.append([1.50,'nombre',4.50,'costohora',9.00,'especialidad'])
            Acomoda(datos_detalle,datos_reporte,primeralinea,True,datos_titulo)
            primer_recurso=False
        datos_reporte[0] += 1
        Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
        datos_detalle.append([1,['Helvetica',9,colors.black],[1.50,primeralinea-datos_reporte[1]],str(reg_recurso.nombre),'l'])
        datos_detalle.append([1,['Helvetica',9,colors.black],[4.50,primeralinea-datos_reporte[1]],str(reg_recurso.costohora),'l'])
        datos_detalle.append([1,['Helvetica',9,colors.black],[9.00,primeralinea-datos_reporte[1]],str(reg_recurso.especialidad),'l'])
        datos_reporte[1] += 0.4
    if not primer_recurso:
        datos_reporte[0] += 2
        Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
        datos_detalle.append([4,[1.00,primeralinea-datos_reporte[1]+0.2,20.50,primeralinea-datos_reporte[1]+0.2,0.3]])
        datos_detalle.append([4,[1.00,primeralinea-datos_reporte[1]+0.15,20.50,primeralinea-datos_reporte[1]+0.15,0.3]])
        datos_reporte[1] += 0.8


    plan = Reporte("recurso.pdf",letter,'portrait',datos_detalle)
    plan.detalle()
    plan.grabar()
    return HttpResponseRedirect('/proyectos/listar_recurso')


# Este modelo es independiente por lo que
# se elabora una lista de sus registros
class ListarasignacionView(ListView):
	# Definir el modelo a utilizar
	model = asignacion
	# Especificar el template HTML
	template_name = 'proyectos/asignacion_list.html'

	# Prepara los context para el HTML
	def get_context_data(self,**kwargs):
		context = super(ListarasignacionView, self).get_context_data(**kwargs)
		context['lista'] = asignacion.objects.all()
		return context

# Este modelo es independiente y esta vista
# es la utilizada para la edicion de un registro
# ya grabado en la Base de Datos
class EditarasignacionView(UpdateView):
	# Define el modelo
	model = asignacion
	# Define el formulario
	form_class = asignacionForm
	# Define el HTML de edicion
	template_name = 'proyectos/asignacion_update_form.html'

	# Procedimiento de salida despues de actualizacion exitosa
	def get_success_url(self):
		# Retorna al HTML de edicion con la comunicacion de correcta actualizacion
		return reverse_lazy('proyectos:editar_asignacion', args=[self.object.id]) + '?correcto'

	# Prepara los context para el HTML de edicion
	def get_context_data(self,**kwargs):
		context = super(EditarasignacionView, self).get_context_data(**kwargs)
		# Recupera el modelo a ser editado y envia su id
		asignacion = (self.object)
		modelo = (self.object)
		context['asignacion_id'] = self.object.id

		# Envia el context con la identificacion que se dio al borrado
		context['nombre'] = str(modelo.recurso )+ '-' + str(modelo.actividad)
		return context

# Este modelo es independiente y esta vista
# es la utilizada para la insercion de un nuevo registro
# en la Base de Datos
class CrearasignacionView(CreateView):
	# Define el modelo cuyo registro se inserta
	model = asignacion
	# Define el formulario de controles
	form_class = asignacionForm
	# Define el HTML de insercion
	template_name = 'proyectos/asignacion_form.html'

	# Procedimiento de retorno por insercion exitosa
	def get_success_url(self):
		# Retorna al HTML de la lista de registros del modelo
		return reverse_lazy('proyectos:listar_asignacion') + '?correcto'
	# Prepara los context de insercion
	def get_context_data(self,**kwargs):
		context = super(CrearasignacionView, self).get_context_data(**kwargs)
		return context

# Este modelo es independiente y esta vista
# es la utilizada para el borrado de un registro
# ya grabado en la Base de Datos
class BorrarasignacionView(DeleteView):
	# Define le modelo a borrar
	model = asignacion
	# Define el HTML de borrado
	template_name = 'proyectos/asignacion_confirm_delete.html'

	# Procedimiento de retorno por borrado exitoso
	def get_success_url(self):
		# Retorna al HTML de lista de registros del modelo
		return reverse_lazy('proyectos:listar_asignacion') + '?correcto'
	# Prepara los context de borrado
	def get_context_data(self,**kwargs):
		context = super(BorrarasignacionView, self).get_context_data(**kwargs)
		# Recupera el modelo a borrar y envia su id
		modelo = asignacion.objects.get(id=self.object.id)
		context['nombreborrar'] = str(modelo.recurso )+ '-' + str(modelo.actividad)
		return context

def ReporteasignacionView(request):

    # Variables del proyecto para el reporte
    primeralinea = 24.50
    maxlineas = 44

    numeroLineas = 0
    salto = 0
    pagina = 1
    
    # Lista de transferencia
    datos_detalle = []

    # Variables de reporte
    datos_reporte = []
    datos_reporte.append(numeroLineas)
    datos_reporte.append(salto)
    datos_reporte.append(pagina)
    datos_reporte.append(maxlineas)

    # Control de titulos por modelos
    primer_asignacion = True




    for reg_asignacion in asignacion.objects.all():
        if primer_asignacion:
            datos_titulo = []
            datos_titulo.append(['Lista de Asignaciones',10.50])
            datos_titulo.append([True,10.50])
            datos_titulo.append(1.00)
            datos_titulo.append(20.50)
            datos_titulo.append(0.30)
            datos_titulo.append([1.50,'diaAsignado',4.50,'horaInicio',9.00,'horas',13.50,'recurso',18.00,'actividad'])
            Acomoda(datos_detalle,datos_reporte,primeralinea,True,datos_titulo)
            primer_asignacion=False
        datos_reporte[0] += 1
        Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
        datos_detalle.append([1,['Helvetica',9,colors.black],[1.50,primeralinea-datos_reporte[1]],str(reg_asignacion.diaAsignado),'l'])
        datos_detalle.append([1,['Helvetica',9,colors.black],[4.50,primeralinea-datos_reporte[1]],str(reg_asignacion.horaInicio),'l'])
        datos_detalle.append([1,['Helvetica',9,colors.black],[9.00,primeralinea-datos_reporte[1]],str(reg_asignacion.horas),'l'])
        datos_detalle.append([1,['Helvetica',9,colors.black],[13.50,primeralinea-datos_reporte[1]],str(reg_asignacion.recurso),'l'])
        datos_detalle.append([1,['Helvetica',9,colors.black],[18.00,primeralinea-datos_reporte[1]],str(reg_asignacion.actividad),'l'])
        datos_reporte[1] += 0.4
    if not primer_asignacion:
        datos_reporte[0] += 2
        Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
        datos_detalle.append([4,[1.00,primeralinea-datos_reporte[1]+0.2,20.50,primeralinea-datos_reporte[1]+0.2,0.3]])
        datos_detalle.append([4,[1.00,primeralinea-datos_reporte[1]+0.15,20.50,primeralinea-datos_reporte[1]+0.15,0.3]])
        datos_reporte[1] += 0.8


    plan = Reporte("asignacion.pdf",letter,'portrait',datos_detalle)
    plan.detalle()
    plan.grabar()
    return HttpResponseRedirect('/proyectos/listar_asignacion')


# Este modelo es independiente por lo que
# se elabora una lista de sus registros
class ListarempresaView(ListView):
	# Definir el modelo a utilizar
	model = empresa
	# Especificar el template HTML
	template_name = 'proyectos/empresa_list.html'

	# Prepara los context para el HTML
	def get_context_data(self,**kwargs):
		context = super(ListarempresaView, self).get_context_data(**kwargs)
		context['lista'] = empresa.objects.all()
		return context

# Este modelo es independiente y esta vista
# es la utilizada para la edicion de un registro
# ya grabado en la Base de Datos
class EditarempresaView(UpdateView):
	# Define el modelo
	model = empresa
	# Define el formulario
	form_class = empresaForm
	# Define el HTML de edicion
	template_name = 'proyectos/empresa_update_form.html'

	# Procedimiento de salida despues de actualizacion exitosa
	def get_success_url(self):
		# Retorna al HTML de edicion con la comunicacion de correcta actualizacion
		return reverse_lazy('proyectos:editar_empresa', args=[self.object.id]) + '?correcto'

	# Prepara los context para el HTML de edicion
	def get_context_data(self,**kwargs):
		context = super(EditarempresaView, self).get_context_data(**kwargs)
		# Recupera el modelo a ser editado y envia su id
		empresa = (self.object)
		modelo = (self.object)
		context['empresa_id'] = self.object.id
		proyecto_lista = proyecto.objects.filter(empresa = empresa)
		context['listaproyecto'] =  proyecto_lista

		# Envia el context con la identificacion que se dio al borrado
		context['nombre'] = str(modelo.nombre)
		# Envia el cotext con el numero de modelos dependientes
		context['numeroproyecto'] = proyecto.objects.filter(empresa=empresa).count()
		return context

# Este modelo es independiente y esta vista
# es la utilizada para la insercion de un nuevo registro
# en la Base de Datos
class CrearempresaView(CreateView):
	# Define el modelo cuyo registro se inserta
	model = empresa
	# Define el formulario de controles
	form_class = empresaForm
	# Define el HTML de insercion
	template_name = 'proyectos/empresa_form.html'

	# Procedimiento de retorno por insercion exitosa
	def get_success_url(self):
		# Retorna al HTML de la lista de registros del modelo
		return reverse_lazy('proyectos:listar_empresa') + '?correcto'
	# Prepara los context de insercion
	def get_context_data(self,**kwargs):
		context = super(CrearempresaView, self).get_context_data(**kwargs)
		return context

# Este modelo es independiente y esta vista
# es la utilizada para el borrado de un registro
# ya grabado en la Base de Datos
class BorrarempresaView(DeleteView):
	# Define le modelo a borrar
	model = empresa
	# Define el HTML de borrado
	template_name = 'proyectos/empresa_confirm_delete.html'

	# Procedimiento de retorno por borrado exitoso
	def get_success_url(self):
		# Retorna al HTML de lista de registros del modelo
		return reverse_lazy('proyectos:listar_empresa') + '?correcto'
	# Prepara los context de borrado
	def get_context_data(self,**kwargs):
		context = super(BorrarempresaView, self).get_context_data(**kwargs)
		# Recupera el modelo a borrar y envia su id
		modelo = empresa.objects.get(id=self.object.id)
		context['nombreborrar'] = str(modelo.nombre)
		return context

def ReporteempresaView(request):

    # Variables del proyecto para el reporte
    primeralinea = 24.50
    maxlineas = 44

    numeroLineas = 0
    salto = 0
    pagina = 1
    
    # Lista de transferencia
    datos_detalle = []

    # Variables de reporte
    datos_reporte = []
    datos_reporte.append(numeroLineas)
    datos_reporte.append(salto)
    datos_reporte.append(pagina)
    datos_reporte.append(maxlineas)

    # Control de titulos por modelos
    primer_empresa = True
    primer_proyecto = True
    primer_actividad = True
    primer_costo = True




    for reg_empresa in empresa.objects.all():
        if primer_empresa:
            datos_titulo = []
            datos_titulo.append(['Lista de Empresas',10.50])
            datos_titulo.append([True,10.50])
            datos_titulo.append(1.00)
            datos_titulo.append(20.50)
            datos_titulo.append(0.30)
            datos_titulo.append([1.50,'nombre'])
            Acomoda(datos_detalle,datos_reporte,primeralinea,True,datos_titulo)
            primer_empresa=False
        primer_proyecto=True
        datos_reporte[0] += 1
        Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
        datos_detalle.append([1,['Helvetica',9,colors.black],[1.50,primeralinea-datos_reporte[1]],str(reg_empresa.nombre),'l'])
        datos_reporte[1] += 0.4
        for reg_proyecto in proyecto.objects.filter(empresa=reg_empresa):
            if primer_proyecto:
                datos_titulo = []
                datos_titulo.append(['Lista de Proyectos',11.50])
                datos_titulo.append([False,10.50])
                datos_titulo.append(2.00)
                datos_titulo.append(20.50)
                datos_titulo.append(0.30)
                datos_titulo.append([2.50,'descripcion',5.50,'fechaInicio',10.00,'fechaFin',14.50,'tipo',19.00,'responsable'])
                Acomoda(datos_detalle,datos_reporte,primeralinea,True,datos_titulo)
                primer_proyecto=False
            primer_actividad=True
            datos_reporte[0] += 1
            Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
            datos_detalle.append([1,['Helvetica',9,colors.black],[2.50,primeralinea-datos_reporte[1]],str(reg_proyecto.descripcion),'l'])
            datos_detalle.append([1,['Helvetica',9,colors.black],[5.50,primeralinea-datos_reporte[1]],str(reg_proyecto.fechaInicio),'l'])
            datos_detalle.append([1,['Helvetica',9,colors.black],[10.00,primeralinea-datos_reporte[1]],str(reg_proyecto.fechaFin),'l'])
            datos_detalle.append([1,['Helvetica',9,colors.black],[14.50,primeralinea-datos_reporte[1]],str(reg_proyecto.tipo),'l'])
            datos_detalle.append([1,['Helvetica',9,colors.black],[19.00,primeralinea-datos_reporte[1]],str(reg_proyecto.responsable),'l'])
            datos_reporte[1] += 0.4
            for reg_actividad in actividad.objects.filter(proyecto=reg_proyecto):
                if primer_actividad:
                    datos_titulo = []
                    datos_titulo.append(['Lista de Actividades',12.50])
                    datos_titulo.append([False,10.50])
                    datos_titulo.append(3.00)
                    datos_titulo.append(20.50)
                    datos_titulo.append(0.30)
                    datos_titulo.append([3.50,'descripcion',6.50,'fechaInicio',11.00,'fechaFin'])
                    Acomoda(datos_detalle,datos_reporte,primeralinea,True,datos_titulo)
                    primer_actividad=False
                primer_costo=True
                datos_reporte[0] += 1
                Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
                datos_detalle.append([1,['Helvetica',9,colors.black],[3.50,primeralinea-datos_reporte[1]],str(reg_actividad.descripcion),'l'])
                datos_detalle.append([1,['Helvetica',9,colors.black],[6.50,primeralinea-datos_reporte[1]],str(reg_actividad.fechaInicio),'l'])
                datos_detalle.append([1,['Helvetica',9,colors.black],[11.00,primeralinea-datos_reporte[1]],str(reg_actividad.fechaFin),'l'])
                datos_reporte[1] += 0.4
                for reg_costo in costo.objects.filter(actividad=reg_actividad):
                    if primer_costo:
                        datos_titulo = []
                        datos_titulo.append(['Lista de Costos',13.50])
                        datos_titulo.append([False,10.50])
                        datos_titulo.append(4.00)
                        datos_titulo.append(20.50)
                        datos_titulo.append(0.30)
                        datos_titulo.append([4.50,'tipocosto',7.50,'importe',12.00,'moneda',16.50,'fecha'])
                        Acomoda(datos_detalle,datos_reporte,primeralinea,True,datos_titulo)
                        primer_costo=False
                    datos_reporte[0] += 1
                    Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
                    datos_detalle.append([1,['Helvetica',9,colors.black],[4.50,primeralinea-datos_reporte[1]],str(reg_costo.tipocosto),'l'])
                    datos_detalle.append([1,['Helvetica',9,colors.black],[7.50,primeralinea-datos_reporte[1]],str(reg_costo.importe),'l'])
                    datos_detalle.append([1,['Helvetica',9,colors.black],[12.00,primeralinea-datos_reporte[1]],str(reg_costo.moneda),'l'])
                    datos_detalle.append([1,['Helvetica',9,colors.black],[16.50,primeralinea-datos_reporte[1]],str(reg_costo.fecha),'l'])
                    datos_reporte[1] += 0.4
                if not primer_costo:
                    datos_reporte[0] += 2
                    Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
                    datos_detalle.append([4,[4.00,primeralinea-datos_reporte[1]+0.2,20.50,primeralinea-datos_reporte[1]+0.2,0.3]])
                    datos_detalle.append([4,[4.00,primeralinea-datos_reporte[1]+0.15,20.50,primeralinea-datos_reporte[1]+0.15,0.3]])
                    datos_reporte[1] += 0.8
            if not primer_actividad:
                datos_reporte[0] += 2
                Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
                datos_detalle.append([4,[3.00,primeralinea-datos_reporte[1]+0.2,20.50,primeralinea-datos_reporte[1]+0.2,0.3]])
                datos_detalle.append([4,[3.00,primeralinea-datos_reporte[1]+0.15,20.50,primeralinea-datos_reporte[1]+0.15,0.3]])
                datos_reporte[1] += 0.8
        if not primer_proyecto:
            datos_reporte[0] += 2
            Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
            datos_detalle.append([4,[2.00,primeralinea-datos_reporte[1]+0.2,20.50,primeralinea-datos_reporte[1]+0.2,0.3]])
            datos_detalle.append([4,[2.00,primeralinea-datos_reporte[1]+0.15,20.50,primeralinea-datos_reporte[1]+0.15,0.3]])
            datos_reporte[1] += 0.8
    if not primer_empresa:
        datos_reporte[0] += 2
        Acomoda(datos_detalle,datos_reporte,primeralinea,False,datos_titulo)
        datos_detalle.append([4,[1.00,primeralinea-datos_reporte[1]+0.2,20.50,primeralinea-datos_reporte[1]+0.2,0.3]])
        datos_detalle.append([4,[1.00,primeralinea-datos_reporte[1]+0.15,20.50,primeralinea-datos_reporte[1]+0.15,0.3]])
        datos_reporte[1] += 0.8


    plan = Reporte("empresa.pdf",letter,'portrait',datos_detalle)
    plan.detalle()
    plan.grabar()
    return HttpResponseRedirect('/proyectos/listar_empresa')






# Este modelo es dependiente de empresa
# Vista que es utilizada para la edicion del
# modelo proyecto cuyos registros y se encuentran
# grabados en la Base de Datos
class EditarproyectoView(UpdateView):
	# El modelo que se edita
	model = proyecto
	# El formulario para la edicion
	form_class = proyectoForm
	# El HTML que se despliega ante el usuario
	template_name = 'proyectos/proyecto_update_form.html'

	# El procedimiento de salida de la edicion
	def get_success_url(self):
		# El modelo proyecto es independiente
		# Despues de editar el modelo se vuelve al HTML de edicion
		# con el mensaje de actualizacion correcta del registro
		return reverse_lazy('proyectos:editar_empresa', args=[self.request.GET['empresa_id']]) + '?correcto'

	# Se preparan los context para enviarlos al HTML de edicion
	def get_context_data(self,**kwargs):
		context = super(EditarproyectoView, self).get_context_data(**kwargs)
		# Se recupera el registro de proyecto que se edita
		proyecto = (self.object)
		modelo = (self.object)
		# Se envian al HTML el id del modelo y su campo que lo identifica
		# Este campo fue el que se definio como identificador de borrado del modelo
		context['proyecto_id'] = self.object.id
		context['nombre'] = str(modelo.descripcion)
		# Se envia al HTML la lista de los modelos dependientes de @modelo
		actividad_actividad = actividad.objects.filter(proyecto = proyecto)
		context['listaactividad'] =  actividad_actividad

		# Se recupera el modelo padre y se envia su id
		context['empresa_id'] = self.object.empresa.id

# Se envia al HTML el numero de modelos dependientes de proyecto
		context['numeroactividad'] = actividad.objects.filter(proyecto=proyecto).count()

		return context

# Este modelo es dependiente de empresa
# Esta vista es utilizada para el registro de nuevos
# registros del modelo proyecto
class CrearproyectoView(CreateView):
	# Se define el modelo cuyo registro de inserta
	model = proyecto
	# El formulario para el nuevo registro
	form_class = proyectoForm
	# El HTML para el nuevo registro
	template_name = 'proyectos/proyecto_form.html'

	# El procedimiento de salida de la insercion
	def get_success_url(self):
		# Despues de la insercion del registro, el control
		# retorna al HTML de edicion del modelo padre
		return reverse_lazy('proyectos:editar_empresa', args=[self.request.GET['empresa_id']]) + '?correcto'

	# Procedimiento para el clik de insercion
	def post(self,request,*args,**kwargs):
		# Se recupera el formulario con los controles ya llenos
		form = self.form_class(request.POST)
		# Se recupera el registro del modelo padre 
		empresa_post = empresa.objects.get(id = request.GET['empresa_id'])
		if form.is_valid():
		# El formulario es valido, no existen incongruencias
		# Se graba el registro en la base de datos pero 
		# la grabacion se mantiene pendiente, sin commit 
			proyecto= form.save(commit=False)
			# Se asigna a proyecto la dependencia con el modelo padre
			proyecto.empresa = empresa_post
			# Se graba el registro definitivamente en la base de datos 
			proyecto.save()
			# Se leva el control al procedimiento de salida por grabacion exitosa
			return HttpResponseRedirect(self.get_success_url())
		else:
			# Se leva el control al HTML de insercion grabacion no exitosa
			return self.render_to_response(self.get_context_data(form=form))

	def get_context_data(self,**kwargs):
		context = super(CrearproyectoView, self).get_context_data(**kwargs)
		# Se recupera el objeto padre y se envia su id
		context['empresa_id'] = self.request.GET['empresa_id']
		return context

# Este modelo es dependiente de empresa
# Esta vista es utilizada para el borrado de
# registros del modelo proyecto
class BorrarproyectoView(DeleteView):
	# Se define el modelo a borrar
	model = proyecto
	# El template HTML para desplegar la opcion de borrado
	template_name = 'proyectos/proyecto_confirm_delete.html'

	# El procedimiento de salida del borrado
	def get_success_url(self):
		# El control vuelve a la edicion del modelo padre
		return reverse_lazy('proyectos:editar_empresa', args=[self.request.GET['empresa_id']]) + '?correcto'

	# Se preparan los contextos para el HTML de borrado
	def get_context_data(self,**kwargs):
		context = super(BorrarproyectoView, self).get_context_data(**kwargs)
		# Se recupera el modelo y se envia el nombre definido para el borrado
		proyecto = proyecto.objects.get(id=self.object.id)
		context['nombreborrar'] = str(modelo.descripcion)
		# Se recupera el modelo padre y se envia su id
		context['empresa_id'] = self.object.empresa.id

		return context

# Este modelo es dependiente de proyecto
# Vista que es utilizada para la edicion del
# modelo actividad cuyos registros y se encuentran
# grabados en la Base de Datos
class EditaractividadView(UpdateView):
	# El modelo que se edita
	model = actividad
	# El formulario para la edicion
	form_class = actividadForm
	# El HTML que se despliega ante el usuario
	template_name = 'proyectos/actividad_update_form.html'

	# El procedimiento de salida de la edicion
	def get_success_url(self):
		# El modelo actividad es dependiente
		# Despues de editar el modelo se vuelve al HTML de edicion
		# con el mensaje de actualizacion correcta del registro
		return reverse_lazy('proyectos:editar_proyecto', args=[self.request.GET['proyecto_id']]) + '?correcto' + '&empresa_id=' + str(self.request.GET['empresa_id'])

	# Se preparan los context para enviarlos al HTML de edicion
	def get_context_data(self,**kwargs):
		context = super(EditaractividadView, self).get_context_data(**kwargs)
		# Se recupera el registro de actividad que se edita
		actividad = (self.object)
		modelo = (self.object)
		# Se envian al HTML el id del modelo y su campo que lo identifica
		# Este campo fue el que se definio como identificador de borrado del modelo
		context['actividad_id'] = self.object.id
		context['nombre'] = str(modelo.descripcion)
		# Se envia al HTML la lista de los modelos dependientes de @modelo
		costo_costo = costo.objects.filter(actividad = actividad)
		context['listacosto'] =  costo_costo
#@(p_editar_context_lista_hijosactividad_02)
		lista = []
		for co in costo_costo:
			try:
				tc = tipocambio.objects.get(moneda=co.moneda,fecha=co.fecha).valor
			except:
				tc = -1
			lista.append([co,co.importe*tc])
		context['listacosto'] = lista

#@()

		context['proyecto_id'] = self.object.proyecto.id
		# Se recupera el modelo abuelo y se envia su id
		proyecto_proyecto = proyecto.objects.get(id=self.object.proyecto.id)
		context['empresa_id'] = proyecto_proyecto.empresa.id

# Se envia al HTML el numero de modelos dependientes de actividad
		context['numerocosto'] = costo.objects.filter(actividad=actividad).count()

		return context

# Este modelo es dependiente de proyecto
# Esta vista es utilizada para el registro de nuevos
# registros del modelo actividad
class CrearactividadView(CreateView):
	# Se define el modelo cuyo registro de inserta
	model = actividad
	# El formulario para el nuevo registro
	form_class = actividadForm
	# El HTML para el nuevo registro
	template_name = 'proyectos/actividad_form.html'

	# El procedimiento de salida de la insercion
	def get_success_url(self):
		# Despues de la insercion del registro, el control
		# retorna al HTML de edicion del modelo padre
		return reverse_lazy('proyectos:editar_proyecto', args=[self.request.GET['proyecto_id']]) + '?correcto'

	# Procedimiento para el clik de insercion
	def post(self,request,*args,**kwargs):
		# Se recupera el formulario con los controles ya llenos
		form = self.form_class(request.POST)
		# Se recupera el registro del modelo padre 
		proyecto_post = proyecto.objects.get(id = request.GET['proyecto_id'])
		if form.is_valid():
		# El formulario es valido, no existen incongruencias
		# Se graba el registro en la base de datos pero 
		# la grabacion se mantiene pendiente, sin commit 
			actividad= form.save(commit=False)
			# Se asigna a actividad la dependencia con el modelo padre
			actividad.proyecto = proyecto_post
			# Se graba el registro definitivamente en la base de datos 
			actividad.save()
			# Se leva el control al procedimiento de salida por grabacion exitosa
			return HttpResponseRedirect(self.get_success_url())
		else:
			# Se leva el control al HTML de insercion grabacion no exitosa
			return self.render_to_response(self.get_context_data(form=form))

	# Se preparan los context para enviarlos al HTML de insercion
	def get_context_data(self,**kwargs):
		context = super(CrearactividadView, self).get_context_data(**kwargs)
		# Se recupera el objeto padre y se envia su id
		obj = proyecto.objects.get(id=self.request.GET['proyecto_id'])
		context['proyecto_id'] = obj.id
		# Se recupera el modelo abuelo y se envia su id
		empresa_empresa = empresa.objects.get(id=obj.empresa.id)
		context['empresa_id'] = empresa_empresa.id
		return context

# Este modelo es dependiente de proyecto
# Esta vista es utilizada para el borrado de
# registros del modelo actividad
class BorraractividadView(DeleteView):
	# Se define el modelo a borrar
	model = actividad
	# El template HTML para desplegar la opcion de borrado
	template_name = 'proyectos/actividad_confirm_delete.html'

	# El procedimiento de salida del borrado
	def get_success_url(self):
		# El control vuelve a la edicion del modelo padre
		return reverse_lazy('proyectos:editar_proyecto', args=[self.request.GET['proyecto_id']]) + '?correcto'

	# Se preparan los contextos para el HTML de borrado
	def get_context_data(self,**kwargs):
		context = super(BorraractividadView, self).get_context_data(**kwargs)
		# Se recupera el modelo y se envia el nombre definido para el borrado
		actividad = actividad.objects.get(id=self.object.id)
		context['nombreborrar'] = str(modelo.descripcion)
		context['proyecto_id'] = self.object.proyecto.id
		# Se recupera el modelo abuelo y se envia su id
		proyecto_proyecto = proyecto.objects.get(id=self.object.proyecto.id)
		context['empresa_id'] = proyecto_proyecto.empresa.id

		return context

# Este modelo es dependiente de actividad
# Vista que es utilizada para la edicion del
# modelo costo cuyos registros y se encuentran
# grabados en la Base de Datos
class EditarcostoView(UpdateView):
	# El modelo que se edita
	model = costo
	# El formulario para la edicion
	form_class = costoForm
	# El HTML que se despliega ante el usuario
	template_name = 'proyectos/costo_update_form.html'

	# El procedimiento de salida de la edicion
	def get_success_url(self):
		# El modelo costo es dependiente
		# Despues de editar el modelo se vuelve al HTML de edicion
		# con el mensaje de actualizacion correcta del registro
		return reverse_lazy('proyectos:editar_actividad', args=[self.request.GET['actividad_id']]) + '?correcto' + '&proyecto_id=' + str(self.request.GET['proyecto_id'])

	# Se preparan los context para enviarlos al HTML de edicion
	def get_context_data(self,**kwargs):
		context = super(EditarcostoView, self).get_context_data(**kwargs)
		# Se recupera el registro de costo que se edita
		costo = (self.object)
		modelo = (self.object)
		# Se envian al HTML el id del modelo y su campo que lo identifica
		# Este campo fue el que se definio como identificador de borrado del modelo
		context['costo_id'] = self.object.id
		context['nombre'] = str(modelo.tipocosto)

		context['actividad_id'] = self.object.actividad.id
		# Se recupera el modelo abuelo y se envia su id
		actividad_actividad = actividad.objects.get(id=self.object.actividad.id)
		context['proyecto_id'] = actividad_actividad.proyecto.id


		return context

# Este modelo es dependiente de actividad
# Esta vista es utilizada para el registro de nuevos
# registros del modelo costo
class CrearcostoView(CreateView):
	# Se define el modelo cuyo registro de inserta
	model = costo
	# El formulario para el nuevo registro
	form_class = costoForm
	# El HTML para el nuevo registro
	template_name = 'proyectos/costo_form.html'

	# El procedimiento de salida de la insercion
	def get_success_url(self):
		# Despues de la insercion del registro, el control
		# retorna al HTML de edicion del modelo padre
		return reverse_lazy('proyectos:editar_actividad', args=[self.request.GET['actividad_id']]) + '?correcto'

	# Procedimiento para el clik de insercion
	def post(self,request,*args,**kwargs):
		# Se recupera el formulario con los controles ya llenos
		form = self.form_class(request.POST)
		# Se recupera el registro del modelo padre 
		actividad_post = actividad.objects.get(id = request.GET['actividad_id'])
		if form.is_valid():
		# El formulario es valido, no existen incongruencias
		# Se graba el registro en la base de datos pero 
		# la grabacion se mantiene pendiente, sin commit 
			costo= form.save(commit=False)
			# Se asigna a costo la dependencia con el modelo padre
			costo.actividad = actividad_post
			# Se graba el registro definitivamente en la base de datos 
			costo.save()
			# Se leva el control al procedimiento de salida por grabacion exitosa
			return HttpResponseRedirect(self.get_success_url())
		else:
			# Se leva el control al HTML de insercion grabacion no exitosa
			return self.render_to_response(self.get_context_data(form=form))

	# Se preparan los context para enviarlos al HTML de insercion
	def get_context_data(self,**kwargs):
		context = super(CrearcostoView, self).get_context_data(**kwargs)
		# Se recupera el objeto padre y se envia su id
		obj = actividad.objects.get(id=self.request.GET['actividad_id'])
		context['actividad_id'] = obj.id
		# Se recupera el modelo abuelo y se envia su id
		proyecto_proyecto = proyecto.objects.get(id=obj.proyecto.id)
		context['proyecto_id'] = proyecto_proyecto.id
		return context

# Este modelo es dependiente de actividad
# Esta vista es utilizada para el borrado de
# registros del modelo costo
class BorrarcostoView(DeleteView):
	# Se define el modelo a borrar
	model = costo
	# El template HTML para desplegar la opcion de borrado
	template_name = 'proyectos/costo_confirm_delete.html'

	# El procedimiento de salida del borrado
	def get_success_url(self):
		# El control vuelve a la edicion del modelo padre
		return reverse_lazy('proyectos:editar_actividad', args=[self.request.GET['actividad_id']]) + '?correcto'

	# Se preparan los contextos para el HTML de borrado
	def get_context_data(self,**kwargs):
		context = super(BorrarcostoView, self).get_context_data(**kwargs)
		# Se recupera el modelo y se envia el nombre definido para el borrado
		costo = costo.objects.get(id=self.object.id)
		context['nombreborrar'] = str(modelo.tipocosto)
		context['actividad_id'] = self.object.actividad.id
		# Se recupera el modelo abuelo y se envia su id
		actividad_actividad = actividad.objects.get(id=self.object.actividad.id)
		context['proyecto_id'] = actividad_actividad.proyecto.id

		return context





#@[p_load_actividads_01]
def load_actividads(request):
	idp = request.GET.get('proyecto')
	padre = proyecto.objects.get(id=idp)
	actividads = actividad.objects.filter(proyecto=padre).order_by('descripcion')
	return render(request, 'proyectos/load_actividad.html', {'actividads': actividads})
#@[p_load_actividads_02]


# General de Reportes
def Acomoda(datos,datos_reporte,primeralinea,titulo=False,datos_titulo=[]):

    numeroLineas = datos_reporte[0]
    pagina = datos_reporte[2]
    salto = datos_reporte[1]
    maxlineas = datos_reporte[3]

    nuevapagina = False
    if pagina == 1:
        # encabezado
        Encabezado(datos,pagina)
        salto = 0
        pagina += 1
    if numeroLineas >= maxlineas:
        nuevapagina = True
        numeroLineas = 0
        maxlineas = 50
        datos.append([0])
    if nuevapagina:
        # encabezado
        Encabezado(datos,pagina)
        salto = 0
        pass
    if titulo:
        numeroLineas += 1
        salto += 0.5    	
        datos.append([1,['Helvetica-Bold',9,colors.black],[datos_titulo[0][1],primeralinea-salto],datos_titulo[0][0],'c'])
        numeroLineas += 1
        salto += 0.4
        # Fecha
        if datos_titulo[1][0]:
            datos.append([3,['Helvetica',8,colors.red],[datos_titulo[1][1],primeralinea-salto],'c'])
            salto += 0.5
            numeroLineas += 1
        # Linea superior de columnas
        datos.append([4,[datos_titulo[2],primeralinea-salto,datos_titulo[3],primeralinea-salto,datos_titulo[4]]])    
        salto += 0.4
        # Columnas
        pos = 0
        for col in range(0,len(datos_titulo[5]),2):
            datos.append([1,['Helvetica-Bold',9,colors.black],[datos_titulo[5][col],primeralinea-salto],datos_titulo[5][col+1],'l'])
            pos+=2
        salto += 0.2
        # Linea inferior de columnas
        datos.append([4,[datos_titulo[2],primeralinea-salto,datos_titulo[3],primeralinea-salto,datos_titulo[4]]])    
        numeroLineas += 2
        salto += 0.5

    datos_reporte[0] =  numeroLineas
    datos_reporte[1] = salto 
    datos_reporte[2] = pagina 
    datos_reporte[3] = maxlineas 

def Encabezado(datos,pagina):

    anchologo=1.50
    altologo=1.50
    posxlogo=1.00
    posylogo=25.70
    posxnombre=15.00
    posynombre=26.00
    iniciolineax=1.00
    finallineax=20.50
    iniciolineay=25.30
    grosorlinea=0.90
    piex=20.50
    piey=1.00
    lineapiex = 20.50
    lineapiey=1.70
    nombre = 'controlproyectos'

    logo = None
    try:
        cd = os.getcwd()
        logo = cd + '/core/static/core/img/logo.png'
    except:
        pass     

    datos.append([2,logo,[posxlogo,posylogo],[anchologo,altologo]])       
    datos.append([1,['Helvetica',20,colors.black],[posxnombre,posynombre],nombre,'c'])
    datos.append([4,[iniciolineax,iniciolineay,finallineax, iniciolineay,grosorlinea]])
    # Pie
    datos.append([1,['Helvetica',8,colors.black],[piex,piey],'Pag. ' + str(pagina),'c'])
    datos.append([4,[iniciolineax,lineapiey,lineapiex,lineapiey,grosorlinea]])    


