from django.urls import path
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required

from .views import HomeView
from .views import ListarrecursoView, CrearrecursoView, EditarrecursoView, BorrarrecursoView, ReporterecursoView
from .views import CrearproyectoView, EditarproyectoView, BorrarproyectoView
from .views import CrearactividadView, EditaractividadView, BorraractividadView
from .views import CrearcostoView, EditarcostoView, BorrarcostoView
from .views import ListarasignacionView, CrearasignacionView, EditarasignacionView, BorrarasignacionView, ReporteasignacionView
from .views import ListarempresaView, CrearempresaView, EditarempresaView, BorrarempresaView, ReporteempresaView

from .views import load_actividads



proyectos_patterns = ([
	path('',(HomeView.as_view()), name='home'),
	path('listar_recurso/',(ListarrecursoView.as_view()), name='listar_recurso'),
	path('reporte_recurso/',ReporterecursoView, name='reporte_recurso'),
	path('editar_recurso/<int:pk>/',(EditarrecursoView.as_view()), name='editar_recurso'),
	path('crear_recurso/',(CrearrecursoView.as_view()), name='crear_recurso'),
	path('borrar_recurso/<int:pk>/',(BorrarrecursoView.as_view()), name='borrar_recurso'),

	path('editar_proyecto/<int:pk>/',(EditarproyectoView.as_view()), name='editar_proyecto'),
	path('crear_proyecto/',(CrearproyectoView.as_view()), name='crear_proyecto'),
	path('borrar_proyecto/<int:pk>/',(BorrarproyectoView.as_view()), name='borrar_proyecto'),

	path('editar_actividad/<int:pk>/',(EditaractividadView.as_view()), name='editar_actividad'),
	path('crear_actividad/',(CrearactividadView.as_view()), name='crear_actividad'),
	path('borrar_actividad/<int:pk>/',(BorraractividadView.as_view()), name='borrar_actividad'),

	path('editar_costo/<int:pk>/',(EditarcostoView.as_view()), name='editar_costo'),
	path('crear_costo/',(CrearcostoView.as_view()), name='crear_costo'),
	path('borrar_costo/<int:pk>/',(BorrarcostoView.as_view()), name='borrar_costo'),

	path('listar_asignacion/',(ListarasignacionView.as_view()), name='listar_asignacion'),
	path('reporte_asignacion/',ReporteasignacionView, name='reporte_asignacion'),
	path('editar_asignacion/<int:pk>/',(EditarasignacionView.as_view()), name='editar_asignacion'),
	path('crear_asignacion/',(CrearasignacionView.as_view()), name='crear_asignacion'),
	path('borrar_asignacion/<int:pk>/',(BorrarasignacionView.as_view()), name='borrar_asignacion'),

	path('listar_empresa/',(ListarempresaView.as_view()), name='listar_empresa'),
	path('reporte_empresa/',ReporteempresaView, name='reporte_empresa'),
	path('editar_empresa/<int:pk>/',(EditarempresaView.as_view()), name='editar_empresa'),
	path('crear_empresa/',(CrearempresaView.as_view()), name='crear_empresa'),
	path('borrar_empresa/<int:pk>/',(BorrarempresaView.as_view()), name='borrar_empresa'),


	path('ajax/load-actividads/', load_actividads, name='ajax_load_actividads'),

], 'proyectos')

