from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from proyectos.models import recurso
from parametros.models import especialidad
from proyectos.models import proyecto
from parametros.models import tipo
from proyectos.models import actividad
from proyectos.models import costo
from parametros.models import tipocosto
from parametros.models import moneda
from proyectos.models import asignacion
from proyectos.models import empresa







class recursoForm(forms.ModelForm):
	class Meta:
		model = recurso
		fields = ('nombre','costohora','especialidad',)
		widgets = {
			'nombre': forms.TextInput(attrs={'class':'form-control font_control_recurso mt-1', 'placeholder': ''}),
			'costohora': forms.TextInput(attrs={'class':'form-control  font_control_recurso mt-1', 'placeholder': ''}),
			'especialidad': forms.Select(attrs={'class':'form-control  font_control_recurso mt-1'},choices=especialidad.objects.all()),

		}
		labels = {
		'nombre':'nombre','costohora':'Costo por hora','especialidad':'Especialidad',
		}


class proyectoForm(forms.ModelForm):
	class Meta:
		model = proyecto
		fields = ('descripcion','fechaInicio','fechaFin','tipo','responsable',)
		widgets = {
			'descripcion': forms.TextInput(attrs={'class':'form-control font_control_proyecto mt-1', 'placeholder': ''}),
			'fechaInicio': forms.DateInput(attrs={'class':'datepicker form-control  font_control_proyecto mt-1'},format="%m/%d/%Y"),
			'fechaFin': forms.DateInput(attrs={'class':'datepicker form-control  font_control_proyecto mt-1'},format="%m/%d/%Y"),
			'tipo': forms.Select(attrs={'class':'form-control  font_control_proyecto mt-1'},choices=tipo.objects.all()),
			'responsable': forms.Select(attrs={'class':'form-control  font_control_proyecto mt-1'},choices=recurso.objects.all()),

		}
		labels = {
		'descripcion':'descripcion','fechaInicio':'Fecha Inicio','fechaFin':'Fecha final','tipo':'Tipo de proyecto','responsable':'Responsable',
		}


class actividadForm(forms.ModelForm):
	class Meta:
		model = actividad
		fields = ('descripcion','fechaInicio','fechaFin',)
		widgets = {
			'descripcion': forms.TextInput(attrs={'class':'form-control font_control_actividad mt-1', 'placeholder': ''}),
			'fechaInicio': forms.DateInput(attrs={'class':'datepicker form-control  font_control_actividad mt-1'},format="%m/%d/%Y"),
			'fechaFin': forms.DateInput(attrs={'class':'datepicker form-control  font_control_actividad mt-1'},format="%m/%d/%Y"),

		}
		labels = {
		'descripcion':'Descripcion','fechaInicio':'Inicio','fechaFin':'Finalizacion',
		}


class costoForm(forms.ModelForm):
	class Meta:
		model = costo
		fields = ('tipocosto','importe','moneda',)
		widgets = {
			'tipocosto': forms.Select(attrs={'class':'form-control  font_control_costo mt-1'},choices=tipocosto.objects.all()),
			'importe': forms.TextInput(attrs={'class':'form-control  font_control_costo mt-1', 'placeholder': ''}),
			'moneda': forms.Select(attrs={'class':'form-control  font_control_costo mt-1'},choices=moneda.objects.all()),

		}
		labels = {
		'tipocosto':'descripcion','importe':'Importe','moneda':'Moneda',
		}


class asignacionForm(forms.ModelForm):
	class Meta:
		model = asignacion
		fields = ('diaAsignado','horaInicio','horas','recurso','actividad',)
		widgets = {
			'diaAsignado': forms.TextInput(attrs={'class':'form-control  font_control_asignacion mt-1', 'placeholder': ''}),
			'horaInicio': forms.TextInput(attrs={'class':'form-control font_control_asignacion mt-1', 'placeholder': ''}),
			'horas': forms.TextInput(attrs={'class':'form-control  font_control_asignacion mt-1', 'placeholder': ''}),
			'recurso': forms.Select(attrs={'class':'form-control  font_control_asignacion mt-1'},choices=recurso.objects.all()),
			'actividad': forms.Select(attrs={'class':'form-control  font_control_asignacion mt-1'},choices=actividad.objects.all()),

		}
		labels = {
		'diaAsignado':'Dia asignado','horaInicio':'Hora inicio','horas':'Horas','recurso':'Recurso','actividad':'Actividad',
		}
	def clean(self):
		horaInicio = self.cleaned_data['horaInicio']
		if len(horaInicio) != 5:
		    raise forms.ValidationError('La horaInicio debe ser de 5 caracteres')
		if horaInicio[2:3] != ':':
		    raise forms.ValidationError('El caracter que separa horas de minutos debe ser ":"')
		if (int(horaInicio[0:2]) <0 or int(horaInicio[0:2]) >23) or (int(horaInicio[3:5]) <0 or int(horaInicio[3:5]) >59):
		    raise forms.ValidationError('Las horas deben estar entre "00" y "23" y los minutos entre "00" y "59"')


class empresaForm(forms.ModelForm):
	class Meta:
		model = empresa
		fields = ('nombre',)
		widgets = {
			'nombre': forms.TextInput(attrs={'class':'form-control font_control_empresa mt-1', 'placeholder': ''}),

		}
		labels = {
		'nombre':'Nombre',
		}





