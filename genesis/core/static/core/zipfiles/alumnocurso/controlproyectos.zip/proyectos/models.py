from django.db import models
from ckeditor.fields import RichTextField
from django.core.exceptions import ValidationError
from django.utils.translation import ugettext_lazy as _
from django.urls import reverse, reverse_lazy
from django.utils import timezone
from django.contrib.auth.models import User


# Modelos Foreign

from parametros.models import especialidad
from parametros.models import tipo
from parametros.models import tipocosto
from parametros.models import moneda



# Crear los modelo aqui.


class recurso(models.Model):


	nombre = models.CharField(max_length=30,default='')
	costohora =  models.DecimalField(default=0,decimal_places=2,max_digits=10)
	especialidad =  models.ForeignKey(especialidad, on_delete=models.CASCADE, related_name='%(class)s_especialidad')


	def __str__(self):
		return self.nombre

class empresa(models.Model):


	nombre = models.CharField(max_length=30,default='')


	def __str__(self):
		return self.nombre

class proyecto(models.Model):


	descripcion = models.CharField(max_length=30,default='')
	fechaInicio = models.DateField(default=timezone.now)
	fechaFin = models.DateField(default=timezone.now)
	tipo =  models.ForeignKey(tipo, on_delete=models.CASCADE, related_name='%(class)s_tipo')
	responsable =  models.ForeignKey(recurso, on_delete=models.CASCADE, related_name='%(class)s_responsable')
	empresa =  models.ForeignKey(empresa, on_delete=models.CASCADE)


	def __str__(self):
		return self.descripcion

class actividad(models.Model):


	descripcion = models.CharField(max_length=30)
	fechaInicio = models.DateField(default=timezone.now)
	fechaFin = models.DateField(default=timezone.now)
	proyecto =  models.ForeignKey(proyecto, on_delete=models.CASCADE)


	def __str__(self):
		return self.descripcion

class asignacion(models.Model):


	diaAsignado =  models.SmallIntegerField(default=0)
	horaInicio = models.CharField(max_length=5,default='')
	horas =  models.SmallIntegerField(default=0)
	recurso =  models.ForeignKey(recurso, on_delete=models.CASCADE, related_name='%(class)s_recurso')
	actividad =  models.ForeignKey(actividad, on_delete=models.CASCADE, related_name='%(class)s_actividad')


	def __str__(self):
		return self.recurso + '-' + self.actividad

class costo(models.Model):


	tipocosto =  models.ForeignKey(tipocosto, on_delete=models.CASCADE, related_name='%(class)s_tipocosto')
	importe =  models.DecimalField(default=0,decimal_places=2,max_digits=10)
	moneda =  models.ForeignKey(moneda, on_delete=models.CASCADE, related_name='%(class)s_moneda')
	fecha = models.DateField(default=timezone.now)
	actividad =  models.ForeignKey(actividad, on_delete=models.CASCADE)


	def __str__(self):
		return self.tipocosto



