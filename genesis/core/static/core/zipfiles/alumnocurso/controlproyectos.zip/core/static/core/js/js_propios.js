$(function(){
	// #@[p_js_general_01] //
	var enlace = $('#link-busqueda');
	// #@[p_js_general_02] //
	enlace.on('click',function(){
	// #@[p_js_general_03] //
		var texto = $('#textob');
	// #@[p_js_general_04] //
		enlace.attr('href','http://127.0.0.1:8000/');
	// #@[p_js_general_05] //
		// enlace.attr('href',"{% url 'proyectos:lista' %}" + '?criterio=' + texto);
		// enlace.attr('href','http://www.microsoft.com');
	});
	// #@[p_js_general_06] //
}())
	// #@[p_js_general_07] //

// Funcion que se ejecuta cuando se acciona el boton
// de busqueda en el html del modelo recurso
// #@[p_js_busqueda_recurso_01] //
$(function(){
// #@[p_js_busqueda_recurso_02] //
	var enlace = $('#link-busqueda_recurso');
// #@[p_js_busqueda_recurso_03] //
	enlace.on('click',function(){
// #@[p_js_busqueda_recurso_04] //
	var texto = $('#textobrecurso');
// #@[p_js_busqueda_recurso_05] //
	enlace.attr('href','http://127.0.0.1:8001/proyectos/listar_recurso?duplica=0&criterio=' + texto.val());
// #@[p_js_busqueda_recurso_06] //
});
// #@[p_js_busqueda_recurso_07] //
}())
// #@[p_js_busqueda_recurso_08] //
