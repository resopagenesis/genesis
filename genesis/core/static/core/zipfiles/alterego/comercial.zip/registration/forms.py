from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

@importmodelos

#@[p_importmodelos_01]

@listachoices

#@[p_listachoices_01]

#@[p_forms_01]

@forms

