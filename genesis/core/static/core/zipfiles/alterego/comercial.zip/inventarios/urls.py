from django.urls import path
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required

from .views import HomeView
from .views import ListaritemView, CrearitemView, EditaritemView, BorraritemView
from .views import ListarfacturaView, CrearfacturaView, EditarfacturaView, BorrarfacturaView
from .views import CreardetalleView, EditardetalleView, BorrardetalleView



inventarios_patterns = ([
	path('',(HomeView.as_view()), name='home'),
	path('listar_item/',(ListaritemView.as_view()), name='listar_item'),
	path('editar_item/<int:pk>/',(EditaritemView.as_view()), name='editar_item'),
	path('crear_item/',(CrearitemView.as_view()), name='crear_item'),
	path('borrar_item/<int:pk>/',(BorraritemView.as_view()), name='borrar_item'),

	path('listar_factura/',(ListarfacturaView.as_view()), name='listar_factura'),
	path('editar_factura/<int:pk>/',(EditarfacturaView.as_view()), name='editar_factura'),
	path('crear_factura/',(CrearfacturaView.as_view()), name='crear_factura'),
	path('borrar_factura/<int:pk>/',(BorrarfacturaView.as_view()), name='borrar_factura'),

	path('editar_detalle/<int:pk>/',(EditardetalleView.as_view()), name='editar_detalle'),
	path('crear_detalle/',(CreardetalleView.as_view()), name='crear_detalle'),
	path('borrar_detalle/<int:pk>/',(BorrardetalleView.as_view()), name='borrar_detalle'),


], 'inventarios')


