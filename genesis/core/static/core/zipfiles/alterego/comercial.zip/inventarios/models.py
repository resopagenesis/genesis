from django.db import models
from ckeditor.fields import RichTextField
from django.core.exceptions import ValidationError
from django.utils.translation import ugettext_lazy as _
from django.urls import reverse, reverse_lazy
from django.utils import timezone


# Modelos Foreign




# Create your models here.


class item(models.Model):


	codigo = models.CharField(max_length=30,default='')
	descripcion = models.CharField(max_length=30,default='')


	def __str__(self):
		return self.codigo

class factura(models.Model):


	numero =  models.IntegerField(default = 0)
	glosa = models.CharField(max_length=100,default='')


	def __str__(self):
		return str(self.numero)

class detalle(models.Model):


	item =  models.ForeignKey(item, on_delete=models.CASCADE, related_name='%(class)s_item')
	cantidad =  models.IntegerField(default = 0)
	precio =  models.DecimalField(default = 0,decimal_places=3,max_digits=10)
	factura =  models.ForeignKey(factura, on_delete=models.CASCADE)


	def __str__(self):
		return self.item.codigo




