from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from inventarios.models import item
from inventarios.models import factura
from inventarios.models import detalle
from inventarios.models import item







class itemForm(forms.ModelForm):
	class Meta:
		model = item
		fields = ('codigo','descripcion',)
		widgets = {
			'codigo': forms.TextInput(attrs={'class':'form-control font_control_item mt-1', 'placeholder': ''}),
			'descripcion': forms.TextInput(attrs={'class':'form-control font_control_item mt-1', 'placeholder': ''}),

		}
		labels = {
		'codigo':'','descripcion':'',
		}


class facturaForm(forms.ModelForm):
	class Meta:
		model = factura
		fields = ('numero','glosa',)
		widgets = {
			'numero': forms.TextInput(attrs={'class':'form-control  font_control_factura mt-1', 'placeholder': ''}),
			'glosa': forms.TextInput(attrs={'class':'form-control font_control_factura mt-1', 'placeholder': ''}),

		}
		labels = {
		'numero':'','glosa':'',
		}


class detalleForm(forms.ModelForm):
	class Meta:
		model = detalle
		fields = ('item','cantidad','precio',)
		widgets = {
			'item': forms.Select(choices=item.objects.all()),
			'cantidad': forms.TextInput(attrs={'class':'form-control  font_control_detalle mt-1', 'placeholder': ''}),
			'precio': forms.TextInput(attrs={'class':'form-control  font_control_detalle mt-1', 'placeholder': ''}),

		}
		labels = {
		'item':'','cantidad':'','precio':'',
		}






