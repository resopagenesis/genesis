from django.shortcuts import render
from django.views.generic.list import ListView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.views.generic.base import TemplateView
from django.urls import reverse, reverse_lazy
from django.http import HttpResponseRedirect

from inventarios.models import item
from inventarios.models import factura
from inventarios.models import detalle
from inventarios.models import detalle
from inventarios.models import factura
from inventarios.models import factura



from .forms import itemForm
from .forms import facturaForm
from .forms import detalleForm




# Create your views here.
class HomeView(TemplateView):
	template_name = 'inventarios/home.html'

class ListaritemView(ListView):
	model = item

	def get_context_data(self,**kwargs):
		context = super(ListaritemView, self).get_context_data(**kwargs)
		return context

class EditaritemView(UpdateView):
	model = item
	form_class = itemForm
	template_name_suffix = '_update_form'

	def get_success_url(self):
		return reverse_lazy('inventarios:editar_item', args=[self.object.id]) + '?correcto'

	def get_context_data(self,**kwargs):
		context = super(EditaritemView, self).get_context_data(**kwargs)
		item = (self.object)
		context['item_id'] = self.object.id

		context['nombre'] = item.codigo
		return context

class CrearitemView(CreateView):
	model = item
	form_class = itemForm

	def get_success_url(self):
		return reverse_lazy('inventarios:listar_item') + '?correcto'
	def get_context_data(self,**kwargs):
		context = super(CrearitemView, self).get_context_data(**kwargs)
		return context

class BorraritemView(DeleteView):
	model = item

	def get_success_url(self):
		return reverse_lazy('inventarios:listar_item') + '?correcto'
	def get_context_data(self,**kwargs):
		context = super(BorraritemView, self).get_context_data(**kwargs)
		item_borra_item_borra = item.objects.get(id=self.object.id)
		context['nombreborrar'] = item_borra_item_borra.codigo
		return context

class ListarfacturaView(ListView):
	model = factura

	def get_context_data(self,**kwargs):
		context = super(ListarfacturaView, self).get_context_data(**kwargs)
		return context

class EditarfacturaView(UpdateView):
	model = factura
	form_class = facturaForm
	template_name_suffix = '_update_form'

	def get_success_url(self):
		return reverse_lazy('inventarios:editar_factura', args=[self.object.id]) + '?correcto'

	def get_context_data(self,**kwargs):
		context = super(EditarfacturaView, self).get_context_data(**kwargs)
		factura = (self.object)
		context['factura_id'] = self.object.id
		detalle_lista = detalle.objects.filter(factura = factura)
		context['listadetalle'] =  detalle_lista

		context['nombre'] = factura.numero
		context['numerodetalle'] = detalle.objects.filter(factura=factura).count()
		return context

class CrearfacturaView(CreateView):
	model = factura
	form_class = facturaForm

	def get_success_url(self):
		return reverse_lazy('inventarios:listar_factura') + '?correcto'
	def get_context_data(self,**kwargs):
		context = super(CrearfacturaView, self).get_context_data(**kwargs)
		return context

class BorrarfacturaView(DeleteView):
	model = factura

	def get_success_url(self):
		return reverse_lazy('inventarios:listar_factura') + '?correcto'
	def get_context_data(self,**kwargs):
		context = super(BorrarfacturaView, self).get_context_data(**kwargs)
		factura_borra_factura_borra = factura.objects.get(id=self.object.id)
		context['nombreborrar'] = factura_borra_factura_borra.numero
		return context





class EditardetalleView(UpdateView):
	model = detalle
	form_class = detalleForm
	template_name_suffix = '_update_form'

	def get_success_url(self):
		return reverse_lazy('inventarios:editar_factura', args=[self.request.GET['factura_id']]) + '?correcto'

	def get_context_data(self,**kwargs):
		context = super(EditardetalleView, self).get_context_data(**kwargs)
		detalle = (self.object)
		context['detalle_id'] = self.object.id
		context['nombre'] = detalle.item

		context['factura_id'] = self.object.factura.id


		return context

class CreardetalleView(CreateView):
	model = detalle
	form_class = detalleForm

	def get_success_url(self):
		return reverse_lazy('inventarios:editar_factura', args=[self.request.GET['factura_id']]) + '?correcto'

	def post(self,request,*args,**kwargs):
		form = self.form_class(request.POST)
		factura_post = factura.objects.get(id = request.GET['factura_id'])
		if form.is_valid():
			detalle= form.save(commit=False)
			detalle.factura = factura_post
			detalle.save()
			return HttpResponseRedirect(self.get_success_url())
		else:
			return self.render_to_response(self.get_context_data(form=form))

	def get_context_data(self,**kwargs):
		context = super(CreardetalleView, self).get_context_data(**kwargs)
		context['factura_id'] = self.request.GET['factura_id']
		return context

class BorrardetalleView(DeleteView):
	model = detalle

	def get_success_url(self):
		return reverse_lazy('inventarios:editar_factura', args=[self.request.GET['factura_id']]) + '?correcto'

	def get_context_data(self,**kwargs):
		context = super(BorrardetalleView, self).get_context_data(**kwargs)
		detalle_borra_detalle_borra = detalle.objects.get(id=self.object.id)
		context['nombreborrar'] = detalle_borra_detalle_borra.item
		context['factura_id'] = self.object.factura.id

		return context






