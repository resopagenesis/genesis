from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from contabilidad.models import cuenta
from contabilidad.models import comprobante
from contabilidad.models import asiento
from contabilidad.models import cuenta







class cuentaForm(forms.ModelForm):
	class Meta:
		model = cuenta
		fields = ('codigo','descripcion',)
		widgets = {
			'codigo': forms.TextInput(attrs={'class':'form-control font_control_cuenta mt-1', 'placeholder': 'Codigo de cuenta'}),
			'descripcion': forms.TextInput(attrs={'class':'form-control font_control_cuenta mt-1', 'placeholder': ''}),

		}
		labels = {
		'codigo':'Codigo:','descripcion':'Descripcion:',
		}


class comprobanteForm(forms.ModelForm):
	class Meta:
		model = comprobante
		fields = ('fecha','glosa','numero',)
		widgets = {
			'fecha': forms.DateInput(format="%m/%d/%Y"),
			'glosa': forms.TextInput(attrs={'class':'form-control font_control_comprobante mt-1', 'placeholder': ''}),
			'numero': forms.TextInput(attrs={'class':'form-control  font_control_comprobante mt-1', 'placeholder': ''}),

		}
		labels = {
		'fecha':'','glosa':'','numero':'',
		}


class asientoForm(forms.ModelForm):
	class Meta:
		model = asiento
		fields = ('cuenta','debe','haber',)
		widgets = {
			'cuenta': forms.Select(choices=cuenta.objects.all()),
			'debe': forms.TextInput(attrs={'class':'form-control  font_control_asiento mt-1', 'placeholder': ''}),
			'haber': forms.TextInput(attrs={'class':'form-control  font_control_asiento mt-1', 'placeholder': ''}),

		}
		labels = {
		'cuenta':'','debe':'','haber':'',
		}






