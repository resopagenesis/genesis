from django.db import models
from ckeditor.fields import RichTextField
from django.core.exceptions import ValidationError
from django.utils.translation import ugettext_lazy as _
from django.urls import reverse, reverse_lazy
from django.utils import timezone


# Modelos Foreign




# Create your models here.


class cuenta(models.Model):


	codigo = models.CharField(max_length=30,default='')
	descripcion = models.CharField(max_length=100,default='')


	def __str__(self):
		return self.codigo

class comprobante(models.Model):


	fecha =  models.DateTimeField(default=timezone.now)
	glosa = models.CharField(max_length=30,default='')
	numero =  models.IntegerField(default = 0)


	def __str__(self):
		return str(self.fecha)

class asiento(models.Model):


	cuenta =  models.ForeignKey(cuenta, on_delete=models.CASCADE, related_name='%(class)s_cuenta')
	debe =  models.DecimalField(default = 0,decimal_places=3,max_digits=10)
	haber =  models.DecimalField(default = 0,decimal_places=3,max_digits=10)
	comprobante =  models.ForeignKey(comprobante, on_delete=models.CASCADE)


	def __str__(self):
		return self.cuenta.codigo




