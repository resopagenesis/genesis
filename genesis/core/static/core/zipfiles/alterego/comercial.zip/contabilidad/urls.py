from django.urls import path
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required

from .views import HomeView
from .views import ListarcuentaView, CrearcuentaView, EditarcuentaView, BorrarcuentaView
from .views import ListarcomprobanteView, CrearcomprobanteView, EditarcomprobanteView, BorrarcomprobanteView
from .views import CrearasientoView, EditarasientoView, BorrarasientoView



contabilidad_patterns = ([
	path('',(HomeView.as_view()), name='home'),
	path('listar_cuenta/',(ListarcuentaView.as_view()), name='listar_cuenta'),
	path('editar_cuenta/<int:pk>/',(EditarcuentaView.as_view()), name='editar_cuenta'),
	path('crear_cuenta/',(CrearcuentaView.as_view()), name='crear_cuenta'),
	path('borrar_cuenta/<int:pk>/',(BorrarcuentaView.as_view()), name='borrar_cuenta'),

	path('listar_comprobante/',(ListarcomprobanteView.as_view()), name='listar_comprobante'),
	path('editar_comprobante/<int:pk>/',(EditarcomprobanteView.as_view()), name='editar_comprobante'),
	path('crear_comprobante/',(CrearcomprobanteView.as_view()), name='crear_comprobante'),
	path('borrar_comprobante/<int:pk>/',(BorrarcomprobanteView.as_view()), name='borrar_comprobante'),

	path('editar_asiento/<int:pk>/',(EditarasientoView.as_view()), name='editar_asiento'),
	path('crear_asiento/',(CrearasientoView.as_view()), name='crear_asiento'),
	path('borrar_asiento/<int:pk>/',(BorrarasientoView.as_view()), name='borrar_asiento'),


], 'contabilidad')


