from django.shortcuts import render
from django.views.generic.list import ListView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.views.generic.base import TemplateView
from django.urls import reverse, reverse_lazy
from django.http import HttpResponseRedirect

from contabilidad.models import cuenta
from contabilidad.models import comprobante
from contabilidad.models import asiento
from contabilidad.models import asiento
from contabilidad.models import comprobante
from contabilidad.models import comprobante



from .forms import cuentaForm
from .forms import comprobanteForm
from .forms import asientoForm




# Create your views here.
class HomeView(TemplateView):
	template_name = 'contabilidad/home.html'

class ListarcuentaView(ListView):
	model = cuenta

	def get_context_data(self,**kwargs):
		context = super(ListarcuentaView, self).get_context_data(**kwargs)
		return context

class EditarcuentaView(UpdateView):
	model = cuenta
	form_class = cuentaForm
	template_name_suffix = '_update_form'

	def get_success_url(self):
		return reverse_lazy('contabilidad:editar_cuenta', args=[self.object.id]) + '?correcto'

	def get_context_data(self,**kwargs):
		context = super(EditarcuentaView, self).get_context_data(**kwargs)
		cuenta = (self.object)
		context['cuenta_id'] = self.object.id

		context['nombre'] = cuenta.codigo
		return context

class CrearcuentaView(CreateView):
	model = cuenta
	form_class = cuentaForm

	def get_success_url(self):
		return reverse_lazy('contabilidad:listar_cuenta') + '?correcto'
	def get_context_data(self,**kwargs):
		context = super(CrearcuentaView, self).get_context_data(**kwargs)
		return context

class BorrarcuentaView(DeleteView):
	model = cuenta

	def get_success_url(self):
		return reverse_lazy('contabilidad:listar_cuenta') + '?correcto'
	def get_context_data(self,**kwargs):
		context = super(BorrarcuentaView, self).get_context_data(**kwargs)
		cuenta_borra_cuenta_borra = cuenta.objects.get(id=self.object.id)
		context['nombreborrar'] = cuenta_borra_cuenta_borra.codigo
		return context

class ListarcomprobanteView(ListView):
	model = comprobante

	def get_context_data(self,**kwargs):
		context = super(ListarcomprobanteView, self).get_context_data(**kwargs)
		return context

class EditarcomprobanteView(UpdateView):
	model = comprobante
	form_class = comprobanteForm
	template_name_suffix = '_update_form'

	def get_success_url(self):
		return reverse_lazy('contabilidad:editar_comprobante', args=[self.object.id]) + '?correcto'

	def get_context_data(self,**kwargs):
		context = super(EditarcomprobanteView, self).get_context_data(**kwargs)
		comprobante = (self.object)
		context['comprobante_id'] = self.object.id
		asiento_lista = asiento.objects.filter(comprobante = comprobante)
		context['listaasiento'] =  asiento_lista

		context['nombre'] = comprobante.fecha
		context['numeroasiento'] = asiento.objects.filter(comprobante=comprobante).count()
		return context

class CrearcomprobanteView(CreateView):
	model = comprobante
	form_class = comprobanteForm

	def get_success_url(self):
		return reverse_lazy('contabilidad:listar_comprobante') + '?correcto'
	def get_context_data(self,**kwargs):
		context = super(CrearcomprobanteView, self).get_context_data(**kwargs)
		return context

class BorrarcomprobanteView(DeleteView):
	model = comprobante

	def get_success_url(self):
		return reverse_lazy('contabilidad:listar_comprobante') + '?correcto'
	def get_context_data(self,**kwargs):
		context = super(BorrarcomprobanteView, self).get_context_data(**kwargs)
		comprobante_borra_comprobante_borra = comprobante.objects.get(id=self.object.id)
		context['nombreborrar'] = comprobante_borra_comprobante_borra.fecha
		return context





class EditarasientoView(UpdateView):
	model = asiento
	form_class = asientoForm
	template_name_suffix = '_update_form'

	def get_success_url(self):
		return reverse_lazy('contabilidad:editar_comprobante', args=[self.request.GET['comprobante_id']]) + '?correcto'

	def get_context_data(self,**kwargs):
		context = super(EditarasientoView, self).get_context_data(**kwargs)
		asiento = (self.object)
		context['asiento_id'] = self.object.id
		context['nombre'] = asiento.cuenta

		context['comprobante_id'] = self.object.comprobante.id


		return context

class CrearasientoView(CreateView):
	model = asiento
	form_class = asientoForm

	def get_success_url(self):
		return reverse_lazy('contabilidad:editar_comprobante', args=[self.request.GET['comprobante_id']]) + '?correcto'

	def post(self,request,*args,**kwargs):
		form = self.form_class(request.POST)
		comprobante_post = comprobante.objects.get(id = request.GET['comprobante_id'])
		if form.is_valid():
			asiento= form.save(commit=False)
			asiento.comprobante = comprobante_post
			asiento.save()
			return HttpResponseRedirect(self.get_success_url())
		else:
			return self.render_to_response(self.get_context_data(form=form))

	def get_context_data(self,**kwargs):
		context = super(CrearasientoView, self).get_context_data(**kwargs)
		context['comprobante_id'] = self.request.GET['comprobante_id']
		return context

class BorrarasientoView(DeleteView):
	model = asiento

	def get_success_url(self):
		return reverse_lazy('contabilidad:editar_comprobante', args=[self.request.GET['comprobante_id']]) + '?correcto'

	def get_context_data(self,**kwargs):
		context = super(BorrarasientoView, self).get_context_data(**kwargs)
		asiento_borra_asiento_borra = asiento.objects.get(id=self.object.id)
		context['nombreborrar'] = asiento_borra_asiento_borra.cuenta
		context['comprobante_id'] = self.object.comprobante.id

		return context






